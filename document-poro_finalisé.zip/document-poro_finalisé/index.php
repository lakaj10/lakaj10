<?php include './mvc/config/config.php'; 
############################################################################################################################################

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
      <link href="./mvc/vues/img/logo/cc.png" rel="icon"style="width:100%">
    <title> CHARGEMENT</title>
    <link href="./mvc/design/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="./mvc/design/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="./mvc/design/css/ruang-admin.min.css" rel="stylesheet">
    <link href="./mvc/design/css/ruang-admin.css" rel="stylesheet">
    <link href="./mvc/design/css/animate.css" rel="stylesheet">
</head>

<body id="page-top"style="background:<?php echo BODY3;?>;"oncontextmenu="return false">

<script language="javascript">
  document.onmousedown=disableclick;status="Right Click Disabled";Function disableclick(e){if(event.button==2){alert(status);return false;}}

  </script>
<script type="text/JavaScript">
      var clignotement = function(){ 
      if (document.getElementById('DivClignotantesiaka').style.visibility=='visible'){ 
      document.getElementById('DivClignotantesiaka').style.visibility='hidden'; 
      } 
      else{ 
      document.getElementById('DivClignotantesiaka').style.visibility='visible'; 
      } 
      }; 
      periode = setInterval(clignotement, 400);



        var clignotement = function(){ 
      if (document.getElementById('DivClignotantesiaka2').style.visibility=='visible'){ 
      document.getElementById('DivClignotantesiaka2').style.visibility='hidden'; 
      } 
      else{ 
      document.getElementById('DivClignotantesiaka2').style.visibility='visible'; 
      } 
      }; 
      periode = setInterval(clignotement, 400);

</script>

<?php
############################################################################################################################################

      /*
      
      define('COULEUR', 'orange');
      define('FOOTER', '#01D758');
      define('GAUCHE', '#01D758');
      
      */

if(empty($_SESSION['pseudo']))
{
############################################################################################################################################
 echo' <center><br><br><br><br><br><br><br><br> <img src="./mvc/vues/img/logo/loading1.gif" style=" height:180px;width:180px;visibility: visible; -webkit-animation: bounce 3.9s ; " alt="souci d\'affichage" title="DOCUMENTS-PORO.CI"><br><br> <i class="fa fa-spinnerA fa-spinA fa-2x"style="color:'.COULEUR.';font-size:16px;"></i> Patientez ,   Chargement de <b style="color:orange;font-family:arial black"> DOCUMENT-PORO.CI </b>en cours de redirection...</center> <META HTTP-EQUIV="refresh" CONTENT="6; URL=./woodoo.php?webox='.MESSAGE.'&tokken='.MESSAGE.'">';

      //echo'            <span id="DivClignotantesiakaa" style="font-weight:bolder;padding-top: .9rem 1rem;font-size:auto;color:'.COULEUR.';text-decoration:none;font-family: mistral">D</span><span id="DivClignotantesiaka2a" style="font-weight:bolder;padding-top: -60px;font-size:auto;color:'.GAUCHE.';text-decoration:none;font-family: mistral">P</span>              <center> <i class="fa fa-spinner fa-spin fa-3x"style="color:#fc544b;;margin: 20% auto;font-size:90px"id="DivClignotantesiakaa"></i><br> <i class="fa fa-spinnera fa-spin fa-2x"style="color:'.COULEUR.';font-size:18px"></i> Patientez ,  Chargement de redirection en cours ...</center><META HTTP-EQUIV="refresh" CONTENT="5; URL=./woodoo.php?webox='.OUVERTURE.'">';

}
else
{ 
 echo' <center><br><br><br><br><br><br><br><br> <img src="./mvc/vues/img/logo/loading1.gif" style=" height:180px;width:180px;visibility: visible; -webkit-animation: flash 2.9s ; "" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI"><br><br> <i class="fa fa-spinnerA fa-spinA fa-2x"style="color:'.COULEUR.';font-size:16px;"></i> Redirection de <b style="color:orange">'.$_SESSION['nomprenoms'].'</b> en cours sur votre Profil ...</center>  <META HTTP-EQUIV="refresh" CONTENT="6; URL=./goodoo.php?webox='.DASHBOARD.'">';
      //echo'<center> <i class="fa fa-spinner fa-spin fa-3x"style="color:#fc544b;;margin: 20% auto;font-size:90px"id="DivClignotantesiakaa"></i><br> <i class="fa fa-spinnera fa-spin fa-2x"style="color:'.COULEUR.';font-size:18px"></i> Patientez ,  Chargement de redirection en cours ...</center><META HTTP-EQUIV="refresh" CONTENT="5; URL=./goodoo.php?webox='.DASHBOARD.'">';      
}
 
############################################################################################################################################


      $reponse=$bdd->query("SELECT * FROM visiteurs WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
      $res=$reponse->fetchAll();
      $ip=$_SERVER['REMOTE_ADDR'];
      $appareil=$_SERVER['HTTP_USER_AGENT'];
      $datevisite=date('d/m/Y');
      $heurevisite=date('H:i');

if(count($res)==0)   // L'IP ne se trouve pas dans la table, on va l'ajouter.
{   
      $req= $bdd->prepare('INSERT INTO visiteurs(ip,appareil,datevisite,heurevisite)VALUES(?,?,?,?)');
      $req->execute(array($ip,$appareil,$datevisite,$heurevisite));
}
      else // L'IP se trouve déjà dans la table, on met juste à jour le timestamp.
{
      $bdd->exec("UPDATE visiteurs SET  appareil='".$appareil."',datevisite='".$datevisite."',heurevisite='".$heurevisite."' WHERE ip='".$ip."'");
}

      $reponse=$bdd->query("SELECT COUNT(*) AS nbre_entrees FROM visiteurs"); while($donnees = $reponse ->fetch())
{
    // echo '0<b>'.$donnees['nbre_entrees'].'</b>';
} 
      $reponse->closeCursor();
?>

<!-- Scroll to top -->
<a class="scroll-to-top rounded" href="#page-top">
<i class="fas fa-angle-up"></i>
</a>
<?php  include('./mvc/models/webox/image_du_bas.php');

############################################################################################################################################

?>


    <script src="./mvc/design/vendor/jquery/jquery.min.js"></script>
    <script src="./mvc/design/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="./mvc/design/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="./mvc/design/js/ruang-admin.min.js"></script>
    <script src="./mvc/design/vendor/chart.js/Chart.min.js"></script>
    <script src="./mvc/design/js/demo/chart-area-demo.js"></script>  
</body>
</html>


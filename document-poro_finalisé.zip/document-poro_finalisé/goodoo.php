<?php include './mvc/config/config.php'; 
 ############################################################################################################################
//var_dump($_SESSION);
if(empty($_SESSION['pseudo']))
{
 // echo '<b><script type="text/javascript"> alert(\'Votre session a expirée . Veillez vous reconnecter pour continuer.\');</script></b>';
   echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./woodoo.php?webox='.OUVERTURE.'"</SCRIPT>';        

}
else{
/* $session=$_SESSION['id'];
$req=$bdd->prepare("SELECT * FROM users where id='".$session."'");
if($req){
  $connectes=1 ;
  $date=getdate();

  $joura=date('d');
  $moisa=date('m');
  $anneea=date('Y');

  $hour=date('H');
  $min=date('i');
  $sec=date('s');

  $datec=$joura.'/'.$moisa.'/'.$anneea;
  $heurec=$hour.':'.$min.':'.$sec;
  $bdd->exec("UPDATE users SET connectes='".$connectes."',datec='".$datec."',heurec='".$heurec."' WHERE id='".$session."'");      
}*/
} 
 ############################################################################################################################

  
     
      $pseudo=$_SESSION['pseudo'];
       $id=$_SESSION['id'];
      $time=time();
   $reponse=$bdd->query('SELECT * FROM session  WHERE pseudo="'.$pseudo.'" AND expiration<'.$time);
   $res = $reponse->fetchAll();
    if ($res){
      if(isset($_SESSION['id'])){
            $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
            $donnees=$req->fetch(); 
      if( $donnees['verrou']=='1'){
            $connectes=0 ;
            $datec='';
            $heurec='';
            $bdd->exec("UPDATE users SET connectes='".$connectes."',datec='".$datec."',heurec='".$heurec."' WHERE id='".$id."'"); 
         } 
        } 
              $bdd->exec(" DELETE FROM session WHERE expiration < ".$time);
  // echo '<b><script type="text/javascript"> alert(\'Votre session a expirée . Veillez vous reconnecter \');</script></b>';
    /* $_SESSION = array();
            session_destroy();
            sleep(2);*/
        echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./woodoo.php?webox='.OUVERTURE.'&tokken='.SESSION_EXPIREE.'&id='.$_SESSION['id'].'"</SCRIPT>';
      }         
     



   
      $reponse->closeCursor();

?>

  <?php 
                  if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='2'){
                    $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                    $donnees=$req->fetch(); 
                    if($req){
                      // age actuelle du client
                       $date_du_jour2=date("d/m");
                    $jm_dn=substr($donnees['dn'],0,5);
                    $annee=date("Y");

                    if($jm_dn==$date_du_jour2)
                    {  
                    $annee1=substr($donnees['dn'],6,20);
                    $annee2=date("Y");
                    $agee=$annee2-$annee1;

                    $dn=$donnees['dn'];
                    $annee=date("Y");
                    $annee_suivante=date("Y")+1;

                    $date_du_jour2=date("d/m");
                    $jm_dn=substr($donnees['dn'],0,5);
                    $annee=date("Y");

                    $anniv=$jm_dn.'/'.$annee;


                    $prochain_anniv=$jm_dn.'/'.$annee_suivante;


                    $date_du_jour=date("d/m/Y");

                   
                        
                        $id=$_SESSION['id'];
                        $dn=$donnees['dn'];
                        $dna=$jm_dn;
                        $da=$date_du_jour2;
                        $age=$agee;
                        
                        $bdd->exec("UPDATE users SET dna='".$dna."',da='".$da."',age='".$age."' WHERE id='".$id."'");
                        }
                        elseif($jm_dn!=$date_du_jour2)
                        {
                         $dna='';
                         $da='';
                         $age='';
                        $bdd->exec("UPDATE users SET dna='".$dna."',da='".$da."',age='".$age."' WHERE id='".$id."'");

                        }
                        
                    
                    /*
                     echo '<span style="color:lime"><b> '.$dn.' ANS</b></span> ';
                     echo '<span style="color:red"><b> '.$anniv.' ANS</b></span> ';
                     echo '<span style="color:blue"><b> '.$date_du_jour.' ANS</b></span> ';
                      echo '<span style="color:blue"><b> '.$prochain_anniv.' ANS</b></span> ';
                    */         
                  }
                  }
                  
                   ?>


<?php 
 ############################################################################################################################
        if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='1'){
         
      }
      
        elseif(isset($_SESSION['id']) AND $_SESSION['droitacces']=='2'){
            $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
            $donnees=$req->fetch(); 
      if( $donnees['verrou']=='1'){
            $connectes=0 ;
            $datec='';
            $heurec='';
            $bdd->exec("UPDATE users SET connectes='".$connectes."',datec='".$datec."',heurec='".$heurec."' WHERE id='".$session."'"); 
 ############################################################################################################################

            $_SESSION = array();
            session_destroy();
            //sleep(2);
            echo '<script type="text/javascript"> alert(\'     Ce compte a été bloqué . plus dinfos au +225 070 907 138 9        \');</script>';

            echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./woodoo.php?webox='.OUVERTURE.'&msg=mercato"</SCRIPT>'; 
      
  }
  
}
                  
                   ?>
 <?php
//setcookie('pseudo', ''.$_SESSION['pseudo'].'', time() + 365*24*3600, null, null,false, true); 
?>
<!DOCTYPE html>
<html lang="fr">
<head>

      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Favicon-->
      <!-- Author Meta -->
      <meta name="author" content="nivodex">
      <!-- Meta Description -->
    <meta name="description" content="Découvre les résultats des examens">
    <meta name="keywords" content="résultats, examens, résultats en ligne">
    <meta charset="UTF-8">
      <!-- Site Title -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <meta content="fr" http-equiv="Content-Language">
      <meta content="search engine" name="Classification">
      <meta content="Documents-poro.ci, La Poste Côte d&#39;Ivoire" name="Author">
      <meta content="Documents-poro.ci est le premier site de commande de document en ligne." name="description">
      <meta content="document administratif, extrait de naissance Abidjan, acte de mariage Abidjan, demande d&#39;acte de naissance Abidjan,acte de décès Abidjan, demande d&#39;acte de décès Abidjan, légalisation de signature , dossier en ligne Abidjan, dossiers de concours Abidjan, côte d&#39;ivoire, ivory coast, la poste ci, la poste, poste ci, douments en ligne Abidjan, demande d&#39;acte civil Abidjan, demande d&#39;actes de justice Abidjan, déclaration de naissance, ministère de la justice ci, papiers en ligne" name="keywords">
      <meta content="@2016 Documents-poro.ci" name="copyright">
        <?php 
############################################################################################################################################

if(isset($_GET['webox']))
{
      $webox=$_GET['webox'];
if($webox==DASHBOARD)
{
    echo'  <meta content="60" http-equiv="refresh">';
}
else
{
    echo'  <meta content="180" http-equiv="refresh">';

}

}   
############################################################################################################################################

?>
     
      <meta content="0" http-equiv="Expires">
      <meta content="no-cache" http-equiv="Pragma">
      <meta content="Lumens Corp." name="organization">
      <meta content="General" name="Audience">
      <meta content="090212" name="date-revision-ddmmyyyy">
      <meta content="Global" name="Distribution">
      <meta content="never" name="expires">
      <meta content="https://www.documents-poro.ci/" name="identifier-url">
      <meta content="Document" name="Page-topic">
      <meta content="Lumens Corp." name="publisher">
      <meta content="General" name="Rating">
      <meta content="all, index, follow" name="Robots">
      <meta content="Documents-poro.ci est le premier moteur de commande de document en ligne de la Côte d&#39;Ivoire a Abidjan, Cote d&#39;Ivoire, Ivory Coast" name="subject">

      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <link href="./mvc/vues/img/logo/siaka.png" rel="icon"style="width:100%">

<title> 

<?php 
############################################################################################################################################

if(isset($_GET['webox']))
{
      $webox=$_GET['webox'];
if($webox==DASHBOARD)
{  
      echo 'TABLEAU DE BORD';

}
elseif($webox==MDP)
{  
      echo 'MOT DE PASSE';

}
elseif($webox==MOBILE)
{  
      echo 'TELEPHONE MOBILE';

}
elseif($webox==PROFIL)
{  
      echo 'PHOTO DE PROFIL';

}
elseif($webox==SIGNALER_PROBLEME)
{  
      echo 'SIGNALER UN PROBLEME';

}
elseif($webox==MES_MESSAGES_PRIVES)
{  
      echo 'MES MESSAGES PRIVES';

}
elseif($webox==MES_DEMANDES_DU_JOUR)
{  
      echo 'MES DEMANDES DU JOUR';

}
elseif($webox==MES_DEMANDES_DU_MOIS)
{  
      echo 'MES DEMANDES DU MOIS';

}
elseif($webox==MES_DEMANDES_DE_LANNEE)
{  
      echo 'MES DEMANDES DE LANNEE';

}
elseif($webox==MES_PROBLEMES_SIGNALES)
{  
      echo 'MES PROBLEMES SIGNALES';

}
elseif($webox==MES_DEMANDES_TRAITEES)
{  
      echo 'MES DEMANDES TRAITEES';

}
elseif($webox==GRILLE_TARIFAIRE)
{  
      echo 'GRILLE TARIFAIRE';

}
elseif($webox==LISTE_DES_FRAIS)
{  
      echo 'LISTE DES FRAIS';

}
elseif($webox==LISTE_DES_DEMANDES)
{  
      echo 'LISTE DES DEMANDES';

}
elseif($webox==LISTE_DES_DEMANDES_EN_ATTENTE)
{  
      echo 'PANIER';

}
elseif($webox==NAISSANCE)
{  
      echo 'ACTES DE NAISSANCE';

}
elseif($webox==NAISSANCE_TERMINE)
{  
      echo 'ACTES DE NAISSANCE';

}
elseif($webox==MARIAGE_TERMINE)
{  
      echo 'ACTES DE MARIAGE';

}
elseif($webox==LISTE_INFOS)
{  
      echo 'LISTE DES INFOS';

}
elseif($webox==NAISSANCE_PHOTO)
{  
      echo 'ACTES DE NAISSANCE';

}
elseif($webox==NAISSANCE_IDENTIQUE)
{  
      echo 'ACTES DE NAISSANCE';

}
elseif($webox==NAISSANCE_IDENTIQUE_DEUX)
{  
      echo 'ACTES DE NAISSANCE';

}
elseif($webox==NAISSANCE_IDENTIQUE_TROIS)
{  
      echo 'ACTES DE NAISSANCE';

}
elseif($webox==NAISSANCE_IDENTIQUE_QUATRE)
{  
      echo 'ACTES DE NAISSANCE';

}

elseif($webox==DECES_IDENTIQUE_DEUX)
{  
      echo 'ACTES DE DECES';

}
elseif($webox==DECES_IDENTIQUE_TROIS)
{  
      echo 'ACTES DE DECES';

}
elseif($webox==DECES_IDENTIQUE_QUATRE)
{  
      echo 'ACTES DE DECES';

}


elseif($webox==DECES_IDENTIQUE_DEUX)
{  
      echo 'ACTES DE DECES';

}
elseif($webox==DECES_IDENTIQUE_TROIS)
{  
      echo 'ACTES DE DECES';

}
elseif($webox==DECES_IDENTIQUE_QUATRE)
{  
      echo 'ACTES DE DECES';

}


elseif($webox==MARIAGE_IDENTIQUE_DEUX)
{  
      echo 'ACTES DE MARIAGE';

}
elseif($webox==MARIAGE_IDENTIQUE_TROIS)
{  
      echo 'ACTES DE MARIAGE';

}
elseif($webox==MARIAGE_IDENTIQUE_QUATRE)
{  
      echo 'ACTES DE MARIAGE';

}
elseif($webox==DECES_IDENTIQUE)
{  
      echo 'ACTES DE DECES';

}
elseif($webox==MARIAGE_IDENTIQUE)
{  
      echo 'ACTES DE MARIAGE';

}
elseif($webox==CERTIFICAT)
{  
        echo 'CERTIFICAT DE NATIONALITE';

}
elseif($webox==MARIAGE)
{  
        echo 'ACTES DE MARIAGE';

}
elseif($webox==ACTIVER_UNE_DEMANDE)
{  
        echo 'ACTIVER UNE DEMANDE';

}
elseif($webox==LISTE_DES_TARIFS)
{  
        echo 'LISTE DES TARIFS';

}
elseif($webox==ADMIN)
{  
        echo 'LISTE DES SERVICES CLIENTS';

}
elseif($webox==LISTE_DES_UTILISATEURS_CONNECTES)
{  
        echo 'UTILISATEURS CONNECTES';

}
elseif($webox==LISTE_DES_COMPTES_ACTIFS)
{  
        echo 'COMPTES ACTIFS';

}
elseif($webox==LISTE_DES_DEMANDES_RECU)
{  
        echo 'DEMANDES RECU';

}
elseif($webox==LISTE_DES_COMPTES_INACTIFS)
{  
        echo 'COMPTES INACTIFS';

}
elseif($webox==LISTE_DES_DEMANDES_JOURNALIERES)
{  
        echo 'DEMANDES JOURNALIERES';

}
elseif($webox==LISTE_DES_DEMANDES_MENSUELLES)
{  
        echo 'DEMANDES MENSUELLES';

}
elseif($webox==LISTE_DES_DEMANDES_ANNUELLES)
{  
        echo 'DEMANDES ANNUELLES';

}
elseif($webox==LISTE_DES_ACTES_DE_NAISSANCE)
{  
        echo 'LES ACTES DE NAISSANCE';

}
elseif($webox==LISTE_DES_CERTIFICATIONS_DE_DOCUMENT)
{  
        echo 'LES CERTIFICATIONS DE DOCUMENT';

}
elseif($webox==LISTE_DES_PROBLEMES_SIGNALES)
{  
        echo 'LES PROBLEMES SIGNALES';

}
elseif($webox==LISTE_DES_CERTIFICATS_DE_NATIONALITE_IVOIRIENNE)
{  
        echo 'CERTIFICATS DE NATIONALITE IVOIRIENNE';

}
elseif($webox==LISTE_DES_FEMMES)
{  
        echo 'LES FEMMES';

}
elseif($webox==LISTE_DES_ACTES_DE_MARIAGE)
{  
        echo 'LES ACTES DE MARIAGE';

}
elseif($webox==VISITEURS)
{  
        echo 'VISITEURS';

}
elseif($webox==LISTE_DES_ACTES_DE_DECES)
{  
        echo 'LES ACTES DE DECES';

}
elseif($webox==LISTE_DES_CASIERS_JUDICIAIRES)
{  
        echo 'LES CASIERS JUDICIAIRES';

}
elseif($webox==LISTE_DES_HOMMES)
{  
        echo 'LES HOMMES';

}
elseif($webox==SUPPRIMER_MA_DEMANDE)
{  
      echo 'SUPPRESSION DE DEMANDE';

}
elseif($webox==SUPPRIMER_MA_DEMANDE_RECU)
{  
      echo 'SUPPRESSION DE DEMANDE RECUE';

}
elseif($webox==SUPPR)
{  
      echo 'SUPPRESSION DU PROBLEME SIGNALE';

}
elseif($webox==DECES)
{  
        echo 'ACTES DE DECES';

}
elseif($webox==VERROU)
{  
        echo 'VERROUILLER';

}
elseif($webox==SUPPRESSION)
{  
        echo 'SUPPRIMER UTILISATEUR';

}
elseif($webox==ANNULER_ADN)
{  
        echo 'ANNULER DEMANDE';

}
elseif($webox==ANNULER_CNI)
{  
        echo 'ANNULER CNI';

}
elseif($webox==ANNULER_ADDE)
{  
        echo 'ANNULER DECES';

}
elseif($webox==ANNULER_ADM)
{  
        echo 'ANNULER DEMANDE';

}
elseif($webox==EDITER)
{  
        echo 'EDITER UN CLIENT';

}
elseif($webox==EDITER_ADN)
{  
        echo 'EDITER ACTES DE NAISSANCE';

}
elseif($webox==CONFIRMER_ADN)
{  
        echo 'CONFIRMER ACTES DE NAISSANCE';

}
elseif($webox==CONFIRMER_ADDE)
{  
        echo 'CONFIRMER ACTES DE DECES';

}
elseif($webox==CONFIRMER_CJ)
{  
        echo 'CONFIRMER CASIER JUDICIAIRE';

}
elseif($webox==CONFIRMER_CNI)
{  
        echo 'CONFIRMER CERTIFICAT DE NATIONALITE';

}
elseif($webox==CONFIRMER_ADM)
{  
        echo 'CONFIRMER ACTES DE MARIAGE';

}
elseif($webox==DEMANDE_CONFIRMEE)
{  
        echo 'DEMANDE CONFIRMEE';

}
elseif($webox==DEMANDE2_CONFIRMEE)
{  
        echo 'DEMANDE CONFIRMEE';

}
elseif($webox==DEMANDE6_CONFIRMEE)
{  
        echo 'DEMANDE CONFIRMEE';

}
elseif($webox==DEMANDE3_CONFIRMEE)
{  
        echo 'DEMANDE CONFIRMEE';

}
elseif($webox==EDITER_ADM)
{  
        echo 'EDITER ACTES DE MARIAGE';

}
elseif($webox==EDITER_ADDE)
{  
        echo 'EDITER ACTES DE DECES';

}
elseif($webox==EDITER_CJ)
{  
        echo 'EDITER CASIER JUDICIAIRE';

}
elseif($webox==CONFIRMATION_CJ)
{  
   echo 'CONFIRMATION CASIER JUDICIAIRE';

}
elseif($webox==DEMANDE3_CONFIRMEE)
{  
   echo 'DEMANDE CONFIRMEE';

}
elseif($webox==DEMANDE_CONFIRMEE)
{  
   echo 'DEMANDE CONFIRMEE';

}
elseif($webox==DEMANDE2_CONFIRMEE)
{  
   echo 'DEMANDE CONFIRMEE';

}
elseif($webox==DEMANDE5_CONFIRMEE)
{  
   echo 'DEMANDE CONFIRMEE';

}
elseif($webox==DEMANDE6_CONFIRMEE)
{  
   echo 'DEMANDE CONFIRMEE';

}
elseif($webox==CONFIRMATION_CNI)
{  
   echo 'CONFIRMATION CERTIFICAT DE NATIONALITE';

}
elseif($webox==EDITER_CNI)
{  
        echo 'EDITER CNI';

}
elseif($webox==DEVERROU)
{  
        echo 'DEVERROUILLER';

}
elseif($webox==ANNULER_CJ)
{  
        echo 'ANNULER DEMANDE';

}
elseif($webox==COMPTE)
{  
        echo 'MON COMPTE';

}
elseif($webox==LISTE_DES_UTILISATEURS)
{  
        echo 'LISTE DES UTILISATEURS';

}
elseif($webox==INFOS)
{  
        echo 'PUBLIER UNE INFORMATION';

}
elseif($webox==SEARCH)
{  
        echo 'ACTIVER UNE DEMANDE';

}
elseif($webox==SEARCH_DAY)
{  
        echo 'UN INTERVALLE DE DATE';

}
elseif($webox==TLD)
{  
  echo 'TOUTES LES DEMANDES';

}
elseif($webox==SEARCHMONTANT)
{  
        echo 'VOIR MONTANT EN CAISSE';

}
elseif($webox==SEARCHING)
{  
        echo 'RECHERCHE';

}
elseif($webox==CASIER_IDENTIQUE)
{  
        echo 'CASIER JUDICIAIRE';

}
elseif($webox==CERTIFICAT_IDENTIQUE)
{  
        echo 'CERTIFICAT DE NATIONALITE IVOIRIENNE';

}
elseif($webox==MES_ACTES_DE_NAISSANCE)
{  
        echo 'MES ACTES DE NAISSANCE';

}
elseif($webox==MES_CERTIFICATS_DE_NATIONALITE_IVOIRIENNE)
{  
        echo 'MES CERTIFICATS DE NATIONALITE IVOIRIENNE';

}
elseif($webox==MES_ACTES_DE_MARIAGE)
{  
        echo 'MES ACTES DE MARIAGE';

}
elseif($webox==MES_ACTES_DE_DECES)
{  
        echo 'MES ACTES DE DECES';

}
elseif($webox==MES_CASIERS_JUDICIAIRES)
{  
        echo 'MES CASIERS JUDICIAIRES';

}
elseif($webox==MES_CERTIFICATIONS_DE_DOCUMENT)
{  
        echo 'MES CERTIFICATS DE DOCUMENT';

}
elseif($webox==DISCUSSION_INSTANTANEE)
{  
        echo 'DISCUSSION INSTANTANEE';

}
elseif($webox==MES_DEMANDES_EXPEDIEES)
{  
        echo 'MES DEMANDES EXPEDIEES';

}
elseif($webox==CASIER)
{  
        echo 'CASIER JUDICIAIRE';

}
elseif($webox==CASIER_TERMINE)
{  
         echo 'CASIER JUDICIAIRE';

}
elseif($webox==ANNULER_PANIER2)
{  
         echo 'SUPPRIMER DEMANDE';

}
elseif($webox==SUPPR_INFO)
{  
         echo 'SUPPRIMER INFORMATION';

}
elseif($webox==LISTE_DES_FRAIS2)
{  
           echo 'FRAIS DE LIVRAISON';

}
elseif($webox==SUPPRO)
{  
         echo 'SUPPRIMER PROBLEME SIGNALE';

}
elseif($webox==DECES_TERMINE)
{  
         echo 'ACTES DE DECES';

}
elseif($webox==CERTIFICAT_TERMINE)
{  
         echo 'CERTIFICAT DE NATIONALITE IVOIRIENNE';

}

else
{
        echo 'DOCUMENT-PORO.CI';         


}
}   
############################################################################################################################################

?>
  
</title>

        <link href="./mvc/design/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
        <link href="./mvc/design/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="./mvc/design/css/ruang-admin.min.css" rel="stylesheet">
        <link href="./mvc/design/css/animate.css" rel="stylesheet">

</head>

<body oncontextmenu="return false" onkeydown="return true" onmousedown="return true" onclick="return true"id="page-top"style="background:<?php echo BODY;?>;"style="font-family: Nunito,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";font-size:2rem;min-height: 100vh;
    height: 100%;
    width: 100%;
    background: #f5f6fe;
    padding-top: 56px;
    overflow-x: hidden;">


        <div id="wrapper">
      <?php 
           if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='1'){
              include('./mvc/models/webox/menu_gauche_admin.php'); 
          }
          else
          {

              include('./mvc/models/webox/menu_gauche_users.php'); 
          }  
      ?>

        <div id="content-wrapper" class="d-flex flex-column"style="background:<?php echo BODY;?>;"> 
        <div id="content"style="background:<?php echo BODY;?>;">


       <?php 
           if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='1'){
              include('./mvc/models/webox/menu_du_haut_admin.php'); 
          }
          else
          {

              include('./mvc/models/webox/menu_du_haut_users.php'); 
          }  
      ?>

        <div class="container-fluid" id="container-wrapper"style="visibility: visible; -webkit-animation: fadeInLeft 1.1s ; ">


<?php 
############################################################################################################################################
if(isset($_GET['webox']))
{
$webox=$_GET['webox'];
        if($webox==DASHBOARD)
{  
if(isset($_SESSION['id']) AND $_SESSION['droitacces']==1){
        $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
        $donnees=$req->fetch(); 
if($req){
        include('./mvc/models/webox/dashboard.php');
        // echo "<script>window.open('dashboard.php','_self')</script>";
}
}
else
{
        include('./mvc/models/webox/dashboard_users.php');
}

}
elseif($webox==MDP)
{  
        include('./mvc/models/webox/mdp.php');

}

elseif($webox==MOBILE)
{  
        include('./mvc/models/webox/mobile.php');

}
elseif($webox==SUPPRESSION)
{  
        include('./mvc/models/webox/supprimer_utilisateurs.php');

}
elseif($webox==ANNULER_ADN)
{  
        include('./mvc/models/webox/supprimer_demande_adn.php');

}
elseif($webox==ANNULER_CJ)
{  
        include('./mvc/models/webox/supprimer_demande_cj.php');

}
elseif($webox==ANNULER_ADM)
{  
        include('./mvc/models/webox/supprimer_demande_adm.php');

}
elseif($webox==ANNULER_ADDE)
{  
        include('./mvc/models/webox/supprimer_demande_adde.php');

}
elseif($webox==ANNULER_CNI)
{  
        include('./mvc/models/webox/supprimer_demande_cni.php');

}
elseif($webox==MES_DEMANDES_TRAITEES)
{  
        include('./mvc/models/webox/mes_demandes_traitees.php');

}
elseif($webox==MES_DEMANDES_EXPEDIEES)
{  
        include('./mvc/models/webox/mes_demandes_expediees.php');

}
elseif($webox==GRILLE_TARIFAIRE)
{  
        include('./mvc/models/webox/grille_tarifaire.php');

}
elseif($webox==LISTE_DES_FRAIS)
{  
        include('./mvc/models/webox/liste_des_frais.php');

}
elseif($webox==LISTE_DES_FRAIS2)
{  
        include('./mvc/models/webox/liste_des_frais2.php');

}
elseif($webox==SIGNALER_PROBLEME)
{  
        include('./mvc/models/webox/signaler_un_probleme.php');

}
elseif($webox==MES_PROBLEMES_SIGNALES)
{  
        include('./mvc/models/webox/mes_problemes_signales.php');

}
elseif($webox==SUPPRIMER_MA_DEMANDE)
{  
        include('./mvc/models/webox/supprimer_ma_demande.php');

}
elseif($webox==SUPPRIMER_MA_DEMANDE_RECU)
{  
        include('./mvc/models/webox/supprimer_ma_demande_recu.php');

}
elseif($webox==SUPPR)
{  
        include('./mvc/models/webox/supprimer_probleme_signale.php');

}
elseif($webox==SUPPRO)
{  
        include('./mvc/models/webox/supprimer_mes_problemes_signales.php');

}
elseif($webox==SUPPR_INFO)
{  
        include('./mvc/models/webox/supprimer_information.php');

}
elseif($webox==LISTE_DES_DEMANDES)
{  
        include('./mvc/models/webox/liste_des_demandes.php');

}
elseif($webox==LISTE_DES_DEMANDES_EN_ATTENTE)
{  
   include('./mvc/models/webox/panier.php');

}
elseif($webox==ANNULER_PANIER)
{  
   include('./mvc/models/webox/annuler_panier.php');

}
elseif($webox==ANNULER_PANIER2)
{  
   include('./mvc/models/webox/annuler_panier2.php');

}
elseif($webox==TLD)
{  
   include('./mvc/models/webox/tld.php');

}
elseif($webox==LISTE_INFOS)
{  
        include('./mvc/models/webox/liste_des_informations.php');

}
elseif($webox==NAISSANCE)
{  
        include('./mvc/models/webox/actes_de_naissance.php');

}
elseif($webox==EDITER)
{  
    include('./mvc/models/webox/editer_utilisateurs.php');

}
elseif($webox==EDITER_ADN)
{  
    include('./mvc/models/webox/editer_adn.php');

}
elseif($webox==DEMANDE_CONFIRMEE)
{  
    include('./mvc/models/webox/demande_confirmee.php');

}
elseif($webox==DEMANDE2_CONFIRMEE)
{  
    include('./mvc/models/webox/demande2_confirmee.php');

}
elseif($webox==DEMANDE6_CONFIRMEE)
{  
    include('./mvc/models/webox/demande6_confirmee.php');

}
elseif($webox==DEMANDE3_CONFIRMEE)
{  
    include('./mvc/models/webox/demande3_confirmee.php');

}
elseif($webox==DEMANDE5_CONFIRMEE)
{  
    include('./mvc/models/webox/demande5_confirmee.php');

}
elseif($webox==DEMANDE6_CONFIRMEE)
{  
    include('./mvc/models/webox/demande6_confirmee.php');

}
elseif($webox==CONFIRMER_ADN)
{  
    include('./mvc/models/webox/confirmer_adn.php');

}
elseif($webox==CONFIRMER_ADM)
{  
    include('./mvc/models/webox/confirmer_adm.php');

}
elseif($webox==CONFIRMER_ADDE)
{  
    include('./mvc/models/webox/confirmer_adde.php');

}
elseif($webox==CONFIRMER_CJ)
{  
    include('./mvc/models/webox/confirmer_cj.php');

}
elseif($webox==CONFIRMATION_ADN)
{  
    include('./mvc/models/webox/confirmation_adn.php');

}
elseif($webox==CONFIRMER_CNI)
{  
    include('./mvc/models/webox/confirmer_cni.php');

}
elseif($webox==CONFIRMATION_CNI)
{  
    include('./mvc/models/webox/confirmation_cni.php');

}
elseif($webox==CONFIRMATION_ADM)
{  
    include('./mvc/models/webox/confirmation_adm.php');

}
elseif($webox==CONFIRMATION_CJ)
{  
    include('./mvc/models/webox/confirmation_cj.php');

}
elseif($webox==CONFIRMATION_ADDE)
{  
    include('./mvc/models/webox/confirmation_adde.php');

}
elseif($webox==EDITER_ADM)
{  
    include('./mvc/models/webox/editer_adm.php');

}
elseif($webox==EDITER_CJ)
{  
    include('./mvc/models/webox/editer_cj.php');

}
elseif($webox==EDITER_CNI)
{  
    include('./mvc/models/webox/editer_cni.php');

}
elseif($webox==EDITER_ADDE)
{  
    include('./mvc/models/webox/editer_adde.php');

}
elseif($webox==VERROU)
{  
        include('./mvc/models/webox/verrou.php');

}
elseif($webox==LISTE_DES_DEMANDES_RECU)
{  
        include('./mvc/models/webox/liste_des_demandes_recu.php');

}
elseif($webox==ACTIVATIOOON)
{  
        include('./mvc/models/webox/activer_demande.php');

}
elseif($webox==MES_ACTES_DE_NAISSANCE)
{  
        include('./mvc/models/webox/mes_actes_de_naissance.php');

}
elseif($webox==MES_CERTIFICATIONS_DE_DOCUMENT)
{  
        include('./mvc/models/webox/mes_certifications_de_document.php');

}
elseif($webox==MES_ACTES_DE_MARIAGE)
{  
        include('./mvc/models/webox/mes_actes_de_mariage.php');

}
elseif($webox==MES_CERTIFICATS_DE_NATIONALITE_IVOIRIENNE)
{  
        include('./mvc/models/webox/mes_certificats_de_nationalite_ivoirienne.php');

}
elseif($webox==MES_CASIERS_JUDICIAIRES)
{  
        include('./mvc/models/webox/mes_casiers_judiciaires.php');

}
elseif($webox==MES_ACTES_DE_DECES)
{  
        include('./mvc/models/webox/mes_actes_de_deces.php');

}
elseif($webox==MES_MESSAGES_PRIVES)
{  
  

        include('./mvc/models/webox/mes_messages_prives.php');

}
elseif($webox==MES_DEMANDES_DU_JOUR)
{  
  

        include('./mvc/models/webox/mes_demandes_du_jour.php');

}
elseif($webox==MES_DEMANDES_DU_MOIS)
{  
  

        include('./mvc/models/webox/mes_demandes_du_mois.php');

}
elseif($webox==MES_DEMANDES_DE_LANNEE)
{  
  

        include('./mvc/models/webox/mes_demandes_de_lannee.php');

}
elseif($webox==SUPPRESSIOON)
{  
        include('./mvc/models/webox/supprimer_demande.php');

}
elseif($webox==DEVERROU)
{  
        include('./mvc/models/webox/deverrou.php');

}
elseif($webox==LISTE_DES_DEMANDES_EXPEDIEES)
{  
        include('./mvc/models/webox/liste_des_demandes_expediees.php');

}

elseif($webox==ACTIVATIOON)
{  
        include('./mvc/models/webox/activation_du_compte.php');

}
elseif($webox==LISTE_DES_UTILISATEURS)
{  
        include('./mvc/models/webox/liste_des_utilisateurs.php');

}
elseif($webox==ADMIN)
{  
        include('./mvc/models/webox/liste_des_admin.php');

}
elseif($webox==LISTE_DES_UTILISATEURS_CONNECTES)
{  
        include('./mvc/models/webox/liste_des_utilisateurs_connectes.php');

}
elseif($webox==DISCUSSION_INSTANTANEE)
{  
        include('./mvc/models/webox/champs_de_saisi_de_message.php');

}
elseif($webox==LISTE_DES_CERTIFICATS_DE_NATIONALITE_IVOIRIENNE)
{  
        include('./mvc/models/webox/liste_des_certificats_de_nationalite_ivoirienne.php');

}
elseif($webox==LISTE_DES_FEMMES)
{  
        include('./mvc/models/webox/liste_des_femmes.php');

}
elseif($webox==LISTE_DES_CASIERS_JUDICIAIRES)
{  
        include('./mvc/models/webox/liste_des_casiers_judiciaires.php');

}
elseif($webox==LISTE_DES_HOMMES)
{  
        include('./mvc/models/webox/liste_des_hommes.php');

}
elseif($webox==LISTE_DES_CERTIFICATIONS_DE_DOCUMENT)
{  
        include('./mvc/models/webox/liste_des_certifications_de_document.php');

}
elseif($webox==LISTE_DES_PROBLEMES_SIGNALES)
{  
        include('./mvc/models/webox/liste_des_problemes_signales.php');

}
elseif($webox==LISTE_DES_COMPTES_ACTIFS)
{  
        include('./mvc/models/webox/liste_des_comptes_actifs.php');

}
elseif($webox==LISTE_DES_COMPTES_INACTIFS)
{  
        include('./mvc/models/webox/liste_des_comptes_inactifs.php');

}
elseif($webox==LISTE_DES_DEMANDES_JOURNALIERES)
{  
        include('./mvc/models/webox/liste_des_demandes_journalieres.php');

}
elseif($webox==LISTE_DES_DEMANDES_MENSUELLES)
{  
        include('./mvc/models/webox/liste_des_demandes_mensuelles.php');

}
elseif($webox==LISTE_DES_DEMANDES_ANNUELLES)
{  
        include('./mvc/models/webox/liste_des_demandes_annuelles.php');

}
elseif($webox==LISTE_DES_ACTES_DE_NAISSANCE)
{  
        include('./mvc/models/webox/liste_des_actes_de_naissance.php');

}
elseif($webox==INFOS)
{  
        include('./mvc/models/webox/information.php');

}
elseif($webox==LISTE_DES_ACTES_DE_MARIAGE)
{  
        include('./mvc/models/webox/liste_des_actes_de_mariage.php');

}
elseif($webox==LISTE_DES_ACTES_DE_DECES)
{  
        include('./mvc/models/webox/liste_des_actes_de_deces.php');

}
elseif($webox==NAISSANCE_PHOTO)
{  
        include('./mvc/models/webox/photo_extrait.php');

}
elseif($webox==NAISSANCE_IDENTIQUE)
{  
        include('./mvc/models/webox/extrait_info_identique.php');

}
elseif($webox==NAISSANCE_IDENTIQUE_DEUX)
{  
        include('./mvc/models/webox/extrait_info_identique_deux.php');

}
elseif($webox==NAISSANCE_IDENTIQUE_TROIS)
{  
        include('./mvc/models/webox/extrait_info_identique_trois.php');

}
elseif($webox==NAISSANCE_IDENTIQUE_QUATRE)
{  
        include('./mvc/models/webox/extrait_info_identique_quatre.php');

}



elseif($webox==CASIER_IDENTIQUE_DEUX)
{  
        include('./mvc/models/webox/casier_info_identique_deux.php');

}
elseif($webox==CASIER_IDENTIQUE_TROIS)
{  
        include('./mvc/models/webox/casier_info_identique_trois.php');

}
elseif($webox==CASIER_IDENTIQUE_QUATRE)
{  
        include('./mvc/models/webox/casier_info_identique_quatre.php');

}


elseif($webox==DECES_IDENTIQUE_DEUX)
{  
        include('./mvc/models/webox/deces_info_identique_deux.php');

}
elseif($webox==DECES_IDENTIQUE_TROIS)
{  
        include('./mvc/models/webox/deces_info_identique_trois.php');

}
elseif($webox==DECES_IDENTIQUE_QUATRE)
{  
        include('./mvc/models/webox/deces_info_identique_quatre.php');

}



elseif($webox==CERTIFICAT_IDENTIQUE_DEUX)
{  
        include('./mvc/models/webox/certificat_info_identique_deux.php');

}
elseif($webox==CERTIFICAT_IDENTIQUE_TROIS)
{  
        include('./mvc/models/webox/certificat_info_identique_trois.php');

}
elseif($webox==CERTIFICAT_IDENTIQUE_QUATRE)
{  
        include('./mvc/models/webox/certificat_info_identique_quatre.php');

}




elseif($webox==MARIAGE_IDENTIQUE_DEUX)
{  
        include('./mvc/models/webox/mariage_info_identique_deux.php');

}
elseif($webox==MARIAGE_IDENTIQUE_TROIS)
{  
        include('./mvc/models/webox/mariage_info_identique_trois.php');

}
elseif($webox==MARIAGE_IDENTIQUE_QUATRE)
{  
        include('./mvc/models/webox/mariage_info_identique_quatre.php');

}
elseif($webox==CERTIFICAT_IDENTIQUE)
{  
        include('./mvc/models/webox/certificats_info_identique.php');

}
elseif($webox==CERTIFICAT_TERMINE)
{  
        include('./mvc/models/webox/certificats_termine.php');

}
elseif($webox==VISITEURS)
{  
        include('./mvc/models/webox/visiteurs.php');

}
elseif($webox==CASIER_IDENTIQUE)
{  
        include('./mvc/models/webox/casier_info_identique.php');

}
elseif($webox==MARIAGE_IDENTIQUE)
{  
        include('./mvc/models/webox/mariage_info_identique.php');

}
elseif($webox==DECES_IDENTIQUE)
{  
        include('./mvc/models/webox/deces_info_identique.php');

}
elseif($webox==NAISSANCE_TERMINE)
{  
        include('./mvc/models/webox/extrait_termine.php');

}
elseif($webox==CASIER_TERMINE)
{  
        include('./mvc/models/webox/casier_termine.php');

}
elseif($webox==DECES_TERMINE)
{  
        include('./mvc/models/webox/deces_termine.php');

}
elseif($webox==MARIAGE_TERMINE)
{  
        include('./mvc/models/webox/mariage_termine.php');

}
elseif($webox==ACTIVER_UNE_DEMANDE)
{  
        include('./mvc/models/webox/activer_une_demande.php');

}
elseif($webox==PROFIL)
{  
        include('./mvc/models/webox/photo_de_profil.php');

}
elseif($webox==MARIAGE)
{  
        include('./mvc/models/webox/actes_de_mariage.php');

} 
elseif($webox==CASIER)
{  
        include('./mvc/models/webox/casier_judiciaire.php');

}
elseif($webox==LISTE_DES_TARIFS)
{  
        include('./mvc/models/webox/liste_des_tarifs.php');

}
elseif($webox==DECES)
{  
        include('./mvc/models/webox/actes_de_deces.php');

}
elseif($webox==CERTIFICAT)
{  
        include('./mvc/models/webox/certificat_de_nationalite.php');

}

elseif($webox==COMPTE)
{  
        include('./mvc/models/webox/compte.php');

}
elseif($webox==SEARCH)
{  
        include('./mvc/models/webox/search.php');

}
elseif($webox==SEARCH_DAY)
{  
        include('./mvc/models/webox/search_day.php');

}
elseif($webox==SEARCHMONTANT)
{  
        include('./mvc/models/webox/searchmontant.php');

}
elseif($webox==SEARCHING)
{  
     if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='1'){
                include('./mvc/models/webox/searching.php');
          }
          else
          {

               include('./mvc/models/webox/searching_users.php');
          }  
   
      

}
else
{
// sleep(1);
echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="'.URL.'goodoo.php?webox='.DASHBOARD.'"</SCRIPT>';          


}
}   
############################################################################################################################################
?>





</div>
<!---Container Fluid-->
</div>

<!-- Footer -->
<br>   
<?php  include('./mvc/models/webox/footer_profil.php');  ?>

<!-- Footer -->
</div>
</div>

  <!-- Scroll to top -->

<?php  //include('./mvc/models/webox/image_du_bas.php');  ?>

<!-- Scroll to top -->

 <script type="text/JavaScript">
var clignotement = function(){ 
if (document.getElementById('DivClignotante24').style.visibility=='visible'){ 
document.getElementById('DivClignotante24').style.visibility='hidden'; 
} 
else{ 
document.getElementById('DivClignotante24').style.visibility='visible'; 
} 
}; 
periode = setInterval(clignotement, 80);

</script>
<a class="scroll-to-top" href="#page-top"style="border-radius:60%">
<i class="fas fa-angle-up"id="DivClignotante24"></i>
</a>




  <script src="./mvc/design/vendor/jquery/jquery.min.js"></script>
  <script src="./mvc/design/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="./mvc/design/vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="./mvc/design/js/ruang-admin.min.js"></script>
  <script src="./mvc/design/vendor/chart.js/Chart.min.js"></script>
  <script src="./mvc/design/js/demo/chart-area-demo.js"></script>  
</body>

</html>
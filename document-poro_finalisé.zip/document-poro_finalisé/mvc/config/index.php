						
<script type='text/Javascript'>
window.location='../index.php' ;

</script>							
<?php

		
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;">  <i class="fas fa-fw fa-bell fa-1x "style="color:<?php echo TITRE;?>"></i> Notifications</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Notifications</li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->



          <!-- Row -->
         


                 <?php



                //echo $code_client;
                //$reponse=$bdd->query("SELECT*FROM probleme  ORDER BY type  DESC limit 0,10000 ");
                
               //$reponse=$bdd->query("SELECT*FROM probleme ORDER BY dateenvoi  ASC LIMIT 0, 10000000");


                     $droitacces=2;
                  $categorie='Actes de Mariage';
                
                  $reponse=$bdd->query(" 
                  SELECT 
                  users.code,
                  users.nomprenoms,
                  users.mobile,
                  users.photo,
                  users.droitacces,
                  users.email,

                  probleme.code,
            
                  probleme.idp,
                  probleme.dateenvoi,
                  probleme.heureenvoi,
                   probleme.niveau,
                  probleme.commentaire
                 
                  FROM users, probleme WHERE users.code=probleme.code AND users.droitacces='".$droitacces."'   ORDER BY probleme.idp  DESC LIMIT 0, 10000000");
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                  if (count($res) == 0) 
                {

                 /* echo '<script type="text/javascript"> alert(\'     DESOLE  . AUCUNS RESULTAT TROUVES      \');</script>';

                   echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>'; */

                    echo' 

                          <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">LISTE DES NOTIFICATIONS :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                        ';
                
                            include('./mvc/models/webox/oops.php');

                }
                else {
                echo'
                 <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                <div class="table-responsive condensed">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">LISTE DES NOTIFICATIONS :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                </div>
                 <table class="table  table-sm mb-0 table-hover table-condensed">

                    <thead style="color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
                      <tr>
                        <th>Photo</th>
                      
                        <th>Identifiant </th>
                        <th>Nom</th>
                        <th><centere>Date</center> </th>

                        <th>Heure </th>
                        <th>Objet  </th>
                        <th>Messages</th>
                       <th></th>

                      </tr>
                    </thead>

                   

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody id="myInput">
                     
                      
                      <tr>
                          <td>';
                       
                        if(empty($donnees['photo'])) {
                        echo'<img  src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;height:20px;width:20px">';
                        }
                        else
                        {
                        echo'<img  src="./mvc/vues/img/photo/users/'.$donnees['photo'].'" style="border-radius:100%;height:20px;width:20px">';
                        }

                        
                     echo'</td>

                      
                  <td>'.$donnees['code'].'</td>

                  <td title='.$donnees['nomprenoms'].'><centere>'.substr($donnees['nomprenoms'],0,15).' </center></td>

                  <td title='.$donnees['dateenvoi'].'>'.substr($donnees['dateenvoi'],0,20).'</td>

                  <!----><td title='.$donnees['heureenvoi'].'>'.substr($donnees['heureenvoi'],0,5).'</td>

                  <td title='.$donnees['niveau'].'><b style="color:orange">'.substr($donnees['niveau'],0,40).'</b></td>

                        
                        <td><centere>
                        '.nl2br($donnees['commentaire']).'
                        </center></td>

                          <td><small><a href="./goodoo.php?webox='.SUPPR.'&idp='.$donnees['idp'].'"onclick="return confirm(\'êtes vous sûre de supprimer le probleme signalé n°  '.$donnees['idp'].' ?\');" data-toggle="tooltip" data-placement="top" title="SUPPRESSION" data-original-title="Supprimer"><font color="white"><i class="fa fa-trash"style="color:red;"></i></b></a></font></small></center></td>
                         </tr>
                     
              
            </tbody>';
                     }

                echo'</table>';
          }
          
          ?>
  </div>   </div>  </div>  </div>   <br> 



            


            
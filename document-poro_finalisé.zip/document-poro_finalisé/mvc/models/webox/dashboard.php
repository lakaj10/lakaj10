
<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-name:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-tachometer-alt "style="color:<?php echo TITRE;?>"></i> Tableau de Bord </h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Tableau de bord</li>
            </ol>
          </div>



    <?php 
$session_time=7200;    
$expire = intval(time() - $session_time);
//echo $expire.' </br>atn5snd974s9j99sogqf3o70f7';

$expire2 =time();
//echo $expire2;
       if(isset($_GET['tokken']))
       {
        $tokken=$_GET['tokken'];
       if($tokken==TOKKEN)
        {  
         
       /* echo'<div class="alert alert-success alert-dismissible progress-bar progress-bar-striped progress-bar-animated bg-success" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                    <centere> BIENVENUE <b> '.strtoupper($_SESSION['nomprenoms']).' . </b> </center>
                  </div>
<META HTTP-EQUIV="refresh" CONTENT="2; URL=./goodoo.php?webox='.DASHBOARD.'">
                  ';*/

                         
        }
        else
        {

        }
      }
      ?>



          <div class="row mb-3"style="visibility: visible; -webkit-animation: fadeInLeft 2.9s ; ">
              
           
           
                <div class="col-xl-3 col-md-6 mb-4"title="UTILISATEURS INSCRITS">
              <div class="card h-100">

               <a  href="./goodoo.php?webox=<?php echo LISTE_DES_UTILISATEURS;?>"style="text-decoration:none;color:#757575"> <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Utilisateurs</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                        <?php 
                          $reponse=$bdd->query("SELECT COUNT(*) AS id  FROM users WHERE droitacces='2'"); 
                          while($donnees = $reponse ->fetch()){
                          echo'<span style="color:'.BOUTOND.'">'.$donnees['id'].'</span> ';
                          } 
                          $reponse->closeCursor();
                         ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-users fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
                <div class="col-xl-3 col-md-6 mb-4"title="UTILISATEURS EN LIGNE">
              <div class="card h-100">
                 <a  href="./goodoo.php?webox=<?php echo LISTE_DES_UTILISATEURS_CONNECTES;?>"style="text-decoration:none;color:#757575"> 
                  <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Connectés</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                         <?php 
                           $connectes=1;    
                          $reponse=$bdd->query('SELECT COUNT(*) AS nbre_entrees  FROM users WHERE connectes="'.$connectes.'" AND droitacces="2"');
                           while($donnees = $reponse ->fetch()){
                              echo'<span style="color:'.BOUTOND.'">'.$donnees['nbre_entrees'].'</span>';
                          } 
                          $reponse->closeCursor();
                       ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-signal fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
            
                <div class="col-xl-3 col-md-6 mb-4"title="LISTE DES UTILISATEURS HOMMES">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo LISTE_DES_HOMMES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Hommes</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                         <?php                   
                  
                    $sexe='H';
                    $reponse=$bdd->query("SELECT COUNT(*) AS id FROM users WHERE sexe='".$sexe."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['id'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-male fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>

                <div class="col-xl-3 col-md-6 mb-4"title="LISTE DES UTILISATEURS FEMMES">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo LISTE_DES_FEMMES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Femmes</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                         <?php                   
                  
                     $sexe='F';
                    $reponse=$bdd->query("SELECT COUNT(*) AS id FROM users WHERE sexe='".$sexe."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['id'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-female fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
          
                <div class="col-xl-3 col-md-6 mb-4"title="COMPTES ACTIFS">
              <div class="card h-100">
         <a  href="./goodoo.php?webox=<?php echo LISTE_DES_COMPTES_ACTIFS;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Comptes actifs</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                        <?php 
                           $activer=1;    
                          $reponse=$bdd->query('SELECT COUNT(*) AS nbre_entrees  FROM users WHERE activer="'.$activer.'" AND droitacces="2"');
                           while($donnees = $reponse ->fetch()){
                              echo'<span style="color:'.BOUTOND.'">'.$donnees['nbre_entrees'].'</span>';
                          } 
                          $reponse->closeCursor();
                       ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-primary mr-2"><i class="fas fa-arrow-down"></i> 1.10%</span>
                        <span>Since yesterday</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-unlock fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>




                <div class="col-xl-3 col-md-6 mb-4"title="COMPTES INACTIFS">
              <div class="card h-100">
              <a  href="./goodoo.php?webox=<?php echo LISTE_DES_COMPTES_INACTIFS;?>"style="text-decoration:none;color:#757575"> 
                  <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Comptes Inactifs</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                        
                        <?php 
                         $activer=0;    
                          $reponse=$bdd->query('SELECT COUNT(*) AS nbre_entrees  FROM users WHERE activer="'.$activer.'" AND droitacces="2"');
                           while($donnees = $reponse ->fetch()){
                              echo'<span style="color:'.BOUTOND.'">'.$donnees['nbre_entrees'].'</span>';
                          } 
                          $reponse->closeCursor();
                       ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 20.4%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-lock fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>






          
                <div class="col-xl-3 col-md-6 mb-4"title="DEMANDES JOURNALIERES">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo LISTE_DES_DEMANDES_JOURNALIERES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Demandes du jour </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                    <?php
                    $date=getdate();
                    $joura=date('d');
                    $moisa=date('m');
                    $anneea=date('Y');
                    $datedujour=$joura.'/'.$moisa.'/'.$anneea;
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE jour='".$datedujour."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>

                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar-check fa-2x"style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
                <div class="col-xl-3 col-md-6 mb-4"title="DEMANDES MENSUELLES">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo LISTE_DES_DEMANDES_MENSUELLES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Demandes du mois</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                        <?php
                    $date=getdate();
                    
                    $moisa=date('m');
                    
                    $mois=$moisa;
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE mois='".$mois."'");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
                <div class="col-xl-3 col-md-6 mb-4"title="DEMANDES ANNUELLES">
              <div class="card h-100">
              <a  href="./goodoo.php?webox=<?php echo LISTE_DES_DEMANDES_ANNUELLES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Demandes de l'année</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                        
                        <?php
                    $date=getdate();
                   
                    $anneea=date('Y');
                    $annee=$anneea;
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE annee='".$annee."'");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 20.4%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar-plus fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
           













                <div class="col-xl-3 col-md-6 mb-4"title="ACTES DE NAISSANCE ">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo LISTE_DES_ACTES_DE_NAISSANCE;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Actes de naissance</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                         <?php                   
                  
                    $categorie='Actes de Naissance';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-paste fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
            <!-- Earnings (Annual) Card Example -->
                <div class="col-xl-3 col-md-6 mb-4"title="ACTES DE MARIAGE ">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo LISTE_DES_ACTES_DE_MARIAGE;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Actes de mariage</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                        <?php                   
                  
                    $categorie='Actes de Mariage';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-venus-double fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
                <div class="col-xl-3 col-md-6 mb-4"title="ACTES DE DECES ">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo LISTE_DES_ACTES_DE_DECES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Actes de décès</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                        <?php                   
                  
                    $categorie='Actes de Décès';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 20.4%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-ambulance fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
            <!-- Pending Requests Card Example -->
                <div class="col-xl-3 col-md-6 mb-4"title="CERTIFICATION DE DOCUMENT ">
              <div class="card h-100">
           <a  href="./goodoo.php?webox=<?php echo LISTE_DES_CERTIFICATIONS_DE_DOCUMENT;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Certifications de document</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                         <?php                   
                  
                    $categorie='Certification de Document';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>

                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-primary mr-2"><i class="fas fa-arrow-down"></i> 1.10%</span>
                        <span>Since yesterday</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-file-pdf fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>

 







            <!-- Earnings (Annual) Card Example -->
                <div class="col-xl-3 col-md-6 mb-4"title="CERTIFICAT DE NATIONALITE IVOIRIENNE ">
          <a  href="./goodoo.php?webox=<?php echo LISTE_DES_CERTIFICATS_DE_NATIONALITE_IVOIRIENNE;?>"style="text-decoration:none;color:#757575"> 

              <div class="card h-100">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Certificat de Nationalité </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                         <?php                   
                  
                    $categorie='Certificat de Nationalite Ivoirienne';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-flag fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
            <!-- New User Card Example -->
        
            <!-- Pending Requests Card Example -->
                <div class="col-xl-3 col-md-6 mb-4"title="CASIER JUDICIAIRE ">
              <div class="card h-100">
            <a  href="./goodoo.php?webox=<?php echo LISTE_DES_CASIERS_JUDICIAIRES;?>"style="text-decoration:none;color:#757575"> 
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Casiers Judiciaires</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                          <?php                   
                  
                    $categorie='Casiers Judiciaires';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-primary mr-2"><i class="fas fa-arrow-down"></i> 1.10%</span>
                        <span>Since yesterday</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-folder-open fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>



            <!-- Earnings (Monthly) Card Example -->
                <div class="col-xl-3 col-md-6 mb-4"title="PROBLEMES SIGNALES ">
              <div class="card h-100">
                 <a  href="./goodoo.php?webox=<?php echo LISTE_DES_PROBLEMES_SIGNALES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">NOTIFICATIONS</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                         <?php                   
                  
                    $categorie='Légalisation de Document';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idp FROM probleme ");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idp'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-bell fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>


<br>   <br>   <br>   




        
               <!-- Earnings (Monthly) Card Example -->
           
           








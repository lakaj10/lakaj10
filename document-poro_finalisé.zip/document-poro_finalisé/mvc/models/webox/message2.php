

       <div class="modal fade" id="BIEN" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
       <div class="modal-content"style="background:;border-color:">
             <!-- --> <div class="modal-header"style="color:<?php echo COULEUR;?>;  background:<?php echo CONTENUU;?>;border-bottom: 0.0rem solid <?php echo COULEUR;?> ;border-right:0px solid #eee">
         
              <center>    <a  href="./woodoo.php?webox=<?php echo OUVERTURE;?>"title="ACCEUEIL"style="text-decoration:none;"> 
  <!--<i class="fa fa-file-pdf fa-spina fa-2x"style="color:#fc544b;font-size:60px"id="DivClignotantesiakaa"></i><br><br>
   <img src="./mvc/vues/img/logo/coco.png" style=" height:60px;width:60px" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI">-->
  <span style="font-weight:bolder;
font-size:30px;color:<?php echo COULEUR;?>;text-decoration:none;font-family: mistral">D</span><span style="font-weight:bolder;
font-size:30px;color:<?php echo GAUCHE;?>;text-decoration:none;font-family: mistral">P</span> 
  </a>  Bienvenue sur la plateforme du guichet électronique </b></center>
            
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>  
          
          <div class="modal-body">
          Maintenant, dans la REGION DU PORO il est facile de commander ses documents administratifs à distance sans se déplacer grâce à la plateforme adopter par les autorités local . Pour aider les utilisateurs à avoir ses documents dans tout le pays ou qu'ils se trouvent . Cette interface est facile à utiliser avec des formulaires en ligne à renseigner pour effectuer la demande  <hr>  <center> <i class="fas fa-phone"></i> Mobile :  0709071389 &nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-envelope"></i> Email : info@document-poro.ci </center> 
          </div>
         
        
        </div>
      </div>
    </div>
    
    </div>

    <script>
  $(document).ready(function () {
    $("#BIEN").modal('show');
  });
//made by csandreas1 for Stackoverflow
</script>





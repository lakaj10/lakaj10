
<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;">  <i class="fas fa-fw fa-eye fa-1x "style="color:<?php echo TITRE;?>"></i> Edition de la demande</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Edition de la demande</li>
            </ol>
          </div> 







          <!-- BreadCrumb -->

 
    <div class="row"data-wow-delay="0.4s" style="visibility: visible; -webkit-animation: zoomInss 0.4s;">

<?php
  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   

   $reponse=$bdd->query(" 
SELECT

users.code,
users.nomprenoms,
users.mobile,
users.photo,
users.email,

  demandes_adm.idm,
  demandes_adm.coded,
  demandes_adm.codeu,
  demandes_adm.type,
  demandes_adm.categorie,
  demandes_adm.paiement,
  demandes_adm.datepaiement,
  demandes_adm.statut,
  demandes_adm.datestatut,
  demandes_adm.jour,
  demandes_adm.mois,
  demandes_adm.annee,
  demandes_adm.pu,
  demandes_adm.nbrecopie,
  demandes_adm.montant,
  demandes_adm.fre,
  demandes_adm.mode,
  demandes_adm.commune,
  demandes_adm.frc,
  demandes_adm.quartier,
  demandes_adm.frq,

    demandes_adm.nomepoux,
  demandes_adm.nomepouse,

  demandes_adm.filiation,
  demandes_adm.nomprenom,
  demandes_adm.numcni,
  demandes_adm.lieudemande,
  demandes_adm.villelivrai,
  demandes_adm.adressedom,
  demandes_adm.solde,
  demandes_adm.quartier

FROM demandes_adm,users WHERE users.code=demandes_adm.codeu AND demandes_adm.coded='".$identifiant_demande."' ORDER BY demandes_adm.idm  DESC LIMIT 0, 1");


//$reponse=$bdd->query("SELECT * FROM membres WHERE codeuser ='".$_SESSION['code']."'ORDER BY id ASC limit 0,1000");
$nb_resultats = $reponse->rowCount(); 
$res = $reponse->fetchAll();
if (count($res) == 0) 
{
  echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.MARIAGE.'"</SCRIPT>'; 


}
else {
foreach ($res as $donnees) {
echo '
        <div class="col-sm-12">
      
    <!-- End Breadcrumb-->
      <div class="card">
          <div class="card-body">
                  <!-- Content Header (Page header) -->
                  <section class="content-header">
                   
                      <h3 style="font-family:arial;color:orange"> '.ucfirst($donnees['categorie']).'</h3>
                  </section>

                  <!-- Main content -->
                  <section class="invoice">
                    <!-- title row -->
                    <div class="row mt-3">
                      <div class="col-lg-6">
                       <h4>
                      Réference : 
                      <small style="font-family:arial black;color:#66bb6a">'.ucwords($donnees['coded']).'</small>
                    </h4>
                      </div>
            <div class="col-lg-6">
             <h6 class="float-sm-right">Généré le : ';
$date=getdate();
$generation=date('d/m/Y');
echo $generation;
echo'</h6>
            </div>
                    </div>
          
          <hr class="colorgraph" style=" height:8px;
          border-top: 0;
          background:'.BODY3.';
          border-radius: 0px;">
                    <div class="row invoice-info">
                      <div class="col-sm-3 invoice-col">

                        De :
                        <address>
                         <strong>'.strtoupper($donnees['nomprenoms']).'</strong><br>
                          
                          Mobile: (+225) '.ucfirst($donnees['mobile']).'<br>
                          Email: '.substr($donnees['email'],0,26).' <br>
                              Statut de la demande : <b style="text-transform:;color:skyblue">'.substr($donnees['statut'],0,15).'</b>
                        </address>
                      </div><!-- /.col -->

                       <div class="col-sm-3 invoice-col">
                        <b style="color:red"></b>
                        <br>
                         Filiation du demandeur : <b style="text-transform:uppercase;color:#999;">'.strtoupper($donnees['filiation']).'</b><br>
                        Nom & prenoms : <b style="text-transform:uppercase;color:#999;"title="'.strtoupper(substr($donnees['nomprenom'],0,100)).'">'.strtoupper(substr($donnees['nomprenom'],0,15)).'</b><br>
                        Numéro de la CNI : <b style="text-transform:uppercase;color:#999;">'.strtoupper($donnees['numcni']).'</b><br>
                       Nom & prenoms époux :  <b style="text-transform:uppercase;color:#999;">'.strtoupper(substr($donnees['nomepoux'],0,15)).'</b><br>
                      </div><!-- /.col -->

                       <div class="col-sm-3 invoice-col">
                        <b></b>
                        <br>
                       Nom & prenoms épouse :  <b style="text-transform:uppercase;color:#999;">'.strtoupper(substr($donnees['nomepouse'],0,15)).'</b><br>
                        Lieu de la demande : <b style="text-transform:uppercase;color:#999;">'.substr($donnees['lieudemande'],0,12).'</b><br>
                        Ville d\'expédition :</b> <b style="text-transform:uppercase;color:#999;">'.substr($donnees['villelivrai'],0,12).'</b><br>
                        Commune de la ville : <b style="text-transform:uppercase;color:#999;">'.strtoupper(substr($donnees['commune'],0,26)).'</b><br>
                      </div><!-- /.col -->

                      <div class="col-sm-3 invoice-col">
                        <b></b>
                        <br>
                        
                        Adresse du Domicile : <b style="text-transform:uppercase;color:#999;">'.substr($donnees['adressedom'],0,13).'</b><br>
                        Quartier : <b style="text-transform:uppercase;color:#999;">'.substr($donnees['quartier'],0,12).'</b><br>
                        Mode de livraison : <b style="text-transform:;color:skyblue">'.substr($donnees['mode'],0,25).'</b><br>
                        Type de demande : <b style="text-transform:;color:orange">'.substr($donnees['type'],0,25).'</b><br><br>
                      </div><!-- /.col -->
                    </div><!-- /.row -->

                    <!-- Table row -->
                    
                <hr class="colorgraph" style=" height:8px;
                border-top: 0;
                background:'.BODY3.';
                border-radius: 0px;">  
                 
                 <section class="invoice">
                    <!-- title row -->
                    <div class="row mt-3">
                      <div class="col-lg-6">
                       <h5>
                      N° de facture : 
                      <small style="font-family:arial black;color:red">#000'.ucfirst($donnees['idm']).'</small>
                    </h5>
                      </div>
            <div class="col-lg-6">
             <h6 class="float-sm-right">Date de la demande : ';

echo ucfirst($donnees['jour']);
echo'</h6>
            </div>
                    </div>                
              

                  <hr class="colorgraph" style=" height:8px;
                border-top: 0;
                background:'.BODY3.';
                border-radius: 0px;">                  
                <section class="content-header">


<div class="table-responsive condensed">
<table id="example" class="table table-striped  table-sm mb-0 table-hover table-condensed" id="dataTables-example"data-wow-delay="0.2s" style="visibility: visible; -webkit-animation: fadeInLeftBigss 0.2s;">
<thead style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
<tr>
 
<th><center>Extrait</center></th> 
<th><center>Frais . d\'expé.</center></th>
<th><center>Frais à Domi .</center></th>
<th><center>Frais Quartier .</center></th>
<th><center>Prix unitaire</center></th> 
<!-- --><th><center>Copies</center></th> 
<th><center>Montant partiel</center></th> 
<th><center>Montant final</center></th> 
<th><center>Reglé</center></th> 


</tr> 
</thead>

<tbody><tr>

<td><center>';
if(empty($donnees['photo'])) {
  echo'<img  src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;height:20px;width:20px">';
  }
  else
  {
  echo'<img  src="./mvc/vues/img/photo/users/'.$donnees['photo'].'" style="border-radius:100%;height:20px;width:20px">';
  }

echo'</b></center></td>
<td><center>'.ucfirst($donnees['fre']).'</b></center></td>
<td><center>'.ucfirst($donnees['frc']).'</b></center></td>
<td><center>'.ucfirst($donnees['frq']).'</b></center></td>
<td><center>'.ucfirst($donnees['pu']).' </b></center></td>
<td><center>'.ucfirst($donnees['nbrecopie']).'</b></center></td>
<td><center>'.ucfirst($donnees['montant']).' </b></center></td>
<td><center><b>';echo $donnees['solde'];echo' </b></center></td>

<td><center>';
if($donnees['paiement']=='1')
{
echo'<b style="color:orange">Oui</b>';
}
else
{
echo'<b style="color:blue">Non</b>';
}


echo'</center></td>




';
}


echo'</tr></a></tbody></table>
                      </div><!-- /.col -->
                    <!-- /.row -->



                    
                    <!-- /.row -->

                    <!-- this row will not appear when printing -->
              <hr class="colorgraph" style=" height:8px;
              border-top: 0;
              background:'.BODY3.';
              border-radius: 0px;">

              

          
                  </section><!-- /.content -->
          </div>
      </div>

    </div>

';
}}


?>









    </div>    </div></div>
<br>














          <!-- BreadCrumb -->

 
    <div class="row"data-wow-delay="0.4s" style="visibility: visible; -webkit-animation: zoomInss 0.4s;">

<?php
  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   

   $reponse=$bdd->query("SELECT*FROM demandes WHERE coded='".$identifiant_demande."'");

$nb_resultats = $reponse->rowCount(); 
$res = $reponse->fetchAll();
if (count($res) == 0) 
{
 // echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.MARIAGE.'"</SCRIPT>'; 


}
else {
foreach ($res as $donnees) {

}
}
}


?>









    </div>    </div></div>
<br>


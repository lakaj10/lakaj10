

       <div class="modal fade" id="DECONNEXION" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content"style="background:transparent;border:1px solid white;border-color:white">
             <!--  <div class="modal-header"style="color:<?php //echo COULEURT;?>;  background:<?php //echo BOUTON;?>;border-bottom: 0.0rem solid <?php //echo COULEUR;?> ;border-right:0px solid #eee">
         
              <center>     <i class="fas fa-check-circle fa-sm fa-fw mr-2 text-gray-4"></i>activation du compte éffectuée avec succès</b></center>
            
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>  -->
          
          <div class="modal-body">
           

       
                  <?php 
  if(isset($_GET['Identifiant']) AND !empty($_GET['Identifiant']))
  {
    $Identifiant=htmlspecialchars($_GET['Identifiant']);   

    $reponse=$bdd->query('SELECT * FROM users WHERE code="'.$Identifiant.'"');
    $res = $reponse->fetchAll();
    if(count($res) == 0) 
    {   echo '<b><script type="text/javascript"> alert(\'------------------ Le lien utilisé est erroné ------------------- .\');</script></b>';
        echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./woodoo.php?webox='.REGISTER.'"</SCRIPT>'; 

    }
    else
    {

    if($res) 
        {
           $date=getdate();

        $joura=date('d');
        $moisa=date('m');
        $anneea=date('Y');

        $hour=date('H');
        $min=date('i');
        $sec=date('s');

        $dateact=$joura.'/'.$moisa.'/'.$anneea;
        $heureact=$hour.':'.$min.':'.$sec;
        $activer=1 ;
        $bdd->exec("UPDATE users SET activer='".$activer."', dateact='".$dateact."',heureact='".$heureact."' WHERE code='".$Identifiant."'");
    
        $Identifiant=htmlspecialchars($_GET['Identifiant']);
        $reponse=$bdd->query('SELECT * FROM users WHERE code="'.$Identifiant.'"');
        $nb_resultats = $reponse->rowCount(); 
        $res = $reponse->fetchAll();

 foreach ($res as $donnees) {

                 $nom=substr($donnees['nomprenoms'],0,23);
                 $email=substr($donnees['email'],0,27);
                 echo'<span style="color:white">';
                  if($donnees['sexe']=="F"){
                      echo'<img class="rounded-circle" src="./mvc/vues/img/logo/girl.png"  style="max-width: 30px;height:30px"> Mme / Mlle';
                     }
                      elseif($donnees['sexe']=='H'){
                      echo'<img class="rounded-circle" src="./mvc/vues/img/logo/boy.png"  style="max-width: 30px;height:30px"> Mr';
                      }

                echo' </span>&nbsp;   <b style="color:orange;font-family:arial black">'.$nom.' .</b>  <hr style=" height:6px;background:'.BODY3.';font-size:20px"><span style="color:white"><i class="fas fa-envelope fa-fw fa-spina"></i> votre compte a  été activé avec succès . Voici vos accès : </span></small>
                   <hr style=" height:6px;background:'.BODY3.';font-size:20px"> <span style="color:white"><i class="fas fa-user-circle fa-fw fa-spina"></i> Identifiant  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :</span> &nbsp;
                   <b style="color:#ffa">'.$donnees['code'].'&nbsp;&nbsp;&nbsp; </b>
                   <br> <span style="color:white"><i class="fas fa-user fa-fw fa-spina"></i> Nom utilisateur &nbsp; :</span> &nbsp;
                   <b style="color:#ffa">'.$donnees['pseudo'].'</b>
                   <br> <span style="color:white"><i class="fas fa-lock fa-fw fa-spina"></i> Mot de passe &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: </span>&nbsp;
                   <b style="color:#ffa">'.$donnees['mdpcrypte'].'</b>&nbsp;&nbsp;&nbsp;
                   <hr style=" height:6px;background:'.BODY3.';font-size:20px"> 
                   </small>';
 

        }
        } }}
         
        else
        {
        sleep(1);
        echo '<b><script type="text/javascript"> alert(\'Le lien pour activer le compte membre est erroné .\');</script></b>';
                echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./woodoo.php?webox='.REGISTER.'"</SCRIPT>'; 

        echo "Erreur ! Votre compte ne peut être activé...";
       }
   

   ?>

  

          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>
  $(document).ready(function () {
    $("#DECONNEXION").modal();
  });
//made by csandreas1 for Stackoverflow
</script>





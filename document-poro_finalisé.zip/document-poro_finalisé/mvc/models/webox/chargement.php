


 <?php
############################################################################################################################################
if(empty($_SESSION['pseudo']))
{
############################################################################################################################################
   echo'<center><img src="./mvc/vues/img/logo/loading.gif" style=" height:auto;width:auto" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI"style="padding-top: .9rem 1rem;font-size:100px">
</center><META HTTP-EQUIV="refresh" CONTENT="200; URL=./goodoo.php?webox='.DASHBORD.'">';

}
else
{ 
   echo'<center><img src="./mvc/vues/img/logo/loading.gif" style=" height:auto;width:auto" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI"style="padding-top: .9rem 1rem;font-size:100px">
</center><META HTTP-EQUIV="refresh" CONTENT="200; URL=./goodoo.php?webox='.DASHBORD.'">';
}


      
;  ?>

 








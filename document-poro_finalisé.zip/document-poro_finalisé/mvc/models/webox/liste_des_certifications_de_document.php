<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;">  <i class="fas fa-fw fa-file-pdf fa-1x "style="color:<?php echo TITRE;?>"></i> Certifications de document</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Certifications de document</li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->


            
              <?php



                //echo $code_client;
                //$reponse=$bdd->query("SELECT*FROM demandes  ORDER BY type  DESC limit 0,10000 ");
                
                     $droitacces=2;
                  $categorie='Certification de Document';
                
                     $reponse=$bdd->query(" 
                    SELECT
                  users.code,
                  users.nomprenoms,
                  users.mobile,
                  users.photo,
                  users.droitacces,
                  users.email,

                  demandes.idd,
                  demandes.coded,
                  demandes.codeu,
                  demandes.type,
                  demandes.categorie,
                  demandes.paiement,
                  demandes.datepaiement,
                  demandes.statut,
                  demandes.datestatut,
                  demandes.jour,
                  demandes.mois,
                  demandes.annee,
                  demandes.pu,
                  demandes.nbrecopie,
                  demandes.solde
                 
                  FROM users, demandes WHERE users.code=demandes.codeu AND users.droitacces='".$droitacces."' AND demandes.categorie='".$categorie."'  ORDER BY users.nomprenoms  DESC LIMIT 0, 10000000");
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                  if (count($res) == 0) 
                {

                 /* echo '<script type="text/javascript"> alert(\'     DESOLE  . AUCUNS RESULTAT TROUVES      \');</script>';

                   echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>'; */

                    echo' 

                          <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">LISTE DES CERTIFICATIONS DE DOCUMENT :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                     ';
                
                            include('./mvc/models/webox/oops.php');

                }
                else {
                echo'
                 <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                <div class="table-responsive condensed">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">LISTE DES CERTIFICATIONS DE DOCUMENT :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                </div>
                 <table class="table  table-hover table-condensed">

                    <thead>
                      <tr>
                        <th>Avatar</th>
                      
                        <th>Reference </th>
                        <th>Nom & prénoms</th>
                        <th><centere>Adresse email</center> </th>

                        <th>Mobile </th>
                        <th>Demande  </th>
                        <th>Payé</th>
                        <th>Statut</th>
                        <th>Qté   </th>
                        <th>Montant</th>
                       

                      </tr>
                    </thead>

              

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody id="myInput">
                     
                      
                      <tr>
                          <td>';
                       
                        if(empty($donnees['photo'])) {
                        echo'<img  src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;height:20px;width:20px">';
                        }
                        else
                        {
                        echo'<img  src="./mvc/vues/img/photo/users/'.$donnees['photo'].'" style="border-radius:100%;height:20px;width:20px">';
                        }

                        
                     echo'</td>

                      
                         <td>'.$donnees['coded'].'</td>
                        <td title='.$donnees['nomprenoms'].'><centere>'.substr($donnees['nomprenoms'],0,15).' </center></td>
                        <td title='.$donnees['email'].'>'.substr($donnees['email'],0,20).'</td>
                          <!----><td title='.$donnees['mobile'].'>'.substr($donnees['mobile'],0,10).'</td>
                                 <td title='.$donnees['categorie'].'><b style="color:orange">'.substr($donnees['categorie'],0,20).'</b></td>
                        
                        <td><center>';
                        if($donnees['paiement']=='1')
                        {
                          echo'<b style="color:orange">Oui</b>';
                        }
                        else
                        {
                          echo'Non';
                        }
                      
                        echo'</center></td>
                         <td >';
                        if($donnees['statut']=='')
                        {
                          echo'<b style="color:blue">Demande reçu </b>';
                        }
                        else
                        {
                           echo'<b style="color:orange">'.substr($donnees['statut'],0,15).' </b>';
                        }
                      
                      
                        echo'</td>
                          <td>'.$donnees['nbrecopie'].'</td>

                         <td >'.$donnees['montant'].'</td>
                        

                         </tr>
                         </tr>
                     
              
            </tbody>';
                     }

                echo'</table>';
          }
          
          ?>
  </div>   </div>  </div>  </div>   <br> 

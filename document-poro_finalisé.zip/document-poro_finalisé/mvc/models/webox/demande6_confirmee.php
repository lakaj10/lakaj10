

<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-check-circle fa-1x "style="color:<?php echo TITRE;?>"></i>Demande Confirmée</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Demande Confirmée</li>
            </ol>
          </div>
  
<?php

  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   
               $reponse=$bdd->query("SELECT*FROM demandes_cni WHERE coded='".$identifiant_demande."' ORDER BY idcni  DESC LIMIT 0, 1");


              $nb_resultats = $reponse->rowCount(); 
              $res = $reponse->fetchAll();
              if (count($res) == 0) 
              {   
              echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
              //echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE.'"</SCRIPT>'; 

              }
              else
              {
              foreach ($res as $donnees) {

                  $bdd->exec(" DELETE FROM demandes_cni_tmp WHERE idcni = ".$donnees['idcni']);
                               
                    
                              echo '

 <div class="row">


            <div class="col-lg-12">
              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.20)!important;background-color:white">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                 
                              <div class="col-lg-12"><div class="alert alert-success alert-dismissible" role="alert">
                   
                    <center>     <i class="fas fa-fw fa-barcode"></i>CODE <b> : '.ucfirst($donnees['coded']).' </b> &nbsp; &nbsp;|&nbsp; &nbsp;      <i class="fas fa-fw fa-shopping-cart"></i> SOMME A PAYER  <b> : '.ucfirst($donnees['solde']).' F</b> &nbsp; &nbsp;|&nbsp; &nbsp;      <i class="fas fa-fw fa-truck"></i> MODE  <b> : '.strtoupper($donnees['mode']).' </b> </center>
                  </div>';
                    include('./mvc/models/webox/paiement.php');
                    echo'<center>
                          
                      <a target="_blank" href="./printfichier.php?webox='.PRINT_CNI.'&identifiant_demande='.$donnees['coded'].'"  class="btn btn-primary btn-sm waves-effect waves-light ">    IMPRIMER LA FICHE  DE DEMANDE
                      </a> 
                      </center> ';
                                }

                                           


              }
              }
              
              
?>


</div></div></div></div></div>




<?php
  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   

   $reponse=$bdd->query("SELECT*FROM demandes WHERE coded='".$identifiant_demande."'");

$nb_resultats = $reponse->rowCount(); 
$res = $reponse->fetchAll();
if (count($res) == 0) 
{
 // echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CERTIFICAT.'"</SCRIPT>'; 


}

}


?>













        














































































































































<nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top"style="background:<?php echo COULEUR;?>;border-bottom: 0.0rem solid #66bb6a;box-shadow: 0 0.15rem 1.75rem 0 rgb(58 59 69 / 10%) !important;">
          <button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3"style="background:<?php echo COULEUR;?>">
            <i class="fa fa-bars fa-spina"style="color:<?php echo VALIDER;?>"></i>
          </button>

          <ul class="navbar-nav ml-auto">
             <?php 
              /*$droitacces=2;
                                $reponse=$bdd->query('SELECT*FROM users where droitacces="'.$droitacces.'" ORDER By nomprenoms ASC limit 0, 10000000');

                                $nb_resultats = $reponse->rowCount(); 
                                $res = $reponse->fetchAll();
                                if (count($res) == 0) 
                                {
                                echo'

                                ';

                                }
                                else {
                                echo'<select type="number" class="form-control "autocomplete="on"name="SearchBrowserData"aria-label="Search" aria-describedby="basic-addon2" onFocus="this.placeholder="Patient"onmouseover="this.placeholder="Entrez le mot clé de la demandeé"onMouseout="this.placeholder=" Entrez le mot(s) clé(s)...">' ;
                                foreach ($res as $donnees) {
                                echo ' <option value="'.$donnees['nomprenoms'].'">'.$donnees['code'].'  --  '.$donnees['nomprenoms'].'</option> <br>';
                                }
                                 }
                                echo'</select>';
                                */ 
             ##############################################################################################################################################################

          echo'<li class="nav-item dropdown no-arrow show">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"title="RECHERCHE FILTREE">
                <i class="fas fa-search fa-fw fa-spina"style="color:'.ICON2.'"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                 <form class="navbar-search"action="./goodoo.php?webox='.SEARCHING.'" method="GET"autocomplete="off">
                        <input type="hidden"  name="webox"value="'.SEARCHING.'">
                  <div class="input-group">
                <input type="text" id="coding_language" maxlength="10" name="SearchBrowserData" class="form-control bg-light border-1 small" placeholder="Recherche filtrée sur un client..."style="border-color:#ffa426;font-family:arial;color:silver;text-transform:uppercase"required>
                    <div class="input-group-append">
                      <button class="btn btn-warning progress-bar progress-bar-striped progress-bar-animated badge-warning bg-warning" type="submit"value="search">
                        <i class="fas fa-search fa-sm"style="color:"></i> 
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>


          ';
             
              ##############################################################################################################################
                  
              ?>




 <?php 
     ############################################################################################################################
  ?>
            <li class="nav-item dropdown no-arrow mx-1">
        <a href="./goodoo.php?webox=<?php echo LISTE_DES_PROBLEMES_SIGNALES;?>" class="nav-link dropdown-toggle"title="MESSAGES RECUS" >
             
                    <?php 
                          $dateenvoi=date("d/m/Y"); 
                          $reponse=$bdd->query('SELECT * FROM probleme WHERE dateenvoi="'.$dateenvoi.'"');
                          $nb_resultats = $reponse->rowCount(); 
                          //echo $nb_resultats;
                          if($nb_resultats==0)
                          {
                          echo'<i class="fas fa-bell fa-fw"style="color:'.ICON2.'"></i>';
                          }
                          elseif($nb_resultats>0 && $nb_resultats<=9)
                          {
                           echo'<i class="fas fa-bell fa-fw"style="color:'.ICON2.'"></i>
                           <span class="badge badge-info badge-counter">'.$nb_resultats.'</span>
                           ';  
                          }
                          elseif($nb_resultats>10)
                          {
                           echo'<i class="fas fa-bell fa-fw"style="color:'.ICON2.'"></i>
                           <span class="badge badge-info badge-counter">9+</span>
                           ';  
                          }
                       ?>
            
              </a>
             
            </li>


























   <li class="nav-item dropdown no-arrow mx-1">
        <a href="./goodoo.php?webox=<?php echo LISTE_DES_DEMANDES_EN_ATTENTE;?>" class="nav-link dropdown-toggle"title="DEMANDES EN ATTENTE" >
             
                    <?php 
                           $categorie='Demande recu';$jour=date("d/m/Y"); 
                       $paiement=0; 
                          $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE statut='".$categorie."' AND paiement='".$paiement."' AND jour='".$jour."'");
                          $nb_resultats = $reponse->rowCount(); 

                          while($donnees = $reponse ->fetch()){
                    echo'<i class="fas fa-shopping-cart fa-fw"style="color:'.ICON2.'"id="Siaka"></i>
                           <span class="badge badge-danger badge-counter">'.$donnees['idd'].'</span>
                           ';
                    } $reponse->closeCursor();
                       ?>
            
              </a>
             
            </li>










































































































































   <?php 
     ############################################################################################################################
  ?>
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle"title="UTILISATEURS CONNECTES" href="javascript:{}" id="messagesDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
             
                    <?php 
                          $connectes=1;
                               $droitacces=2;   
                          $reponse=$bdd->query('SELECT * FROM users  WHERE connectes="'.$connectes.'" AND droitacces="'.$droitacces.'"');
                          $nb_resultats = $reponse->rowCount(); 
                          //echo $nb_resultats;
                          if($nb_resultats==0)
                          {
                          echo'<i class="fas fa-signal fa-fw"style="color:'.ICON2.'"></i>';
                          }
                          elseif($nb_resultats>0 && $nb_resultats<=9)
                          {
                           echo'<i class="fas fa-signal fa-fw"style="color:'.ICON2.'"></i>
                           <span class="badge badge-primary badge-counter">'.$nb_resultats.'</span>
                           ';  
                          }
                          elseif($nb_resultats>10)
                          {
                           echo'<i class="fas fa-signal fa-fw"style="color:'.ICON2.'"></i>
                           <span class="badge badge-primary badge-counter">9+</span>
                           ';  
                          }
                       ?>
            
              </a>
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="messagesDropdown">

                     <?php 
                          $connectes=1;
                          $droitacces=2;   
                          $reponse=$bdd->query('SELECT * FROM users  WHERE connectes="'.$connectes.'" AND droitacces="'.$droitacces.'"');
                          $nb_resultats = $reponse->rowCount(); 
                          //echo $nb_resultats;
                          if($nb_resultats==0)
                          {
                          //echo'<i class="fas fa-users fa-fw"></i>';
                          }
                          elseif($nb_resultats==1)
                          {
                            echo'<h6 class="dropdown-header"style="background:'.BODY.';border-color:'.BODY.';color:white">
                            Connecté
                            </h6>';
                               $connectes=1;
                            $droitacces=2;
                          $reponse1=$bdd->query('SELECT * FROM users   WHERE connectes="'.$connectes.'"AND droitacces="'.$droitacces.'" ORDER BY heurec ASC limit 0,1  ');
                            $res1 = $reponse1->fetchAll();
                            foreach ($res1 as $donnees) {

                            
                            echo'<a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">';
                              if(empty($donnees['photo'])) {
                              echo'<img class="rounded-circle" src="./mvc/vues/img/logo/boy.png"  style="max-width: 60px">';
                              }
                              else
                              {
                              echo'<img class="rounded-circle" src="./mvc/vues/img/photo/users/'.$donnees['photo'].'"  style="max-width: 60px">';
                              }
                           
                            echo'<div class="status-indicator bg-success"></div>
                            </div>
                            <div>
                            <div class="text-truncate">'.$donnees['nomprenoms'].'</div>
                            <div class=" text-gray-500">'.$donnees['datec'].' · '.$donnees['heurec'].'</div>
                            </div>
                            </a>
                           
                           ';  
                          }
                          }
                          

                           else
                          {

                            echo'<h6 class="dropdown-header"style="background:'.BODY.';border-color:'.BODY.';color:white">
                             Connéctes
                            </h6>';
                            $droitacces=2;
                          $reponse1=$bdd->query('SELECT * FROM users  where droitacces="'.$droitacces.'" ORDER BY heurec ASC limit 0,1  ');
                            $res1 = $reponse1->fetchAll();
                            foreach ($res1 as $donnees) {

                            
                            echo'<a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">';
                              if(empty($donnees['photo'])) {
                              echo'<img class="rounded-circle" src="./mvc/vues/img/logo/boy.png"  style="max-width: 60px">';
                              }
                              else
                              {
                              echo'<img class="rounded-circle" src="./mvc/vues/img/photo/users/'.$donnees['photo'].'"  style="max-width: 60px">';
                              }
                           
                            echo'<div class="status-indicator bg-success"></div>
                            </div>
                            <div>
                            <div class="text-truncate">'.$donnees['nomprenoms'].'</div>
                            <div class=" text-gray-500">'.$donnees['datec'].' · '.$donnees['heurec'].'</div>
                            </div>
                            </a>
                                 
                           ';  
                          }
                          echo'  <a class="dropdown-item text-center small text-gray-500" href="./goodoo.php?webox='.LISTE_DES_UTILISATEURS_CONNECTES.'">Voir tous les utilisateurs </a>';
                        }
                          
                          
                       ?>
                
              </div>
            </li>
















































 <?php 
     ############################################################################################################################
  ?>
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" title="DOCUMENTS EXPEDIES" href="javascript:{}" id="messagesDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
             
                    <?php 
                          $statut="Expédiée";
                          $reponse=$bdd->query('SELECT * FROM demandes  WHERE statut="'.$statut.'"');
                          $nb_resultats = $reponse->rowCount(); 
                          //echo $nb_resultats;
                          if($nb_resultats==0)
                          {
                          echo'<i class="fas fa-truck fa-fw"style="color:'.ICON2.'"></i>';
                          }
                          elseif($nb_resultats>0 && $nb_resultats<=9)
                          {
                           echo'<i class="fas fa-truck fa-fw"style="color:'.ICON2.'"></i>
                           <span class="badge badge-success badge-counter">'.$nb_resultats.'</span>
                           ';  
                          }
                          elseif($nb_resultats>10)
                          {
                           echo'<i class="fas fa-truck fa-fw"style="color:'.ICON2.'"></i>
                           <span class="badge badge-success badge-counter">9+</span>
                           ';  
                          }
                       ?>
            
              </a>
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="messagesDropdown">

                     <?php 
                         $statut="Expédiée";
                          $reponse=$bdd->query('SELECT * FROM demandes  WHERE statut="'.$statut.'"');
                          $nb_resultats = $reponse->rowCount(); 
                          //echo $nb_resultats;
                          if($nb_resultats==0)
                          {
                          //echo'<i class="fas fa-users fa-fw"></i>';
                          }
                          elseif($nb_resultats==1)
                          {
                            echo'<h6 class="dropdown-header"style="background:'.BODY.';border-color:'.BODY.'">
                            Demande expédiée
                            </h6>';
                            $statut="Expédiée";
                            $reponse1=$bdd->query('SELECT * FROM demandes  WHERE statut="'.$statut.'" ORDER BY idd ASC limit 0,1 ');
                            $res1 = $reponse1->fetchAll();
                            foreach ($res1 as $donnees) {

                            echo'<a class="dropdown-item d-flex align-items-center" href="./goodoo.php?webox='.SEARCH.'&SearchBrowserData='.$donnees['coded'].'">
                            <div class="mr-3">
                            <div class="icon-circle bg-default"style="background:'.BODY.'">
                            <i class="fas fa-file-pdf text-danger"></i>
                            </div>
                            </div>
                            <div>
                            <div class="small text-gray-500">Envoyée le '.$donnees['datestatut'].'</div>
                            REFERENCE : <b>'.$donnees['coded'].'</b>
                            </div>
                            </a>';
                          }
                          }
                          

                           else
                          {

                            echo'<h6 class="dropdown-header"style="background:'.BODY.';border-color:'.BODY.'">
                             demandes expédiées
                            </h6>';
                            $droitacces=2;
                          $reponse1=$bdd->query('SELECT * FROM demandes  WHERE statut="'.$statut.'" ORDER BY idd DESC limit 0,3  ');
                            $res1 = $reponse1->fetchAll();
                            foreach ($res1 as $donnees) {

                            
                            echo'<a class="dropdown-item d-flex align-items-center" href="./goodoo.php?webox='.SEARCH.'&SearchBrowserData='.$donnees['coded'].'">
                            <div class="mr-3">
                            <div class="icon-circle bg-default"style="background:'.BODY.'">
                            <i class="fas fa-file-pdf text-danger"></i>
                            </div>
                            </div>
                            <div>
                            <div class="small text-gray-500">Envoyée le '.$donnees['datestatut'].'</div>
                            REFERENCE : <b>'.$donnees['coded'].'</b>
                            </div>
                            </a>';
                          }
                          echo'  <a class="dropdown-item text-center small text-gray-500" href="./goodoo.php?webox='.LISTE_DES_DEMANDES_EXPEDIEES.'">Toutes les demandes expédiées</a>';
                        }
                          
                          
                       ?>
                
              </div>
            </li>




            <div class="topbar-divider d-none d-sm-block"></div>




            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">

                <?php 
                ############################################################################################################################

                  if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='1'){
                    $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                    $donnees=$req->fetch(); 
                    if($req){
                        if(empty($donnees['photo'])) {
                    echo'<img class="img-profile" src="./mvc/vues/img/logo/avatar.png" style="border-radius:100%;max-width: 60px;height:30px;width:30px">';
                }
                else
                {
                       echo'<img class="img-profile" src="./mvc/vues/img/photo/admin/'.$donnees['photo'].'" style="border-radius:100%;max-width: 60px;height:30px;width:30px">';
                }
                 
                        }
                     }
      
          
                  
                   ?>
                 <span class="ml-2 d-none d-lg-inline text-white small"> 
                  <?php 
                  if(isset($_SESSION['id'])){
                    $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                    $donnees=$req->fetch(); 
                    if($req){
                      echo '<b style="color:#ff9900;font-family:verdana">'.strtoupper(substr($_SESSION['pseudo'],0,6)).'  </b>';
                  }
                  }
                  ##############################################################################################################################################################
                   ?>

     


                
            
                     
                   </span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                
                 <a class="dropdown-item" href="#">
                  <i class="fas fa-user-circle fa-sm fa-fw mr-2 text-gray-400"></i>
                 <?php 
                  if(isset($_SESSION['id'])){
                    $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                    $donnees=$req->fetch(); 
                    if($req){
                      echo '<b style="color:#ff9900;">'.strtoupper(substr($_SESSION['nomprenoms'],0,20)).'  </b>';
                  }
                  }
                  ##############################################################################################################################################################
                   ?>
                </a>

                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#COMPTE" id="#modalCenter"title="COMPTE <?php echo strtoupper($_SESSION['compte']);?>">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Mon compte
                </a>
                <a class="dropdown-item" href="./goodoo.php?webox=<?php echo MDP;?>">
                  <i class="fas fa-lock fa-sm fa-fw mr-2 text-gray-400"></i>
                  Mot de passe
                </a>

                 <a class="dropdown-item" href="./goodoo.php?webox=<?php echo MOBILE;?>">
                  <i class="fas fa-phone fa-sm fa-fw mr-2 text-gray-400"></i>
                  Téléphone mobile
                </a>

                 <a class="dropdown-item" href="./goodoo.php?webox=<?php echo PROFIL;?>">
                  <i class="fas fa-camera fa-sm fa-fw mr-2 text-gray-400"></i>
                  Photo de profil
                </a>

                 <div class="dropdown-divider"></div>

                  <a class="dropdown-item" data-toggle="modal" data-target="#DEMANDE" id="#modalCenter">
                  <i class="fas fa-paste fa-sm fa-fw mr-2 text-gray-400"></i>
                Activer une demande
                </a>

                 <a class="dropdown-item" data-toggle="modal" data-target="#INTERVALLE" id="#modalCenter">
                  <i class="fas fa-search fa-sm fa-fw mr-2 text-gray-400"></i>
                 Rechercher dans un intervalle 
                </a>

                 <div class="dropdown-divider"></div>

                  <a class="dropdown-item" href="./goodoo.php?webox=<?php echo LISTE_DES_ACTES_DE_NAISSANCE;?>">
                  <i class="fas fa-paste fa-sm fa-fw mr-2 text-gray-400"></i>
                 Actes de naissance
                </a>

                 <a class="dropdown-item" href="./goodoo.php?webox=<?php echo LISTE_DES_ACTES_DE_MARIAGE;?>">
                  <i class="fas fa-venus-double fa-sm fa-fw mr-2 text-gray-400"></i>
                 Actes de mariage
                </a>

                 <a class="dropdown-item" href="./goodoo.php?webox=<?php echo LISTE_DES_ACTES_DE_DECES;?>">
                  <i class="fas fa-ambulance fa-sm fa-fw mr-2 text-gray-400"></i>
                  Actes de décès
                </a>

                <a class="dropdown-item" href="./goodoo.php?webox=<?php echo LISTE_DES_CERTIFICATIONS_DE_DOCUMENT;?>">
                  <i class="fas fa-file-pdf fa-sm fa-fw mr-2 text-gray-400"></i>
                  Certifications de Document
                </a>

                 <a class="dropdown-item" href="./goodoo.php?webox=<?php echo LISTE_DES_CASIERS_JUDICIAIRES;?>">
                  <i class="fas fa-folder-open fa-sm fa-fw mr-2 text-gray-400"></i>
                  Casiers Judiciaires
                </a>

                 <a class="dropdown-item" href="./goodoo.php?webox=<?php echo LISTE_DES_CERTIFICATS_DE_NATIONALITE_IVOIRIENNE;?>">
                  <i class="fas fa-flag fa-sm fa-fw mr-2 text-gray-400"></i>
                 Certificats de Nationalité
                </a>

                  <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="./goodoo.php?webox=<?php echo TLD;?>">
                  <i class="fas fa-tags fa-sm fa-fw mr-2 text-gray-400"></i>
                 Toutes les demandes confondues
                </a>

                 <a class="dropdown-item" href="./goodoo.php?webox=<?php echo INFOS;?>">
                  <i class="fas fa-bullhorn fa-sm fa-fw mr-2 text-gray-400"></i>
                  Infos :  <?php                   
                  
                    $reponse=$bdd->query("SELECT COUNT(*) AS nbre_entrees FROM infosvue");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['nbre_entrees'].' vue(s)';
                    } $reponse->closeCursor();

                    ?>
                </a>
                
                <a class="dropdown-item" href="./goodoo.php?webox=<?php echo LISTE_INFOS;?>">
                  <i class="fas fa-th fa-sm fa-fw mr-2 text-gray-400"></i>
                  Liste des infos 
                </a>
               
                <div class="dropdown-divider"></div>
                
                
                <a class="dropdown-item" data-toggle="modal" data-target="#DECONNEXION" id="#modalCenter">
                  <i class="fas fa-power-off fa-sm fa-fw mr-2 text-gray-400"></i>
                  Deconnexion
                </a>
              </div>
            </li>
          </ul>
        </nav>




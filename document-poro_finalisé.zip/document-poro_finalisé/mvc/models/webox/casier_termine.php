

<?php

  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   
               $reponse=$bdd->query("SELECT*FROM demandes_cj_tmp WHERE coded='".$identifiant_demande."' ORDER BY idcj  DESC LIMIT 0, 1");


              $nb_resultats = $reponse->rowCount(); 
              $res = $reponse->fetchAll();
              if (count($res) == 0) 
              {   
              echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
              //echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE.'"</SCRIPT>'; 

              }
              else
              {
              foreach ($res as $donnees) {

                $req = $bdd->prepare('SELECT 1 FROM demandes_cj WHERE coded="'.$identifiant_demande.'"');
                          $req->execute(array('coded'=>$donnees['coded']));
                          $nb_resultats_recherche=$req->fetch();

                              if(!$nb_resultats_recherche)
                              {
                              $solde=$donnees['montant']+$donnees['fre']+$donnees['frc']+$donnees['frq'];
                                  $bdd->exec("UPDATE demandes_cj_tmp SET solde='".$solde."' WHERE  coded='".$donnees['coded']."'");
                              
                                if($req)
                                {
                                 //$bdd->exec(" DELETE FROM demandes_tmp WHERE idd = ".$donnees['idd']);
                                 echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CONFIRMER_CJ.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>'; 
                                }

                              }
                              else 
                              {
                              echo '<b><script type="text/javascript"> alert(\'Votre demande a deja été pris en compte . redirection sur les details \');</script></b>';
                              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.EDITER_CJ.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>';

                              }                


              }
              }
              }
              
?>



</div></div></div></div></div>

















        
             
      

























































































































































 <?php 


$idd=htmlspecialchars($_GET["idd"]) ;
if(empty($idd))
{
	echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.TLD.'"</SCRIPT>';

}
elseif(isset($idd))
{

$idd=htmlspecialchars($_GET["idd"]) ;

$bdd->exec(" DELETE FROM demandes WHERE idd = ".$idd);


if($bdd)
{
	
	echo '<script type="text/javascript"> alert(\'           Opération éffectuée avec succès          \');</script>';

echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.TLD.'"</SCRIPT>';
}


}
else
{
	echo("echoué") ;
}

?>





<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-list fa-1x "style="color:<?php echo TITRE;?>"></i> Les frais d'expéditions</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="pType Demande"> Les frais d'expéditions</li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->



          <!-- Row -->
          <div class="row">
            <!-- Datatables -->
            <div class="col-lg-12">
              <div class="card mb-4">

                
                 <?php

                //echo $code_client;
                /**/$reponse=$bdd->query("SELECT*FROM frais  ORDER BY ville  ASC limit 0,100000 ");

                
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                if (count($res) == 0) 
                {
                    echo'    

                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">LISTE DES FRAIS D\'EXPEDITION :&nbsp;<b style="color:red">'.strtoupper($_GET['SearchBrowserData']).'  ( '.$nb_resultats.' ) </b></h6>
                        ';
                
                            include('./mvc/models/webox/oops.php');
               

                  }
                else {
                echo'


                <div class="table-responsive table-condensed">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="visibility: visible; -webkit-animation: bounce 8.9s ; ">
                  <h6 class="m-0 font-weight-bold text-primary"> LISTE DES FRAIS D\'EXPEDITION :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                </div>
                 <table class="table  table-sm mb-0 table-hover table-condensed">

                              <thead style="color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
                      <tr>
                        <th>ID</th>
                         <th><center>Code</center> </th>
                        
                        <th><centere>Ville</center></th>
                       
                        <th><center>Frais  </center></th>
                      </tr>
                    </thead>

                 

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody>
                     
                      
                      <tr>
                        <td>#00'.$donnees['idf'].'</td>
                       <td><center>'.$donnees['code'].'</span></center>
                        </td> 
                        <td><centere><span style="text-transform:uppercase;font-weight:bolder;color:orange">'.strtoupper($donnees['ville']).'</span></center></td>
                        <td ><center>'.$donnees['montant'].'</span></center>
                        </td> 
                      </tr>
                     
              
            </tbody>';
                     }

                echo'</table>';
          }
          ?>
        </div>   </div>  </div>  </div>   <br> <br> 
             


































            
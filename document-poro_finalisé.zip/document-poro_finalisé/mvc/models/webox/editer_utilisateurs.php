
<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
            <h1 class="h3 mb-0 "style="color:<?php echo TITRE;?>;font-weight:bolder;">  <i class="fas fa-fw fa-eye fa-1x "style="color:<?php echo TITRE;?>"></i> Editer un client</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Editer un client</li>
            </ol>
          </div> 




<?php
  if(isset($_GET['id']) AND !empty($_GET['id']))
  {
    $id=htmlspecialchars($_GET['id']);   

    $reponse=$bdd->query('SELECT * FROM users WHERE id="'.$id.'"');
    $res = $reponse->fetchAll();
    if(count($res) == 0) 
    { 
 echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.LISTE_DES_UTILISATEURS.'"</SCRIPT>'; 
    }
    else
    {

    if($res) 
        {
 foreach ($res as $donnees) {
           echo 
' 

        <div class="col-sm-12">
      
    <!-- End Breadcrumb-->
      <div class="card">
          <div class="card-body">
                  <!-- Content Header (Page header) -->
                  <section class="content-header">
                   
                      <h5 style="font-family:arial;color:silver;font-weight:bolder"> '.substr($donnees['nomprenoms'],0,10).'</h5>
                  </section>

                  <!-- Main content -->
                  <section class="invoice">
                    <!-- title row -->
                    <div class="row mt-3">
                      <div class="col-lg-6">
                       <h4><centere>
                     ';
                        if(empty($donnees['photo'])) {
                        echo'<img class="img-profile" src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;max-width:100px;height:70px;width:70px">';
                        }
                        else
                        {
                        echo'<img class="img-profile" src="./mvc/vues/img/photo/users/'.$donnees['photo'].'" style="border-radius:100%;max-width:100px;height:70px;width:70px">';
                        }


                      echo'
                    </center></h4>
                      </div>
            <div class="col-lg-6">
             <h6 class="float-sm-right">AGE : ';
$annee1=substr($donnees['dn'],6,20);
$annee2=date("Y");
$age=$annee2-$annee1;
echo '<b style="text-transform:uppercase;color:red">'.$age.'&nbsp;ANS </b>';
echo'</h6>
            </div>
                    </div>
          <hr class="colorgraph" style=" height:8px;
          border-top: 0;
          background:'.BODY3.';
          border-radius: 0px;">
                    <div class="row invoice-info">
                      <div class="col-sm-3 invoice-col">
                        De
                        <address>
                         <strong>'.ucfirst($donnees['nomprenoms']).'</strong><br>
                          
                          Phone: (+225) '.ucfirst($donnees['mobile']).'<br>
                          Email: '.substr($donnees['email'],0,26).'...
                        </address>
                      </div><!-- /.col -->

                       <div class="col-sm-3 invoice-col">
                        <b></b>
                        <br>
                        Compte : <b style="text-transform:uppercase">'.strtoupper($donnees['compte']).'</b><br>
                       
                        Identifiant :  <b style="text-transform:uppercase">'.substr($donnees['code'],0,12).'</b><br>
                         Mot de passe :</b> <b style="text-transform:uppercase">'.substr($donnees['mdpcrypte'],0,12).'</b><br>
                      </div><!-- /.col -->

                       <div class="col-sm-3 invoice-col">
                        <b></b>
                        <br>
                         Date de naissance : <b style="text-transform:uppercase">'.strtoupper($donnees['dn']).'</b><br>
                     Date d\'inscription :  <b style="text-transform:uppercase">'.substr($donnees['dateins'],0,12).'</b><br>
                        Date d\'activation : <b style="text-transform:uppercase">'.substr($donnees['dateact'],0,12).'</b><br>
                       
                      </div><!-- /.col -->

                      <div class="col-sm-3 invoice-col">
                        <b></b>
                        <br>
                        
                        Nom utilisateur : <b style="text-transform:uppercase">'.substr($donnees['pseudo'],0,13).'</b><br>
                        Dernière connexion : <b style="text-transform:uppercase">'.substr($donnees['datec'],0,12).'</b><br>
                        Statut en ligne : <b style="text-transform:;color:skyblue">';
                        if($donnees['connectes']=='1')
                          {
                            echo'<b style="color:orange">Connecté</span></b>';
                          }
                          else
                          {
                          echo'<b style="color:blue">Deconnecté</b>';
                          }
                        
                          echo'</b>
                      </div><!-- /.col -->
                    </div>
                      <!-- /.col -->
                    <!-- /.row -->



                    
                    <!-- /.row -->

                    <!-- this row will not appear when printing -->
                  <hr class="colorgraph" style=" height:8px;
          border-top: 0;
          background:'.BODY3.';
          border-radius: 0px;">

         
                  </section><!-- /.content -->
          </div>
    

  
       

';
}}}}


?>
 </div> </div> </div> </div> </div>  </div></div>




            
























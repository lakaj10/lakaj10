
 <script type="text/JavaScript">
var clignotement = function(){ 
if (document.getElementById('DivClignotante2').style.visibility=='visible'){ 
document.getElementById('DivClignotante2').style.visibility='hidden'; 
} 
else{ 
document.getElementById('DivClignotante2').style.visibility='visible'; 
} 
}; 
periode = setInterval(clignotement, 800);

</script>

<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-name:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-tachometer-alt fa-1x "style="color:<?php echo TITRE;?>"></i> Tableau de Bord </h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Tableau de bord</li>
            </ol>
          </div>
    <?php 
     

       if(isset($_GET['tokken']))
       {
        $tokken=$_GET['tokken'];
       if($tokken==TOKKEN)
        {  
         
      /*  echo'<div class="alert alert-info alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                    <centere>  <i class="fas fa-fw fa-user-circle fa-1x "style="color:'.COULEURT.'"></i><b>DOCUMENTS-PORO </b>souhaite la bienvenue sur sa plateforme à   <b> '.strtoupper($_SESSION['nomprenoms']).' . </b> connecté en tant qu\'<b>'.strtoupper($_SESSION['compte']).'</b></center>
                  </div>
<META HTTP-EQUIV="refresh" CONTENT="10; URL=./goodoo.php?webox='.DASHBOARD.'">
                  ';
*/
                         
        }
        else
        {

        }
      }
      ?>


       <?php
                           if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='2'){
                            $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                            $donnees=$req->fetch(); 
                          if($req){
                            // age actuelle du client
                         
                          $dna=$donnees['dna'];
                          $da=$donnees['da'];

                           if($da!='' AND $dna!='')
                          {
                      echo'<div class="alert alert-info alert-dismissible " role="alert"data-toggle="modal" data-target="#ANNIVERSAIRE" id="#modalCenter">
                     
                      <center>  <i class="fas fa-fw fa-bell fa-1x "style="color:'.COULEURT.'"></i> Une nouvelle notification pour  ';
                  if($donnees['sexe']=="F"){
                      echo'Mme / Mlle';
                     }
                      elseif($donnees['sexe']=='H'){
                      echo'Mr';
                      }

                echo'<b> '.strtoupper($_SESSION['nomprenoms']).' . </b> Cliquez ici pour en savoir plus</center>
                      </div>';
                          }
                          elseif($da=='' AND $dna=='')
                          {
                           //       echo'<span style="color:'.BOUTOND.'">'.'0'.'</span>'; 
                          }
                        
                         
                  }
                  }
                        ?>
                 <div class="row mb-3"style="visibility: visible; -webkit-animation: fadeInLeft 2.9s ; ">

           <!-- Earnings (Monthly) Card Example -->


                <div class="col-xl-3 col-md-6 mb-4"title="SERVICE CLIENT EN LIGNE">
              <div class="card h-100">
             <a   href="#" data-toggle="modal" data-target="#SERVICE_CLIENT" id="#modalCenter"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Service client</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                    <?php
                $connectes=1;
                $droitacces=1;   
              
                $reponse=$bdd->query('SELECT COUNT(*) AS id FROM users  WHERE connectes="'.$connectes.'" AND droitacces="'.$droitacces.'"');
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['id'].'';
                    } $reponse->closeCursor();

                    ?>

                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-headphones fa-2x"style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>

                <div class="col-xl-3 col-md-6 mb-4"title="NOTIFICATIONS RECUES ">
              <div class="card h-100">
              <a   data-toggle="modal" data-target="#ANNIVERSAIRE" id="#modalCenter"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Notifications</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                        
                        <?php
                           if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='2'){
                            $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                            $donnees=$req->fetch(); 
                          if($req){
                            // age actuelle du client
                         
                          $dna=$donnees['dna'];
                          $da=$donnees['da'];

                           if($da!='' AND $dna!='')
                          {
                              echo'<span style="color:red"id="DivClignotante2">'.'1'.'</span>';
                          }
                          elseif($da=='' AND $dna=='')
                          {
                                  echo'<span style="color:'.BOUTOND.'">'.'0'.'</span>'; 
                          }
                        
                         
                  }
                  }
                        ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 20.4%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-bell fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
           


                <div class="col-xl-3 col-md-6 mb-4"title="MON PANIER ">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo LISTE_DES_DEMANDES_RECU;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Mon panier </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                    <?php
                     $categorie='Demande recu';$paiement=0;
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE statut='".$categorie."' AND paiement='".$paiement."' AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>

                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-shopping-cart fa-2x"style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
          


              


                <div class="col-xl-3 col-md-6 mb-4"title="ACTES DE NAISSANCE ">
              <div class="card h-100">
              <a  href="./goodoo.php?webox=<?php echo MES_ACTES_DE_NAISSANCE;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1"> Actes de naissance</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                         <?php                   
                  
                    $categorie='Actes de Naissance';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."' AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-paste fa-2x"style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
            <!-- Earnings (Annual) Card Example -->
                <div class="col-xl-3 col-md-6 mb-4"title="ACTES DE MARIAGE ">
              <div class="card h-100">
              <a  href="./goodoo.php?webox=<?php echo MES_ACTES_DE_MARIAGE;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Actes de mariage</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                        <?php                   
                  
                    $categorie='Actes de Mariage';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-venus-double fa-2x"style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
            <!-- New User Card Example -->
                <div class="col-xl-3 col-md-6 mb-4"title="ACTES DE DECES ">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo MES_ACTES_DE_DECES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1"> Actes de décès</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                        <?php                   
                  
                    $categorie='Actes de Décès';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 20.4%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-ambulance fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
            <!-- Pending Requests Card Example -->
                <div class="col-xl-3 col-md-6 mb-4"title="CERTIFICATION DE DOCUMENT ">
              <div class="card h-100">
            <a  href="./goodoo.php?webox=<?php echo MES_CERTIFICATIONS_DE_DOCUMENT;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Certification de document</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                         <?php                   
                  
                    $categorie='Certification de Document';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>

                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-danger mr-2"><i class="fas fa-arrow-down"></i> 1.10%</span>
                        <span>Since yesterday</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-file-pdf fa-2x"style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>

 







         
            <!-- Earnings (Annual) Card Example -->
                <div class="col-xl-3 col-md-6 mb-4"title="CERTIFICAT DE NATIONALITE IVOIRIENNE">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo MES_CERTIFICATS_DE_NATIONALITE_IVOIRIENNE;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Certificats de Nationalité </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                         <?php                   
                  
                    $categorie='Certificat de Nationalite Ivoirienne';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>
                      </div>
                    </div>
                    <div class="col-auto">
                  <i class="fas fa-flag fa-2x"style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
            <!-- New User Card Example -->
          
            <!-- Pending Requests Card Example -->
                <div class="col-xl-3 col-md-6 mb-4"title="CASIERS JUDICIAIRES">
              <div class="card h-100">
                    <a  href="./goodoo.php?webox=<?php echo MES_CASIERS_JUDICIAIRES;?>"style="text-decoration:none;color:#757575"> 
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Casiers Judiciaires</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                          <?php                   
                  
                    $categorie='Casiers Judiciaires';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE categorie='".$categorie."'AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-danger mr-2"><i class="fas fa-arrow-down"></i> 1.10%</span>
                        <span>Since yesterday</span>
                      </div>
                    </div>
                    <div class="col-auto">
                <i class="fas fa-folder-open fa-2x"style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>












   
                <div class="col-xl-3 col-md-6 mb-4"title="DEMANDES JOURNALIERES">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo MES_DEMANDES_DU_JOUR;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Demandes du jour </div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                    <?php
                    $date=getdate();
                    $joura=date('d');
                    $moisa=date('m');
                    $anneea=date('Y');
                    $datedujour=$joura.'/'.$moisa.'/'.$anneea;
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE jour='".$datedujour."' AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>

                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar-check fa-2x"style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
                <div class="col-xl-3 col-md-6 mb-4"title="DEMANDES MENSUELLES">
              <div class="card h-100">
          <a  href="./goodoo.php?webox=<?php echo MES_DEMANDES_DU_MOIS;?>"style="text-decoration:none;color:#757575"> 


                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Demandes du mois</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                        <?php
                    $date=getdate();
                    
                    $moisa=date('m');
                    
                    $mois=$moisa;
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE mois='".$mois."' AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
                <div class="col-xl-3 col-md-6 mb-4"title="DEMANDES ANNUELLES">
              <div class="card h-100">
              <a  href="./goodoo.php?webox=<?php echo MES_DEMANDES_DE_LANNEE;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Demandes de l'année</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                        
                        <?php
                    $date=getdate();
                   
                    $anneea=date('Y');
                    $annee=$anneea;
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE annee='".$annee."'AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 20.4%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar-plus fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
           


             



  <div class="col-xl-3 col-md-6 mb-4"title="TOUTES MES DEMANDES">
              <div class="card h-100">
              <a  href="./goodoo.php?webox=<?php echo LISTE_DES_DEMANDES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Toutes mes demandes</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                        
                        <?php
                    $date=getdate();
                   
                    $anneea=date('Y');
                    $annee=$anneea;
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 20.4%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-edit fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
           






   
                <div class="col-xl-3 col-md-6 mb-4"title="DEMANDES TRAITEES ">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo MES_DEMANDES_TRAITEES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Demandes traitées</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        <?php
                    $statut='Traitée';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE statut='".$statut."'AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>

                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-file fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
                <div class="col-xl-3 col-md-6 mb-4"title="DEMANDES EXPEDIEES ">
              <div class="card h-100">
              <a  href="./goodoo.php?webox=<?php echo MES_DEMANDES_EXPEDIEES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Demandes expédiées</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                        
                           <?php
                    $statut='Expédiée';
                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE statut='".$statut."'AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                    echo'<span style="color:'.BOUTOND.'">'.$donnees['idd'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 20.4%</span>
                        <span>Since last </span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-truck fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
           

                <div class="col-xl-3 col-md-6 mb-4"title="PROBLEMES SIGNALES ">
              <div class="card h-100">
             <a  href="./goodoo.php?webox=<?php echo MES_PROBLEMES_SIGNALES;?>"style="text-decoration:none;color:#757575"> 

                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Messages envoyés</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
                        
                        <?php
                   
                    $reponse=$bdd->query("SELECT COUNT(*) AS idp FROM probleme WHERE  code='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                     echo'<span style="color:'.BOUTOND.'">'.$donnees['idp'].'';
                    } $reponse->closeCursor();

                    ?>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-envelope fa-2x "style="color:<?php echo ICON;?>;"></i>
                    </div>
                  </div>
                </div></a>
              </div>
            </div>
           




<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;">  <i class="fas fa-fw fa-check-circle fa-1x "style="color:<?php echo TITRE;?>"></i> Confirmation de la demande</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Confirmation de la demande</li>
            </ol>
          </div> 







          <!-- BreadCrumb -->

 
    <div class="row"data-wow-delay="0.4s" style="visibility: visible; -webkit-animation: zoomInss 0.4s;">

<?php
  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   

   $reponse=$bdd->query(" 
SELECT

users.code,
users.nomprenoms,
users.mobile,
users.photo,
users.email,

  demandes_cni_tmp.idcni,
  demandes_cni_tmp.coded,
  demandes_cni_tmp.codeu,
  demandes_cni_tmp.type,
  demandes_cni_tmp.categorie,
  demandes_cni_tmp.paiement,
  demandes_cni_tmp.datepaiement,
  demandes_cni_tmp.statut,
  demandes_cni_tmp.datestatut,
  demandes_cni_tmp.jour,
  demandes_cni_tmp.mois,
  demandes_cni_tmp.annee,
  demandes_cni_tmp.pu,
  demandes_cni_tmp.nbrecopie,
  demandes_cni_tmp.montant,
  demandes_cni_tmp.fre,
  demandes_cni_tmp.mode,
  demandes_cni_tmp.commune,
  demandes_cni_tmp.frc,
  demandes_cni_tmp.quartier,
  demandes_cni_tmp.frq,

  demandes_cni_tmp.dn,
 demandes_cni_tmp.ln,
  demandes_cni_tmp.filiation,
  demandes_cni_tmp.nomprenom,
  demandes_cni_tmp.numcni,
      demandes_cni_tmp.motifdemande,
  demandes_cni_tmp.lieudemande,
  demandes_cni_tmp.villelivrai,
  demandes_cni_tmp.adressedom,
  demandes_cni_tmp.solde,
  demandes_cni_tmp.quartier

FROM demandes_cni_tmp,users WHERE users.code=demandes_cni_tmp.codeu AND demandes_cni_tmp.coded='".$identifiant_demande."' ORDER BY demandes_cni_tmp.idcni  DESC LIMIT 0, 1");


//$reponse=$bdd->query("SELECT * FROM membres WHERE codeuser ='".$_SESSION['code']."'ORDER BY id ASC limit 0,1000");
$nb_resultats = $reponse->rowCount(); 
$res = $reponse->fetchAll();
if (count($res) == 0) 
{
  echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CERTIFICAT.'"</SCRIPT>'; 


}
else {
foreach ($res as $donnees) {
echo '
        <div class="col-sm-12">
      
    <!-- End Breadcrumb-->
      <div class="card">
          <div class="card-body">
                  <!-- Content Header (Page header) -->
                  <section class="content-header">
                   
                      <h3 style="font-family:arial;color:orange"> '.ucfirst($donnees['categorie']).'</h3>
                  </section>

                  <!-- Main content -->
                  <section class="invoice">
                    <!-- title row -->
                    <div class="row mt-3">
                      <div class="col-lg-6">
                       <h4>
                      Réference : 
                      <small style="font-family:arial black;color:#66bb6a">'.ucwords($donnees['coded']).'</small>
                    </h4>
                      </div>
            <div class="col-lg-6">
             <h6 class="float-sm-right">Généré le : ';
$date=getdate();
$generation=date('d/m/Y');
echo $generation;
echo'</h6>
            </div>
                    </div>
          
          <hr class="colorgraph" style=" height:8px;
          border-top: 0;
          background:'.BODY3.';
          border-radius: 0px;">
                    <div class="row invoice-info">
                      <div class="col-sm-3 invoice-col">

                        De :
                        <address>
                         <strong>'.strtoupper($donnees['nomprenoms']).'</strong><br>
                          
                          Mobile: (+225) '.ucfirst($donnees['mobile']).'<br>
                          Email: '.substr($donnees['email'],0,26).' <br>
                              Statut de la demande : <b style="text-transform:;color:skyblue">'.substr($donnees['statut'],0,15).'</b>
                           
                     
                        </address>
                      </div><!-- /.col -->

                       <div class="col-sm-3 invoice-col">
                        <b style="color:red"></b>
                        <br>
                        Filiation du demandeur : <b style="text-transform:uppercase;color:#999;">'.strtoupper($donnees['filiation']).'</b><br>
                        Nom & prenoms : <b style="text-transform:uppercase;color:#999;"title="'.strtoupper(substr($donnees['nomprenom'],0,100)).'">'.strtoupper(substr($donnees['nomprenom'],0,15)).'</b><br>
                        Numéro de la CNI : <b style="text-transform:uppercase;color:#999;">'.strtoupper($donnees['numcni']).'</b><br>
                     
                          Date de naissance :  <b style="text-transform:uppercase;color:#999;">'.strtoupper(substr($donnees['dn'],0,15)).'</b><br>
                      </div><!-- /.col -->

                       <div class="col-sm-3 invoice-col">
                        <b></b>
                        <br>
                     
                       Lieu de naissance :  <b style="text-transform:uppercase;color:#999;">'.strtoupper(substr($donnees['ln'],0,15)).'</b><br>
                        Lieu de la demande : <b style="text-transform:uppercase;color:#999;">'.substr($donnees['lieudemande'],0,12).'</b><br>
                        Ville d\'expédition :</b> <b style="text-transform:uppercase;color:#999;">'.substr($donnees['villelivrai'],0,12).'</b><br>
                        Commune de la ville : <b style="text-transform:uppercase;color:#999;">'.strtoupper(substr($donnees['commune'],0,26)).'</b><br>
                      </div><!-- /.col -->

                      <div class="col-sm-3 invoice-col">
                        <b></b>
                        <br>
                        
                        Adresse du Domicile : <b style="text-transform:uppercase;color:#999;">'.substr($donnees['adressedom'],0,13).'</b><br>
                        Quartier : <b style="text-transform:uppercase;color:#999;">'.substr($donnees['quartier'],0,12).'</b><br>
                     
                     
                        Motif de la demande : <b style="text-transform:uppercase;color:#999;">'.substr($donnees['motifdemande'],0,12).'</b><br>
                           Mode de livraison : <b style="text-transform:;color:skyblue">'.substr($donnees['mode'],0,25).'</b><br>
                        Type de demande : <b style="text-transform:;color:orange">'.substr($donnees['type'],0,25).'</b><br><br>
                      </div><!-- /.col -->
                    </div><!-- /.row -->

                    <!-- Table row -->
                    
                <hr class="colorgraph" style=" height:8px;
                border-top: 0;
                background:'.BODY3.';
                border-radius: 0px;">  
                 
                 <section class="invoice">
                    <!-- title row -->
                    <div class="row mt-3">
                      <div class="col-lg-6">
                       <h5>
                      N° de facture : 
                      <small style="font-family:arial black;color:red">DOCS-PORO-000'.ucfirst($donnees['idcni']).'</small>
                    </h5>
                      </div>
            <div class="col-lg-6">
             <h6 class="float-sm-right">Date de la demande : ';

echo ucfirst($donnees['jour']);
echo'</h6>
            </div>
                    </div>                
              

                  <hr class="colorgraph" style=" height:8px;
                border-top: 0;
                background:'.BODY3.';
                border-radius: 0px;">                  
                <section class="content-header">


<div class="table-responsive condensed">
<table id="example" class="table table-striped  table-sm mb-0 table-hover table-condensed" id="dataTables-example"data-wow-delay="0.2s" style="visibility: visible; -webkit-animation: fadeInLeftBigss 0.2s;">
<thead style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
<tr>
 
<th><center>Photo</center></th> 
<th><center>Frais . d\'expé.</center></th>
<th><center>Frais à Domi .</center></th>
<th><center>Frais Quartier .</center></th>
<th><center>Prix unitaire</center></th> 
<!-- --><th><center>Copies</center></th> 
<th><center>Montant partiel</center></th> 
<th><center>Montant final</center></th> 
<th><center>Reglé</center></th> 


</tr> 
</thead>

<tbody><tr>

<td><center>';
if(empty($donnees['photo'])) {
  echo'<img  src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;height:20px;width:20px">';
  }
  else
  {
  echo'<img  src="./mvc/vues/img/photo/users/'.$donnees['photo'].'" style="border-radius:100%;height:20px;width:20px">';
  }

echo'</b></center></td>
<td><center>'.ucfirst($donnees['fre']).'</b></center></td>
<td><center>'.ucfirst($donnees['frc']).'</b></center></td>
<td><center>'.ucfirst($donnees['frq']).'</b></center></td>
<td><center>'.ucfirst($donnees['pu']).' </b></center></td>
<td><center>'.ucfirst($donnees['nbrecopie']).'</b></center></td>
<td><center>'.ucfirst($donnees['montant']).' </b></center></td>
<td><center><b>';echo $donnees['solde'];echo' </b></center></td>

<td><center>';
if($donnees['paiement']=='1')
{
echo'<b style="color:orange">Oui</b>';
}
else
{
echo'<b style="color:blue">Non</b>';
}


echo'</center></td>




';
}


echo'</tr></a></tbody></table>
                      </div><!-- /.col -->
                    <!-- /.row -->



                    
                    <!-- /.row -->

                    <!-- this row will not appear when printing -->
              <hr class="colorgraph" style=" height:8px;
              border-top: 0;
              background:'.BODY3.';
              border-radius: 0px;">

              <div class="row no-print">
                     
            <div class="col-lg-12">
            <div class="float-sm-right">
                      <a href="./goodoo.php?webox='.CONFIRMATION_CNI.'&identifiant_demande='.$donnees['coded'].'" class="btn btn-success btn-sm btn-block"><span class="fa fa-check-circle"></span> CONFIRMER LA DEMANDE</b></a>
            </div>
                      </div>
                      
                      

          
               </div>
                  </section><!-- /.content -->
          </div>
      </div>

    </div>

';
}}


?>









    </div>    </div></div>
<br>

            
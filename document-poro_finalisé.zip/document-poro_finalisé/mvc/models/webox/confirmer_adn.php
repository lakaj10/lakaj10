
<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;">  <i class="fas fa-fw fa-check-circle fa-1x "style="color:<?php echo TITRE;?>"></i> Confirmation de la demande</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Confirmation de la demande</li>
            </ol>
          </div> 







          <!-- BreadCrumb -->

 
    <div class="row"data-wow-delay="0.4s" style="visibility: visible; -webkit-animation: zoomInss 0.4s;">

<?php
  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   

   $reponse=$bdd->query(" 
SELECT

users.code,
users.nomprenoms,
users.mobile,
users.email,


  demandes_adn_tmp.idn,
  demandes_adn_tmp.coded,
  demandes_adn_tmp.codeu,
  demandes_adn_tmp.type,
  demandes_adn_tmp.categorie,
  demandes_adn_tmp.paiement,
  demandes_adn_tmp.datepaiement,
  demandes_adn_tmp.statut,
  demandes_adn_tmp.datestatut,
  demandes_adn_tmp.jour,
  demandes_adn_tmp.mois,
  demandes_adn_tmp.annee,
  demandes_adn_tmp.pu,
  demandes_adn_tmp.nbrecopie,
  demandes_adn_tmp.montant,
  demandes_adn_tmp.fre,
  demandes_adn_tmp.mode,
  demandes_adn_tmp.commune,
  demandes_adn_tmp.frc,
  demandes_adn_tmp.quartier,
  demandes_adn_tmp.frq,


  demandes_adn_tmp.filiation,
  demandes_adn_tmp.nomprenom,
  demandes_adn_tmp.numextrait,
  demandes_adn_tmp.datereg,
  demandes_adn_tmp.motifdemande,
  demandes_adn_tmp.lieudemande,
  demandes_adn_tmp.villelivrai,
  demandes_adn_tmp.adressedom,
  demandes_adn_tmp.solde,
  demandes_adn_tmp.quartier,
  demandes_adn_tmp.photo

FROM demandes_adn_tmp,users WHERE users.code=demandes_adn_tmp.codeu  AND demandes_adn_tmp.coded='".$identifiant_demande."' ORDER BY demandes_adn_tmp.idn  DESC LIMIT 0, 1");


//$reponse=$bdd->query("SELECT * FROM membres WHERE codeuser ='".$_SESSION['code']."'ORDER BY id ASC limit 0,1000");
$nb_resultats = $reponse->rowCount(); 
$res = $reponse->fetchAll();
if (count($res) == 0) 
{
echo '<b><script type="text/javascript"> alert(\'Votre demande a deja été pris en compte . redirection sur les details \');</script></b>';
                              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.EDITER_ADN.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>';

exit();
}
else {
foreach ($res as $donnees) {
echo '
        <div class="col-sm-12">
      
    <!-- End Breadcrumb-->
      <div class="card">
          <div class="card-body">
                  <!-- Content Header (Page header) -->
                  <section class="content-header">
                   
                      <h3 style="font-family:arial;color:orange"> '.ucfirst($donnees['categorie']).'</h3>
                  </section>

                  <!-- Main content -->
                  <section class="invoice">
                    <!-- title row -->
                    <div class="row mt-3">
                      <div class="col-lg-6">
                       <h4>
                      Réference : 
                      <small style="font-family:arial black;color:#66bb6a">'.ucwords($donnees['coded']).'</small>
                    </h4>
                      </div>
            <div class="col-lg-6">
             <h6 class="float-sm-right">Généré le : ';
$date=getdate();
$generation=date('d/m/Y');
echo $generation;
echo'</h6>
            </div>
                    </div>
          
          <hr class="colorgraph" style=" height:8px;
          border-top: 0;
          background:'.BODY3.';
          border-radius: 0px;">
                    <div class="row invoice-info">
                      <div class="col-sm-3 invoice-col">

                        De :
                        <address>
                         <strong>'.strtoupper($donnees['nomprenoms']).'</strong><br>
                          
                          Mobile: (+225) '.ucfirst($donnees['mobile']).'<br>
                          Email: '.substr($donnees['email'],0,26).' <br>
                              Statut de la demande : <b style="text-transform:;color:skyblue">'.substr($donnees['statut'],0,15).'</b>
                        </address>
                      </div><!-- /.col -->

                       <div class="col-sm-3 invoice-col">
                        <b style="color:red"></b>
                        <br>
                        Filiation du demandeur : <b style="text-transform:uppercase;color:#999;">'.strtoupper($donnees['filiation']).'</b><br>
                        Nom & prenoms : <b style="text-transform:uppercase;color:#999;"title="'.strtoupper(substr($donnees['nomprenom'],0,100)).'">'.strtoupper(substr($donnees['nomprenom'],0,15)).'</b><br>
                        Numéro de l\'extrait : <b style="text-transform:uppercase;color:#999;">000'.strtoupper($donnees['numextrait']).'</b><br>
                        Date du régistre :  <b style="text-transform:uppercase;color:#999;">'.strtoupper($donnees['datereg']).'</b><br>
                      </div><!-- /.col -->

                       <div class="col-sm-3 invoice-col">
                        <b></b>
                        <br>
                       Motif de la demande :  <b style="text-transform:uppercase;color:#999;">'.substr($donnees['motifdemande'],0,12).'.</b><br>
                        Lieu de la demande : <b style="text-transform:uppercase;color:#999;">'.substr($donnees['lieudemande'],0,12).'</b><br>
                        Ville d\'expédition :</b> <b style="text-transform:uppercase;color:#999;">'.substr($donnees['villelivrai'],0,12).'</b><br>
                        Commune de la ville : <b style="text-transform:uppercase;color:#999;">'.strtoupper(substr($donnees['commune'],0,26)).'</b><br>
                      </div><!-- /.col -->

                      <div class="col-sm-3 invoice-col">
                        <b></b>
                        <br>
                        
                        Adresse du Domicile : <b style="text-transform:uppercase;color:#999;">'.substr($donnees['adressedom'],0,13).'</b><br>
                        Quartier : <b style="text-transform:uppercase;color:#999;">'.substr($donnees['quartier'],0,12).'</b><br>
                        Mode de livraison : <b style="text-transform:;color:skyblue">'.substr($donnees['mode'],0,25).'</b><br>
                        Type de demande : <b style="text-transform:;color:orange">'.substr($donnees['type'],0,25).'</b><br><br>
                      </div><!-- /.col -->
                    </div><!-- /.row -->

                    <!-- Table row -->
                    
                <hr class="colorgraph" style=" height:8px;
                border-top: 0;
                background:'.BODY3.';
                border-radius: 0px;">  
                 
                 <section class="invoice">
                    <!-- title row -->
                    <div class="row mt-3">
                      <div class="col-lg-6">
                       <h5>
                      N° de facture : 
                      <small style="font-family:arial black;color:red">#000'.ucfirst($donnees['idn']).'</small>
                    </h5>
                      </div>
            <div class="col-lg-6">
             <h6 class="float-sm-right">Date de la demande : ';

echo ucfirst($donnees['jour']);
echo'</h6>
            </div>
                    </div>                
              

                  <hr class="colorgraph" style=" height:8px;
                border-top: 0;
                background:'.BODY3.';
                border-radius: 0px;">                  
                <section class="content-header">


<div class="table-responsive condensed">
<table id="example" class="table table-striped  table-sm mb-0 table-hover table-condensed" id="dataTables-example"data-wow-delay="0.2s" style="visibility: visible; -webkit-animation: fadeInLeftBigss 0.2s;">
<thead style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
<tr>
 
<th><center>Extrait</center></th> 
<th><center>Frais . d\'expé.</center></th>
<th><center>Frais à Domi .</center></th>
<th><center>Frais Quartier .</center></th>
<th><center>Prix unitaire</center></th> 
<!-- --><th><center>Copies</center></th> 
<th><center>Montant partiel</center></th> 
<th><center>Montant final</center></th> 
<th><center>Reglé</center></th> 


</tr> 
</thead>

<tbody><tr>

<td><center>';
if(empty($donnees['photo'])){
echo'';
}
else{
echo'<a href="./mvc/vues/img/extrait/'.$donnees['photo'].'"style="text-decoration:none"alt="Souci d\'affichage de la copie de l\'extrait"><i class="fas fa-file-pdf fa-1x" style="color:#fc544b;"></i></a>';
}

echo'</b></center></td>
<td><center>'.ucfirst($donnees['fre']).'</b></center></td>
<td><center>'.ucfirst($donnees['frc']).'</b></center></td>
<td><center>'.ucfirst($donnees['frq']).'</b></center></td>
<td><center>'.ucfirst($donnees['pu']).' </b></center></td>
<td><center>'.ucfirst($donnees['nbrecopie']).'</b></center></td>
<td><center>'.ucfirst($donnees['montant']).' </b></center></td>
<td><center><b>';echo $donnees['solde'];echo' </b></center></td>

<td><center>';
if($donnees['paiement']=='1')
{
echo'<b style="color:orange">Oui</b>';
}
else
{
echo'<b style="color:blue">Non</b>';
}


echo'</center></td>




';
}


echo'</tr></a></tbody></table>
                      </div><!-- /.col -->
                    <!-- /.row -->



                    
                    <!-- /.row -->

                    <!-- this row will not appear when printing -->
              <hr class="colorgraph" style=" height:8px;
              border-top: 0;
              background:'.BODY3.';
              border-radius: 0px;">

               <div class="row no-print">
                     
            <div class="col-lg-12">
            <div class="float-sm-right">
                      <a href="./goodoo.php?webox='.CONFIRMATION_ADN.'&identifiant_demande='.$donnees['coded'].'" class="btn btn-success btn-sm btn-block"><span class="fa fa-check-circle"></span> CONFIRMER LA DEMANDE</b></a>
            </div>
                      </div>
                      

          
               </div>
                  </section><!-- /.content -->
          </div>
      </div>

    </div>

';
}}


?>









    </div>    </div></div>
<br>

            

<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-folder-open fa-1x "style="color:<?php echo TITRE;?>"></i> Casier judiciaire</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Casier judiciaire</li>
            </ol>
          </div>


              <!--   <div class="alert alert-danger alert-dismissible fade show text-center progress-bar progress-bar-striped progress-bar-animated bg-danger" role="alert"style="font-size:14px;">
     <b>PJ : Extrait de naissance original de moins de 6 mois </b> 
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">×</span>
    </button>
  </div>-->
    
<?php


$errors = [];
mb_internal_encoding('UTF-8');


if ('POST' == $_SERVER['REQUEST_METHOD']) {

if (isset($_POST['ajouter_demande_casier_judiciaire'])) {
    $stmt = $bdd->prepare('SELECT 1 FROM demandes WHERE coded = :coded');
    $stmt->execute(['coded' => $_POST['coded']]);
    if (FALSE !== $stmt->fetchColumn()) {
    $errors['coded'] = "ce code est dejà utilisé";
    }

  } 


  if(!$errors) {
  
  $dn=$_POST['dn'];
  $timestamp=strtotime($dn);
  $dn=date("d/m/Y", $timestamp);

  $pu=$_POST['pu'];
 
     $statut='Demande recu';
  $datestatut=date("d/m/Y");
$paiement=0;
 $req= $bdd->prepare('INSERT INTO demandes_cj_tmp(coded,codeu,type,categorie,statut,datestatut,jour,mois,annee,pu,filiation,nomprenom,numcni,dn,ln,paiement)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');

  $req->execute(array($_POST['coded'],$_POST['codeu'],$_POST['type'],$_POST['categorie'],$statut,$datestatut,$_POST['jour'],$_POST['mois'],$_POST['annee'],$_POST['pu'],$_POST['filiation'],$_POST['nomprenoms'],$_POST['numcni'],$dn,$_POST['ln'],$paiement));

    if ($req) {
     //$reponse = $bdd->query('SELECT * FROM demandes_cj_tmp WHERE coded="'.$_POST['coded'].'" ORDER BY idd DESC LIMIT 0, 1');
      $reponse = $bdd->query('SELECT * FROM demandes_cj_tmp WHERE coded="'.$_POST['coded'].'" ORDER BY idcj DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {

  //$req= $bdd->prepare('INSERT INTO naissances_tmp(coded,codeu,filiation,nomprenom,datereg)VALUES(?,?,?,?,?)');
  //$req->execute(array($_POST['coded'],$_POST['codeu'],$_POST['filiation'],$_POST['nomprenom'],$datereg));
 
      echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CASIER_IDENTIQUE.'&identifiant_demande='.$_POST['coded'].'"</SCRIPT>'; 
                  
                }
      }
   }
}

if($errors) {
echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div>';

}

?> 



<form method="POST" action=""  autocomplete="on" enctype="multipart/form-data">


  <?php

if(isset($_SESSION['code']))
{ 
$req=$bdd->query('SELECT*FROM tarif WHERE nom="Casiers Judiciaires"'); 
$donnees=$req->fetch(); 
if($req){

echo' 
 <input hidden name="pu" class="form-control form-control-sm  " type="text" value="'.$donnees['montant'].'">
  <input hidden name="type" class="form-control form-control-sm  " type="text" value="'.$donnees['type'].'">
 <input hidden name="categorie" class="form-control form-control-sm  " type="text" value="'.$donnees['nom'].'">

    ';
}
}  
srand((double)microtime()*10000);
$num=rand();
$coded1='CJU-'.$num;
$coded2=substr($coded1,0,8);
$coded=$coded2;
//echo $coded;
echo'  <input type="hidden" name="coded" value="'.$coded.'"/>';   


$date=getdate();
$joura=date('d');
$moisa=date('m');
$anneea=date('Y');
$jour=$joura.'/'.$moisa.'/'.$anneea;
echo'<input type="hidden"name="jour"class="form-control form-control-sm  " value="'.$jour.'">';       
echo'<input type="hidden"name="mois"class="form-control form-control-sm  " value="'.$moisa.'">';
echo'<input type="hidden"name="annee"class="form-control form-control-sm  " value="'.$anneea.'">';       
?>

  <div class="row">
            <div class="col-lg-12">
              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.06)!important;background-color:white">
               
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.06)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-primary">FORMULAIRE DE DEMANDE</h6>
                                              
                </div> 

                 <input  value="<?php if(isset($_SESSION['code']) AND $_SESSION['droitacces']=='2'){ echo $_SESSION['code'];}?>" type="hidden"name="codeu" class="form-control form-control-sm   "style="background:<?php echo COULEURT ?> ;color:<?php echo TITRE ?>; font-family:arial;"  placeholder="users-" required>




                <div class="card-body">
                         <!-- <div class="form-group">
                               <label for="1"> Titulaire du compte</label>
                      <input disabled=""data-toggle="popover" title="TITULAIRE DU COMPTE"
                    data-content="Right?" value="<?php // if(isset($_SESSION['nomprenoms']) AND $_SESSION['droitacces']=='2'){ echo $_SESSION['nomprenoms'];}?>" type="text"class="form-control form-control-sm   "style="background:<?php  //echo COULEURT ?> ;color:<?php  //echo TITRE ?>; font-family:arial;"  placeholder="users-" required>
                      </div -->


                    <div class="form-group"<?php if (array_key_exists('filiation', $errors)) echo 'has-error';?>>
                      <label for="1"> Filiation du demandeur</label>
                      <select class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:<?php echo BOUTON ?>" name="filiation"id="1"autofocus value="<?php if (array_key_exists('filiation', $_POST)) echo htmlspecialchars($_POST['filiation']); ?>">
                      
                        <option value="Père">Père</option>
                        <option value="Mère">Mère</option>
                        <option value="Oncle">Oncle</option>
                        <option value="Tante"> Tante</option>

                        <option value="Soeur"> Soeur</option>
                        <option value="Frère">Frère</option>
                        <option value="Enfants"> Enfants</option>
                         <option value="Moi même"> Moi même</option>
                        <option value="Autres">Autres</option>
                        
                      </select>
                    </div>

                    <div class="form-group"<?php if (array_key_exists('nomprenoms', $errors)) echo 'has-error';?>>
                      <label for="2"> Nom & prénoms du demandeur</label>
                      <input type="text" name="nomprenoms" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:<?php echo BOUTON ?>" id="2" placeholder="" required value="<?php if (array_key_exists('nomprenoms', $_POST)) echo htmlspecialchars($_POST['nomprenoms']); ?>">
                    </div>

                    <div class="form-group"<?php if (array_key_exists('numcni', $errors)) echo 'has-error';?>>
                      <label for="2"> Numéro de la CNI </label>
                      <input type="text" name="numcni" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:<?php echo BOUTON ?>" id="2" placeholder="" required value="<?php if (array_key_exists('numcni', $_POST)) echo htmlspecialchars($_POST['numcni']); ?>">
                    </div>



                  <div class="form-group"<?php if (array_key_exists('dn', $errors)) echo 'has-error';?>>
                      <label for="3"> Date de naissance</label>
                      <input type="date"autofocus=""name="dn"style="border:1px solid #ddd;font-family:arial;text-transform:none;color:<?php echo BOUTON ?>" class="form-control form-control-sm  " id="3" placeholder="" required value="<?php if (array_key_exists('dn', $_POST)) echo htmlspecialchars($_POST['dn']); ?>">
                    </div>



                    <div class="form-group"<?php if (array_key_exists('ln', $errors)) echo 'has-error';?>>
                      <label for="3"> Lieu de naissance</label>
                      <input type="text"autofocus="" name="ln"style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:<?php echo BOUTON ?>" class="form-control form-control-sm  " id="3" placeholder="" required value="<?php if (array_key_exists('ln', $_POST)) echo htmlspecialchars($_POST['ln']); ?>">
                    </div>




                  
                   
              
           <div class="form-group">

                    <div class="custom-control custom-checkbox" style="line-height: 1.5rem;">
                    <input type="checkbox" class="custom-control-input" id="customCheck"required="" checked="">
                    <label class="custom-control-label" for="customCheck"checked=""> <b> Pièce Jointe :</b><b  style="color: red"> Extrait de naissance original de moins de 6 mois  </b>
                    </label>
                    </div>
                    </div>
          
                
              
          
              

                   
                    <button type="submit"name="ajouter_demande_casier_judiciaire"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar"> ENREGISTRER
</button>
                  </div>
                </div>
              </div>
</div>
           </form>       
             
            
 </div> </div><br><br> </div> </div> 


          


             
      







































































































































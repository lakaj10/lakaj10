 


 <?php
############################################################################################################################################
if(empty($_SESSION['pseudo']))
{
######################################################################################################################################### echo'<META HTTP-EQUIV="refresh" CONTENT="0; URL=./woodoo.php?webox='.OUVERTURE.'">';

}
else
{ 
  sleep(2);
   echo'<META HTTP-EQUIV="refresh" CONTENT="0; URL=./goodoo.php?webox='.DASHBOARD.'">';
}


      
;  ?>

 

 <?php
#############################################################################################################################################
?>

<br>
 <div class="container-login"style="visibility: visible; -webkit-animation: fadeInLeft 2.9s ; ">
    <div class="row justify-content-center">
      <div class="col-xl-6 col-lg-12 col-md-12">

   
<?php  include('./mvc/models/webox/head.php');  ?>

              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;background-color:white">

<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
    <h6 class="m-0 font-weight-bold text-default"> CONNEXION </h6>
</div>

<div class="card-body"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;">

 <?php
############################################################################################################################################
error_reporting(E_ALL);

      if(isset($_POST['connexiona'])) {
        $pseudo=htmlspecialchars($_POST['pseudo']);
        $mdpcrypte=htmlspecialchars($_POST['mdpcrypte']);
        $membre=$bdd->prepare("SELECT * FROM users where pseudo=? AND mdpcrypte=?  AND verrou=0 AND activer=1");
        $membre->execute(array($pseudo,$mdpcrypte));
        $membreexist=$membre->rowCount();

if($membreexist==1){
        $membreinfo=$membre->fetch();
if($membreinfo){

        $_SESSION['id']=$membreinfo['id'];
        $_SESSION['mdp']=$membreinfo['mdp'];
        $_SESSION['droitacces']=$membreinfo['droitacces'];
        $_SESSION['connectes']=$membreinfo['connectes'];
        $_SESSION['photo']=$membreinfo['photo'];
        $_SESSION['pseudo']=$membreinfo['pseudo'];
        $_SESSION['nomprenoms']=$membreinfo['nomprenoms'];
        $_SESSION['code']=$membreinfo['code'];
        $_SESSION['compte']=$membreinfo['compte'];

        //echo'<center><img src="./mvc/vues/img/logo/loading.gif" style=" height:auto;width:auto" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI"style=";margin: 20% auto;font-size:100px"></center><META HTTP-EQUIV="refresh" CONTENT="0; URL=./woodoo.php?webox='.LOADING.'">';
 echo '

 <SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'&tokken='.TOKKEN.'"</SCRIPT>'; 
        $session=$_SESSION['id'];
        $req=$bdd->prepare("SELECT * FROM users where id='".$session."'");
        if($req){
      
        $connectes=1 ;
        $date=getdate();

        $joura=date('d');
        $moisa=date('m');
        $anneea=date('Y');

        $hour=date('H');
        $min=date('i');
        $sec=date('s');

        $datec=$joura.'/'.$moisa.'/'.$anneea;
        $heurec=$hour.':'.$min.':'.$sec;
        $bdd->exec("UPDATE users SET connectes='".$connectes."',datec='".$datec."',heurec='".$heurec."' WHERE id='".$session."'");      
        }
          //sleep(2);
       //echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="'.URL.'goodoo.php?webox='.DASHBOARD.'&tokken='.TOKKEN.'"</SCRIPT>'; 
            //
               
           //echo $_SESSION['id'];
         // $bdd->exec("UPDATE users SET datec='".$datec."' AND heurec='".$heurec."' WHERE id='".$_SESSION['id']."'");   

        /**/$reponse=$bdd->query("SELECT * FROM session WHERE id='".$_SESSION['id']."'");
        $res=$reponse->fetchAll();
        $pseudo=$_SESSION['pseudo'];
        $id=$_SESSION['id'];
         $session_time=7200;    
        $time=time();
        $expiration= intval(time() + $session_time);


        if(count($res)==0)   // L'IP ne se trouve pas dans la table, on va l'ajouter.
        {   
        $req= $bdd->prepare('INSERT INTO session(id,pseudo,expiration)VALUES(?,?,?)');
        $req->execute(array($id,$pseudo,$expiration));
        }
        else // L'IP se trouve déjà dans la table, on met juste à jour le timestamp.
        {
        $bdd->exec("UPDATE session SET  pseudo='".$pseudo."',expiration='".$expiration."' WHERE id='".$id."'");
        }

exit();
       }
}

else{
    // sleep(1);
        echo '<div class="alert alert-danger alert-dismissible fade show text-center" role="alert"style="font-size:14px">
    <strong>Le couple de connexion est incorrect</strong>
   
  </div>
  '; 
       // 


}
}

#############################################################################################################################################
;  ?>

 <?php 
     

       if(isset($_GET['tokken']))
       {
        $tokken=$_GET['tokken']; 
       if($tokken==TOKKEN)
        {  
         
        /*echo'    <div class="alert alert-info alert-dismissible" role="alert">
                   
                    <center> Merci de votre visite. et à bientôt </b></center>
                  </div>

                  ';*/
      
        }
       /**/ elseif($tokken==SESSION_EXPIREE)
        {  
         
      
                 if(isset($_SESSION['id'])){
                        $req=$bdd->query('SELECT*FROM users WHERE id="'.$_GET['id'].'"'); 
                        $donnees=$req->fetch(); 
                   if( $donnees['connectes']=='1'){
                        $id=$_SESSION['id'];
                        $connectes=0 ;
                        $datec='';
                        $heurec='';
                        $bdd->exec("UPDATE users SET connectes='".$connectes."',datec='".$datec."',heurec='".$heurec."' WHERE id='".$id."'");
                  if($bdd){
                      $_SESSION = array();
                     session_destroy(); 
                        //echo $_SESSION['id'];
                    // echo'<META HTTP-EQUIV="refresh" CONTENT="0; URL=./woodoo.php?webox='.MESSAGE2.'&tokken='.MESSAGE2.'">';
  echo '<b><script type="text/javascript"> alert(\'Votre session a expirée . Veillez vous reconnecter pour continuer.\');</script></b>';

                       
                  exit();
                  } 

                 }

               }
              
                         
        }
        else
        {

        }
      }
      ?>
<form class="form" method="post" action=""accept-charset="UTF-8">
         </label>
    <div class="form-group">
              <label for="1"> Nom utilisateur</label>
            <input type="text" name="pseudo"   class="form-control " id="1" placeholder=""style="border:1px solid skyblue;font-family:arial;text-transform:;color:<?php echo TEXTE ?>;"autofocus required="">
          </div>

          <div class="form-group">
                <label for="2">  <a style="text-decoration:none;color:#757575" href="./woodoo.php?webox=<?php echo FORGOT;?>"title="Mot de passe oublié">
         
          <span>Mot de passe oublié ?</span></a></label>
            <input  type="password" name="mdpcrypte"id="2" placeholder="" class="form-control " style="border:1px solid skyblue;font-family:arial;text-transform:;color:<?php echo TEXTE ?>;" autofocus required="">
          </div>

          <div class="form-group">
            <div class="custom-control custom-checkbox " style="line-height: 1.5rem;">
              <input type="checkbox"name="remember" class="custom-control-input" id="customCheck"checked="">
              <label class="custom-control-label" for="customCheck"checked="">Se souvenir de moi
                </label>
            </div>
          </div>

 <button type="submit"name="connexiona"  class="btn btn-warning btn-block"style="background:#ff8800;border: 1px solid #ff7700">            <i class="fas fa-spinner fa-spin"></i> CONNEXION  </center></button> 

  

                      <?php  include('./mvc/models/webox/reseaux_sociaux.php');  ?> 
                    
                      <div class="text-center">
                      <a class="font-weight " href="./woodoo.php?webox=<?php echo REGISTER;?>"title="Inscription nouveau Client"style="color:red!important;text-decoration:none;font-weight:bolder;">Vous n'avez pas de compte ? &nbsp;S'inscrire </a>
                    </div>

    </div>
</div></div></div></div>
 <?php
#############################################################################################################################################
?>








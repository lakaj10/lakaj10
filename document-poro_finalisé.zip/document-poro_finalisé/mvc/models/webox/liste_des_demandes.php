<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
             <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-edit fa-1x "style="color:<?php echo TITRE;?>"></i>  Toutes mes demandes </h1>

          
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Toutes mes demandes </li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->




          <!-- Row -->
         


                 <?php
                 $droitacces=2;
                 $reponse=$bdd->query('SELECT * FROM demandes WHERE codeu="'.$_SESSION['code'].'" ORDER BY idd ASC limit 0,10000000  ');
               
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                  if (count($res) == 0) 
                {
                    echo'  
                           <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">TOUTES MES DEMANDES :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                            ';
                
                            include('./mvc/models/webox/oops.php');

                }
                else {
                echo'
                 <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                <div class="table-responsive condensed">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">TOUTES MES DEMANDES :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                </div>
             <table class="table  table-sm mb-0 table-hover table-condensed">

                    <thead style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
                      <tr>
                      
                      
                        <th>Reference</th>
                        <th>Catégorie </th>
                        <th><centere>Demande</center> </th>
                         <th>Date   </th>
                       
                       
                        <th>Statut</th>
                         <th>Reglé </th>
                       <th>Le</th>
                        <th><centere>Pu </center></th>
                        <th><centere>Copie</center></th>
                         <th><centere>Montant</center></th>
                         
                         <th></th>
                          <th></th>
                      </tr>
                    </thead>

                   

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody id="myInput">
                     
                      
                      <tr>
                        
                        <td>'.$donnees['coded'].'</td>

                        <td title='.$donnees['type'].'><centere>'.substr($donnees['type'],0,10).' </center></td>

                        <td title='.$donnees['categorie'].'>'.strtoupper(substr($donnees['categorie'],0,10)).'</td>

                        <td >'.substr($donnees['jour'],0,10).'</td>

                         <td >';
                        if($donnees['statut']=='Demande recu')
                        {
                          echo'<b style="color:blue"><span class="badge badge-danger progress-bar progress-bar-striped progress-bar-animated bg-danger">Demande reçu </span></b>';
                        }
                        elseif($donnees['statut']=='Activée')
                        {
                           echo'<b style="color:orange"><span class="badge badge-warning progress-bar progress-bar-striped progress-bar-animated bg-warning">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                        elseif($donnees['statut']=='En cours de traitement')
                        {
                           echo'<b style="color:orange"><span class="badge badge-primary progress-bar progress-bar-striped progress-bar-animated bg-primary">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                        elseif($donnees['statut']=='Traitée')
                        {
                           echo'<b style="color:orange"><span class="badge badge-info progress-bar progress-bar-striped progress-bar-animated bg-info">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                         else
                        {
                           echo'<b style="color:orange"><span class="badge badge-success progress-bar progress-bar-striped progress-bar-animated bg-success">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                      
                      
                        echo'</td>
                        
                          <!----><td>';
                        if($donnees['paiement']=='1')
                        {
                          echo'<b style="color:orange">Oui</span></span>';
                        }
                        else
                        {
                        echo'<b style="color:blue">Non</span></span>';
                        }
                        
                      
                       echo'</td>

                          

                        <!----><td>'.substr($donnees['datestatut'],0,10).'</td>
                          <!----><td >'.$donnees['pu'].'</td>

                           <td><center>'.substr($donnees['nbrecopie'],0,10).'</center></td>
                        
                          <!----><td ><center>'.$donnees['solde'].'</center></td>

                     


                            <td><center><small>';
                        if($donnees['paiement']=='1')
                        {
                          echo'<a href="javascript:{}" data-toggle="tooltip" data-placement="top" title="SUPPRESSION" data-original-title="Supprimer"><font color="white"><i class="fa fa-check-circle"style="color:green;"></i></b></a></font>';
                        }
                        else
                        {
                        echo'<a href="./goodoo.php?webox='.SUPPRIMER_MA_DEMANDE.'&idd='.$donnees['idd'].'"onclick="return confirm(\'êtes vous sûre de supprimer votre demande referencée :  '.$donnees['coded'].' ?\');" data-toggle="tooltip" data-placement="top" title="SUPPRESSION" data-original-title="Supprimer"><font color="white"><i class="fa fa-trash"style="color:red;"></i></b></a></font>';
                        }
                      
                      
                        echo'</small></center></td>
                        ';
                           if(isset($donnees['categorie']) AND $donnees['categorie']=='Actes de Naissance')
                           {
                             echo'<td><small><a href="./goodoo.php?webox='.EDITER_ADN.'&identifiant_demande='.$donnees['coded'].'" data-toggle="tooltip" data-placement="top" title="EDITER " data-original-title="Afiicher les informations su compte"><font color="white"><i class="fa fa-eye"style="color:#4c60da;"></i></b></a></font></small></center></td>';


                           }
                           elseif(isset($donnees['categorie']) AND $donnees['categorie']=='Actes de Mariage')
                           {
                             echo'<td><small><a href="./goodoo.php?webox='.EDITER_ADM.'&identifiant_demande='.$donnees['coded'].'" data-toggle="tooltip" data-placement="top" title="EDITER " data-original-title="Afiicher les informations su compte"><font color="white"><i class="fa fa-eye"style="color:#4c60da;"></i></b></a></font></small></center></td>';


                           }
                           elseif(isset($donnees['categorie']) AND $donnees['categorie']=='Actes de Décès')
                           {
                             echo'<td><small><a href="./goodoo.php?webox='.EDITER_ADDE.'&identifiant_demande='.$donnees['coded'].'" data-toggle="tooltip" data-placement="top" title="EDITER " data-original-title="Afiicher les informations su compte"><font color="white"><i class="fa fa-eye"style="color:#4c60da;"></i></b></a></font></small></center></td>';


                               

                           }
                           elseif(isset($donnees['categorie']) AND $donnees['categorie']=='Casiers Judiciaires')
                           {
                             echo'<td><small><a href="./goodoo.php?webox='.EDITER_CJ.'&identifiant_demande='.$donnees['coded'].'" data-toggle="tooltip" data-placement="top" title="EDITER " data-original-title="Afiicher les informations su compte"><font color="white"><i class="fa fa-eye"style="color:#4c60da;"></i></b></a></font></small></center></td>';

                              

                           }
                           elseif(isset($donnees['categorie']) AND $donnees['categorie']=='Certificat de Nationalite Ivoirienne')
                           {
                             echo'<td><small><a href="./goodoo.php?webox='.EDITER_CNI.'&identifiant_demande='.$donnees['coded'].'" data-toggle="tooltip" data-placement="top" title="EDITER " data-original-title="Afiicher les informations su compte"><font color="white"><i class="fa fa-eye"style="color:#4c60da;"></i></b></a></font></small></center></td>';

                            

                           }

                         echo'

                      </tr>
                     
              
            </tbody>';
                     }

                echo'</table>';
          }
          
          ?>
  </div>   </div>  </div>  </div>   



            
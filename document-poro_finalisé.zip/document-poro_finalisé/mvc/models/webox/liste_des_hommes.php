<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-name:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-male fa-1x "style="color:<?php echo TITRE;?>"></i> Hommes</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Hommes</li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->



          <!-- Row -->
         


                 <?php



                //echo $code_client;
                //$reponse=$bdd->query("SELECT*FROM demandes  ORDER BY type  DESC limit 0,10000 ");
                
                    $droitacces=2;
                    $hommes="H";
                    $reponse=$bdd->query('SELECT * FROM users  where droitacces="'.$droitacces.'" AND sexe="'.$hommes.'" ORDER BY id ASC limit 0,10000000  ');
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                  if (count($res) == 0) 
                {

                 /* echo '<script type="text/javascript"> alert(\'     DESOLE  . AUCUNS RESULTAT TROUVES      \');</script>';

                   echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>'; */

                    echo' 

                          <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">LISTE DES HOMMES :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                         ';
                
                            include('./mvc/models/webox/oops.php');

                }
                else {
                echo'
                 <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                <div class="table-responsive condensed">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">LISTE DES HOMMES :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                </div>
                 <table class="table  table-sm mb-0 table-hover table-condensed">

                    <thead style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
                      <tr>
                        <th>Photo</th>
                      <th>Genre </th>
                        <th>Identifiant </th>
                        <th>Nom </th>
                        <th><centere>Email</center> </th>

                        <th>Mobile </th>
                          <th>Pseudo</th>
                          <th>Mdpasse  </th>
                        <th>Né le  </th>
                        <th>Age</th>
                          <th>Inscrit le  </th>
                         

                      </tr>
                    </thead>

              

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody id="myInput">
                     
                      
                      <tr>
                          <td >';
                       
                        if(empty($donnees['photo'])) {
                        echo'<img  src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;height:20px;width:20px">';
                        }
                        else
                        {
                        echo'<img  src="./mvc/vues/img/photo/users/'.$donnees['photo'].'" style="border-radius:100%;height:20px;width:20px">';
                        }

                        
                     echo'</td>

                       <td title='.$donnees['sexe'].'><center><b style="color:orange"><span class="badge badge-success progress-bar progress-bar-striped progress-bar-animated bg-success">'.substr($donnees['sexe'],0,15).'</span></b> </center></td>
                         <td >'.$donnees['code'].'</td>
                        <td title='.$donnees['nomprenoms'].'><centere>'.substr($donnees['nomprenoms'],0,12).' </center></td>
                        <td  title='.$donnees['email'].'>'.substr($donnees['email'],0,10).'</td>
                          <!----><td  title='.$donnees['mobile'].'>'.substr($donnees['mobile'],0,12).'</td>
                           <td>'.$donnees['pseudo'].'</td>
                       <td   title='.$donnees['mdpcrypte'].'>'.substr($donnees['mdpcrypte'],0,2).'</td>
                        

                                 <td  title='.$donnees['dn'].'><b style="color:orange"><span class="badge badge-warning progress-bar progress-bar-striped progress-bar-animated bg-warning">'.substr($donnees['dn'],0,20).'</span></b></td>

                                    <td ><centee><b>';
                                    $annee1=substr($donnees['dn'],6,20);
                                    $annee2=date("Y");
                                    $age=$annee2-$annee1;

                                    echo $age;
                                     echo'</b></center></td>
                        
                    

                         <td><b style="color:orange"><span class="badge badge-info progress-bar progress-bar-striped progress-bar-animated bg-info">'.$donnees['dateins'].'</span></b></td>
                       
                         </tr>
                         </tr>
                     
              
            </tbody>';
                     }

                echo'</table>';
          }
          
          ?>
  </div>   </div>  </div>  </div>   <br> 



            


            
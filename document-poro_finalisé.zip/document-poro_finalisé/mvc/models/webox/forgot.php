 

 <br>
 <?php
#############################################################################################################################################
?>

 <div class="container-login"style="visibility: visible; -webkit-animation: fadeInLeft 2.9s ; ">
    <div class="row justify-content-center">
   <div class="col-xl-6 col-lg-12 col-md-12">

<?php  include('./mvc/models/webox/head.php');  ?>


              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;background-color:white">

<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
    <h6 class="m-0 font-weight-bold text-default"><i class="fa fa-question-circlee"></i> CONNEXION</h6>
</div>

<div class="card-body"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;">

 <?php

//error_reporting(E_ALL);
if(isset($_POST['connexiona'])) {
    $pseudo=htmlspecialchars($_POST['pseudo']);
    $code=htmlspecialchars($_POST['code']);

   $membre=$bdd->prepare("SELECT * FROM users where pseudo=? AND code=?  AND verrou=0 AND activer=1");
    $membre->execute(array($pseudo,$code));
    $membreexist=$membre->rowCount();

if($membreexist==1){
    $membreinfo=$membre->fetch();
    if($membreinfo){
        $_SESSION['id']=$membreinfo['id'];
        $_SESSION['mdp']=$membreinfo['mdp'];
        $_SESSION['droitacces']=$membreinfo['droitacces'];
        $_SESSION['photo']=$membreinfo['photo'];
        $_SESSION['pseudo']=$membreinfo['pseudo'];
        $_SESSION['nomprenoms']=$membreinfo['nomprenoms'];
        $_SESSION['code']=$membreinfo['code'];
        $_SESSION['compte']=$membreinfo['compte'];
        echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>'; 
        $session=$_SESSION['id'];
        $req=$bdd->prepare("SELECT * FROM users where id='".$session."'");
        if($req){
      
        $connectes=1 ;
        $date=getdate();

        $joura=date('d');
        $moisa=date('m');
        $anneea=date('Y');

        $hour=date('H');
        $min=date('i');
        $sec=date('s');

        $datec=$joura.'/'.$moisa.'/'.$anneea;
        $heurec=$hour.':'.$min.':'.$sec;
        $bdd->exec("UPDATE users SET connectes='".$connectes."',datec='".$datec."',heurec='".$heurec."' WHERE id='".$session."'");      
        }
          //sleep(2);
       //echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="'.URL.'goodoo.php?webox='.DASHBOARD.'&tokken='.TOKKEN.'"</SCRIPT>'; 
            //
               
           //echo $_SESSION['id'];
         // $bdd->exec("UPDATE users SET datec='".$datec."' AND heurec='".$heurec."' WHERE id='".$_SESSION['id']."'");   

        /**/$reponse=$bdd->query("SELECT * FROM session WHERE id='".$_SESSION['id']."'");
        $res=$reponse->fetchAll();
        $pseudo=$_SESSION['pseudo'];
        $id=$_SESSION['id'];
         $session_time=7200;    
        $time=time();
        $expiration= intval(time() + $session_time);


        if(count($res)==0)   // L'IP ne se trouve pas dans la table, on va l'ajouter.
        {   
        $req= $bdd->prepare('INSERT INTO session(id,pseudo,expiration)VALUES(?,?,?)');
        $req->execute(array($id,$pseudo,$expiration));
        }
        else // L'IP se trouve déjà dans la table, on met juste à jour le timestamp.
        {
        $bdd->exec("UPDATE session SET  pseudo='".$pseudo."',expiration='".$expiration."' WHERE id='".$id."'");
        }

exit();
       }
}

else{
     sleep(1);
        echo '<div class="alert alert-danger alert-dismissible fade show text-center" role="alert"style="font-size:14px;">
    <strong>Le couple de connexion est incorrect</strong>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">×</span>
    </button>
  </div>
<META HTTP-EQUIV="refresh" CONTENT="2; URL=./woodoo.php?webox='.OUVERTURE.'">
  '; 
       // 


}
}

#############################################################################################################################################
;  ?>

     <form class="form" method="post" action="">

    <div class="form-group">
              <label for="1">Nom utilisateur</label>
            <input type="text" name="pseudo"   class="form-control " id="1" placeholder=" "style="border:1px solid skyblue;font-family:arial;text-transform:normal;color:<?php echo TEXTE ?>"autofocus required="">
          </div>

        <div class="form-group">
                <label for="1"> Identifiant <a style="text-decoration:none;color:red" href="./woodoo.php?webox=<?php echo OUVERTURE;?>"title="Mot de passe oublié">
         
          <span>oublié ?</span></a></label>
            <input  type="number" name="code" placeholder="" class="form-control" style="border:1px solid skyblue;font-family:arial;text-transform:normal;color:<?php echo TEXTE ?>" autofocus required="">
          </div>

          <div class="form-group">
            <div class="custom-control custom-checkbox " style="line-height: 1.5rem;">
              <input type="checkbox"name="remember" class="custom-control-input" id="customCheck"checked="">
              <label class="custom-control-label" for="customCheck"checked="">Se souvenir de moi
                </label>
            </div>
          </div>
 <button type="submit"name="connexiona"  class="btn btn-warning btn-block"style="background:#ff8800;border: 1px solid #ff7700">             <i class="fas fa-spinner fa-spin"></i> CONNEXION </button> 

   <?php  include('./mvc/models/webox/reseaux_sociaux.php');  ?> 
                          <div class="text-center">
                      <a class="font-weight " href="./woodoo.php?webox=<?php echo REGISTER;?>"title="Inscription nouveau Client"style="color:red!important;text-decoration:none;font-weight:bolder;">Vous n'avez pas de compte ? &nbsp;S'inscrire  </a>
                    </div>

                  
    </div>
</div></div></div></div>
 <?php
#############################################################################################################################################
?>









<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-bullhorn fa-1x "style="color:<?php echo TITRE;?>"></i> Information</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Information</li>
            </ol>
          </div>
            <div class="row">
            <div class="col-lg-12">
              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.06)!important;background-color:white">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.06)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-primary"> PUBLICATION</h6>
                </div> 
                <div class="card-body">


<?php

$errors = [];
mb_internal_encoding('UTF-8');
if ('POST' == $_SERVER['REQUEST_METHOD']) {
//nom & prenom

if (!$errors) {
$date=getdate();
//$annnee=date('Y');
//$codearticle=$annnee.$date["minutes"].$date["seconds"];
$dateenvoie=date("d/m/Y");
$heureenvoie=date("H:i");

$req= $bdd->prepare('INSERT INTO infos(titre,contenu,dateenvoie,heureenvoie) VALUES(?,?,?,?)');
$req->execute(array($_POST['titre'],$_POST['contenu'],$dateenvoie,$heureenvoie));
if ($req) {
$bdd->exec("DELETE FROM infosvue");
$reponse = $bdd->query('SELECT * FROM infos ORDER BY id DESC LIMIT 0, 1');

while ($donnees = $reponse->fetch())
{


}
}
}   
}
?>




<?php
if (isset($_POST['v']) AND !$errors ) {
      echo '<script type="text/javascript"> alert(\' information publiée avec succès\');</script>';
echo'<META HTTP-EQUIV="refresh" CONTENT="2; URL=#">';

}

?>    


<?php 
if( isset($_SESSION['id']))
{

$req = $bdd->query('SELECT * FROM users where id="'.$_SESSION['id'].'"');
$donnees = $req->fetch();
if($donnees)
{


echo 
' 
               
                  <form method="post" action=""  autocomplete="on">


                  
                    <div class="form-group">
                      <label for="4">Titre</label>
                       <select class="form-control form-control-sm" style="text-align:center;"  name="titre" id="4">
<option value="Info Document-poro"> Info Document-poro</option>
<option value="Urgent"> Urgent</option>
<option value="Promo"> Promo</option>
</select>   
                    </div>
                    
                     <div class="form-group">
                      <label for="5">Contenu </label>
                      <textarea name="contenu" required class="form-control"id="5" cols="10"rows="1"  placeholder="" value=""autofocus></textarea>
                    </div>
                   
                    <button type="submit"name="v"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar"> ENREGISTRER</button>
                  </form>
               
 ';
    }
    }
?>
                </div>
             
           
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo GAUCHE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-ambulance fa-1x "style="color:<?php echo GAUCHE;?>"></i> Actes de décès</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Actes de décès</li>
            </ol>
          </div>


<?php

  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   
               $reponse=$bdd->query("SELECT*FROM demandes_adde_tmp WHERE coded='".$identifiant_demande."' ORDER BY idde  DESC LIMIT 0, 1");


              $nb_resultats = $reponse->rowCount(); 
              $res = $reponse->fetchAll();
              if (count($res) == 0) 
              {   
              echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DECES.'"</SCRIPT>'; 

              }
              else
              {
              foreach ($res as $donnees) {

                $req = $bdd->prepare('SELECT 1 FROM demandes_adde WHERE coded="'.$identifiant_demande.'"');
                          $req->execute(array('coded'=>$donnees['coded']));
                          $nb_resultats_recherche=$req->fetch();

                              if(!$nb_resultats_recherche)
                              {
                              $solde=$donnees['montant']+$donnees['fre']+$donnees['frc']+$donnees['frq'];
                                  $bdd->exec("UPDATE demandes_adde_tmp SET solde='".$solde."' WHERE  coded='".$donnees['coded']."'");
                             

                                if($req)
                                {
                                 //$bdd->exec(" DELETE FROM demandes_tmp WHERE idd = ".$donnees['idd']);
                                 echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CONFIRMER_ADDE.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>'; 
                                }

                              }
                              else 
                              {
                              echo '<b><script type="text/javascript"> alert(\'Votre demande a deja été pris en compte . redirection sur les details \');</script></b>';
                              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.EDITER_ADDE.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>';


                              }                


              }
              }
              }
              
?>



</div></div></div></div></div>

















        





















































































































































                 


                     
             
               

            
             
            <br> <br> 



















































































































































     <!--<div class="alert alert-danger"style="font-size:14px; background-color:skyblue;border-color:skyblue;color:white;border-radius:20px;visibility: visible; animation-name:fadeInRightBig">
    <center><i class="fa fa-bullhorn"id="DivClignotantesiaka"></i> Salut !!!  <b> utilisateur .</b> Veillez avant de continuer prévoir une image de la copie de l'original de l'acte de naissance que vous allez uploader apres le remplissage du formualaire</center>
    </div>-->
            <!-- Earnings (Monthly) Card Example 
                <div class="card-body"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.20)!important;background-color:white">












                 


                     
             
               

                </div>-->
             
            <br> <br> 
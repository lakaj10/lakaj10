
<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
             <h1 class="h3 mb-0 text-800"style="color:<?php echo GAUCHE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-headphones fa-1x "style="color:<?php echo GAUCHE;?>"></i> Dicussion instantanée </h1>

          
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Dicussion instantanée </li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->



          <!-- Row -->
         


                 <?php
                 $droitacces=1;
                  $connectes=1;
                 $reponse=$bdd->query('SELECT * FROM users  WHERE droitacces="'.$droitacces.'" AND connectes="'.$connectes.'" ORDER BY id ASC limit 0,5  ');
               
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                  if (count($res) == 0) 
                {
                    echo'  
                           <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">LISTE DU PERSONNEL SERVICE CLIENT :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                          </div><hr>
                          <div class="col-lg-12">
                          <div class="alert alert-danger">
                          <center> AUCUNS RESULTAT TROUVES  .</b></center>
                          </div></div></div></div></div>
                ';

                }
                else {
                echo'
                 <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                <div class="table-responsive condensed">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">LISTE DU PERSONNEL SERVICE CLIENT :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                </div>
                 <table class="table table-striped table-hover table-condensed">

                    <thead style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
                      <tr>
                        <th>Photot de profil</th>
                      
                        
                        <th>Nom & prénoms</th>
                        
                        <th>Statut</th>

                        
                       
                         <th colspan="5"style=""><center><b>ACTION</b></center></th>

                      </tr>
                    </thead>

                    <tfoot style="    color: #6e707e;background-color: #fff; border-color: #fff;">
                      <tr>
                        <th>Photot de profil</th>
                      
                        
                        <th>Nom & prénoms</th>
                        
                        <th>Statut</th>

                        
                    
                        <th colspan="5"style="color:orange"><center></center></th>

                      </tr>
                    </tfoot>

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody id="myInput">
                     
                      
                      <tr>
                          <td style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;"><center>';
                       
                        if(empty($donnees['photo'])) {
                        echo'<img  src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;height:30px;width:30px">';
                        }
                        else
                        {
                        echo'<img  src="./mvc/vues/img/photo/admin/'.$donnees['photo'].'" style="border-radius:100%;height:30px;width:30px">';
                        }

                        
                     echo'</center></td>

                      
                       
                        <td><centere>'.substr($donnees['nomprenoms'],0,30).' </center></td>
             
                         
                        <td style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;"><centerz>';
                        if($donnees['connectes']=='1')
                        {
                          echo'<b style="color:orange"><span class="badge badge-warning">En ligne</span></b>';
                        }
                        else
                        {
                        echo'<b style="color:blue">Non</b>';
                        }
                      
                        echo'</center></td>
                        
                     

                            <td><small><center><a class="float-center btn btn-primary btn-sm" href="./goodoo.php?webox='.DISCUSSION_INSTANTANEE.'&tokken_service='.$donnees['code'].'"> Discuter <i class="fas fa-chevron-right"></i></a></small></center></td>

                            

                                

                            
                   

                      </tr>
                     
              
            </tbody>';
                     }

                echo'</table>';
          }
          
          ?>
  </div>   </div>  </div>  </div>   <br> 



            
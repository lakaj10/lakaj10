

       <div class="modal fade" id="BIENVENUE" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true" style="visibility: visible; -webkit-animation: flip 3.9s ; ">

      <div class="modal-dialog modal-dialog-centered" role="document">
       <div class="modal-content"style="background:;border-color:white">
             <!--  <div class="modal-header"style="color:<?php //echo VALIDER;?>;  background:<?php //echo BODY;?>;border-bottom: 0.0rem solid <?php echo COULEUR;?> ;border-right:0px solid #eee">
         
              <center>  <i class="fas fa-fw fa-calendar"></i> <?php /*$date=getdate();
                $joura=date('d');
                $moisa=date('m');
                $anneea=date('Y');
                $jour=$joura.'/'.$moisa.'/'.$anneea;

              echo $jour; */?></center>
            
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>  -->
          
          <div class="modal-body">
      <center>   <b style="">commandez vos documents administratifs à distance ici sur .   </b></center>     <hr class="colorgraph" style=" height:8px;
                border-top: 0;
                background:#ff9900;
                border-radius: 0px;"><center> <b style="font-size:26px"><script language="JavaScript1.2" type="text/javascript">
var message="https://www.document-poro.ci"
var neonbasecolor="#00FF00"
var neontextcolor="#0F056B"
var flashspeed=90
var n=0
if (document.all||document.getElementById){
document.write('')
for (m=0;m<message.length;m++)
document.write('<span id="neonlight'+m+'">'+message.charAt(m)+'<\/span></font>')
document.write('')
}
else
document.write(message)

function crossref(number){
var crossobj=document.all? eval("document.all.neonlight"+number) : document.getElementById("neonlight"+number)
return crossobj
}

function neon(){

//Change all letters to base color
if (n==0){
for (m=0;m<message.length;m++)
//eval("document.all.neonlight"+m).style.color=neonbasecolor
crossref(m).style.color=neonbasecolor
}

//cycle through and change individual letters to neon color
crossref(n).style.color=neontextcolor

if (n<message.length-1)
n++
else{
n=0
clearInterval(flashing)
setTimeout("beginneon()",200)
return
}
}

function beginneon(){
if (document.all||document.getElementById)
flashing=setInterval("neon()",flashspeed)
}
beginneon()

</script>    <!--<span class="wow fadeInRight" data-wow-delay="0.9s"style="color:black">Thanzol</span><span class="wow fadeInRight" data-wow-delay="0.9s"style="color:#0F056B">man</span>-->

<script language="JavaScript1.2" type="text/javascript">

var neonbasecolor="#fff"
var neontextcolor="orange"
var flashspeed=200

</script> </b></center>
              <!--Pour aider les utilisateurs à avoir ses documents dans tout le pays ou qu'ils se trouvent . Cette interface est facile à utiliser avec des formulaires en ligne à renseigner pour effectuer la demande  <hr>  <center> <i class="fas fa-phone"></i> Mobile :  0709071389 &nbsp;&nbsp;&nbsp;&nbsp;<i class="fas fa-envelope"></i> Email : info@document-poro.ci </center> -->
          </div>
         
        
        </div>
      </div>
    </div>
    
    </div>

    <script>
  $(document).ready(function () {
    $("#BIENVENUE").modal('show');
  });
//made by csandreas1 for Stackoverflow
</script>





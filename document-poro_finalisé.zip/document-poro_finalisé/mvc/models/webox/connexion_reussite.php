

 <?php

           sleep(2);
           echo'<center> <i class="fa fa-spinner fa-spin fa-5x"style="color:'.VALIDER.';margin:8% auto;"></i><br><small> CONNEXION REUSSITE , VEILLEZ PATIENTER . REDIRECTION EN COURS DANS 10S ...</small></center><META HTTP-EQUIV="refresh" CONTENT="10; URL=./goodoo.php?webox='.DASHBOARD.'">';

            //echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./woodoo.php?webox='.CONNEXION_REUSSITE.'"</SCRIPT>'; 

            //exit();

    
?>


       




const express = require("express");
var request = require('request');
var db = require("mysql");
const fetch = require('node-fetch');
const xml2js = require('xml2js');
const moment = require('moment');
const rssJson = require('./rssJson');
const app = express();
app.use(express.json());
app.use(
  express.urlencoded({
    extended: true,
  })
);
var connection = db.createConnection({
    host:"localhost",
    user:"kamagate",
    password:"kass",
    database : "articleApiNodejs"
})
  
// Connecting to database
connection.connect(function(err) {
    if(err){
      console.log("Error in the connection")
      console.log(err)
    }
    else{
      console.log(`Database Connected`)
      connection.query(`SHOW DATABASES`, 
      function (err, result) {
        if(err)
          console.log(`Error executing the query - ${err}`)
        else
          console.log("Result: ",result) 
      })
    }
})
 /* List of Middleware */

// Import Rss feed and register in bd to JSON format
app.post('/api/articles/import?', (req, res, next) => {
    request('https://lemonde.fr/rss/une.xml', (error,res,body) => {
      
      xml2js.parseString(body, (err, result) => {
        if(err) {
            throw err;
        }
      const rawContent = JSON.stringify(result, null, 4);
      console.log(rawContent);
      var sql = "INSERT INTO importData (importDate,rawContent ) VALUES ?";
      const importDate = moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
      var values = [   
        [ `${importDate}`, `${rawContent}`]
      ]
      connection.query(sql,[values],(err, result) => {
        if (err) throw err;
        console.log('record inserted:' +result.affectedRows);
      }); 
    });   
    });
  });

  // Routes to insert articles in bd
app.get('/api/articles/insert', (req, res) => {
    var sql = "SELECT rawContent FROM  importData limit 1 ";
    const jsonBrut = JSON.stringify(rssJson, null, 4);;
    connection.query(sql,(err, result) => {
      if (err) {
        throw err;
      } 
      const rawContent = JSON.stringify(result, null, 4);
      //console.log(rawContent);
       const a = JSON.parse(jsonBrut);
       const b = (Object.values(a)[0].channel);
       const c = JSON.stringify(b);
       //console.log(c);     
      // inserer les articles dans la bases de données via la table articles
      var sql = "INSERT INTO articles (title,publicationDate,description,externalId,lnk,importDate,mainPicture ) VALUES ?";
      const importDate = moment(new Date()).format('YYYY-MM-DD HH:mm:ss');
      const title = c.title;
      //console.log(title);
      const pubDate = '23-01-2021';
      //const  pubDate = aDate.toString();
      const description = c.description;
      const externalId = c.guid;

      /*  lnk replace link in json structure here*/
      const lnk = c.lnk;
      const mainPicture = c.mainPicture;
      var values = [   
        [ `${title}`,`${pubDate}`,`${description}`,`${externalId}`,`${lnk}`,`${importDate}`,`${mainPicture}`]
      ]
      connection.query(sql,[values],(err, result) => {
        if (err) throw err;
        console.log('articles inserted:' +result.affectedRows);
      });
    });
  });

  //Route to get article from bd
app.get ('/api/articles', (res, req) => {
  var sql = "SELECT * FROM  articles limit 1 ";
  connection.query(sql,(err, result) => {
    if (err) throw err;
    console.log(result);
  }); 
});

module.exports = app;
const http = require('http');
const express = require("express");
const app = require('./app');
const port = 4000;


app.use(express.json());
app.use(
  express.urlencoded({
    extended: true,
  })
);

app.get("/", (req, res) => {
  res.json({ message: "ok" });
});


/* Error handler middleware */
app.use((err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  console.error(err.message, err.stack);
  res.status(statusCode).json({ message: err.message });

  return;
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});

/*
const normalizePort = val=> {
    const port = parseInt(val, 10);

    if (isNaN(port)) {
        return val;
    }
    if (port >=0) {
        return port;
    }
    return false;
};
const port = normalizePort(process.env.PORT || '3000');
app.set('port', port);

const errorHandler = error => {
    if (error.sycall !== 'listen') {
        throw error;
    }
    const address = server.address();
    const bind = typeof address === 'string' ? 'pipe' +address : 'port' + port;
    switch (error.code) {
        case 'EACCES': 
        console.error(bind + 'requires elevated privileges.');
        process.exit(1);
        break;
        case 'EADDRINUSE':
            console.error(bind + 'is already in use');
            process.exit(1);
            break;
            default:
              throw error;
            
    }
};
const server = http.createServer(app);

server.on('error', errorHandler);
server.on('listening', () => {
    const address = server.address();
    const bind = typeof address === 'string' ? 
    'pipe' + address : 'port' +port;
    console.log('Listening on ', +bind);

});

server.listen(port);
*/
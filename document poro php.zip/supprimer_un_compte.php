
<?php include './mvc/config/config.php'; ?>


 <?php 
  
	 if(isset($_GET['webox']))
	  {
	      $webox=$_GET['webox'];
	      if($webox==FERMERTURE)

	      {
	      	$id=htmlspecialchars($_GET["id"]) ;
			$bdd->exec(" DELETE FROM users WHERE id = ".$id);

			if($bdd)
			{
				$_SESSION = array();
            session_destroy();
			 echo '<script type="text/javascript"> alert(\'           SUPPRESSION DU COMPTE EFFECTUEE AVEC SUCCES          \');</script>';

			echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./woodoo.php?webox='.OUVERTURE.'"</SCRIPT>';
			}
	     }
  }   

?>


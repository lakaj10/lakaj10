<?php include './mvc/config/config.php'; 
//var_dump($_SESSION);

if(empty($_SESSION['pseudo']))
{
  //echo '<b><script type="text/javascript"> alert(\'Vous ne pouvez pas accéder à cette page. Connectez vous avant\');</script></b>';

    //echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="index.php"</SCRIPT>';

}
else{

}        
?>


<!DOCTYPE html>
<html lang="fr">

<head>
  <script>
function checkpseudoAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'pseudo='+$("#pseudo").val(),
type: "POST",
success:function(data){
$("#pseudo-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){
}
});
}
</script>
 
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Favicon-->
      <!-- Author Meta -->
      <meta name="author" content="nivodex">
      <!-- Meta Description -->
    <meta name="description" content="Découvre les résultats des examens">
    <meta name="keywords" content="résultats, examens, résultats en ligne">
    <meta charset="UTF-8">
      <!-- Site Title -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <meta content="fr" http-equiv="Content-Language">
      <meta content="search engine" name="Classification">
      <meta content="Documents-poro.ci, La Poste Côte d&#39;Ivoire" name="Author">
      <meta content="Documents-poro.ci est le premier site de commande de document en ligne." name="description">
      <meta content="document administratif, extrait de naissance Abidjan, acte de mariage Abidjan, demande d&#39;acte de naissance Abidjan,acte de décès Abidjan, demande d&#39;acte de décès Abidjan, légalisation de signature , dossier en ligne Abidjan, dossiers de concours Abidjan, côte d&#39;ivoire, ivory coast, la poste ci, la poste, poste ci, douments en ligne Abidjan, demande d&#39;acte civil Abidjan, demande d&#39;actes de justice Abidjan, déclaration de naissance, ministère de la justice ci, papiers en ligne" name="keywords">
      <meta content="@2016 Documents-poro.ci" name="copyright">
      <meta content="180" http-equiv="refresh">
      <meta content="0" http-equiv="Expires">
      <meta content="no-cache" http-equiv="Pragma">
      <meta content="Lumens Corp." name="organization">
      <meta content="General" name="Audience">
      <meta content="090212" name="date-revision-ddmmyyyy">
      <meta content="Global" name="Distribution">
      <meta content="never" name="expires">
      <meta content="https://www.documents-poro.ci/" name="identifier-url">
      <meta content="Document" name="Page-topic">
      <meta content="Lumens Corp." name="publisher">
      <meta content="General" name="Rating">
      <meta content="all, index, follow" name="Robots">
      <meta content="Documents-poro.ci est le premier moteur de commande de document en ligne de la Côte d&#39;Ivoire a Abidjan, Cote d&#39;Ivoire, Ivory Coast" name="subject">
  <link href="./mvc/vues/img/logo/siaka.png" rel="icon">
    <title> <?php 
  
   if(isset($_GET['webox']))
    {
        $webox=$_GET['webox'];
       if($webox==OUVERTURE)
        {  
         echo 'CONNEXION';
                         
        }
        elseif($webox==CONNEXION_REUSSITE)
        {  
         echo 'CONNEXION REUSSITE';
                         
        }
        elseif($webox==REGISTER)
        {  
        echo 'INSCRIPTION';
         
        }
         elseif($webox==DECONNEXION)
        {  
        echo 'DECONNEXION';
         
        }
         elseif($webox==REUSSITE)
        {  
         echo 'INSCRIPTION REUSSITE';
          

      }

       elseif($webox==ACTIVATION)
        {  
       echo 'COMPTE ACTIVE';
          

      }
       elseif($webox==LOADING)
        {  
       echo 'CHARGEMENT EN COURS ...';
          

      }
        elseif($webox==MESSAGE)
        {  
       echo 'CONNEXION';
          

      }
       elseif($webox==COOKIES)
        {  
          echo 'ACCEPTATION COOKIES';
          

      }
         elseif($webox==HOME)
        {  
        echo 'ACCUEIL';
         
        }
         elseif($webox==FORGOT)
        {  
        echo 'MOT DE PASSE OUBLIE';
         
        }
        
      else
        {
              echo 'CONNEXION';         


      }
  }   

?></title>
  <?php 
############################################################################################################################################

if(isset($_GET['webox']))
{
      $webox=$_GET['webox'];
if($webox==REUSSITE)
{
    echo'  <script type="text/javascript" src="./jquery.js"></script>
      <script type="text/javascript" src="./jquery-ui.js"></script>';
}
elseif($webox==ACTIVATION)
{
    echo'  <script type="text/javascript" src="./jquery.js"></script>
      <script type="text/javascript" src="./jquery-ui.js"></script>';
}
elseif($webox==MESSAGE)
{

    echo'  <script type="text/javascript" src="./jquery.js"></script>
      <script type="text/javascript" src="./jquery-ui.js"></script>';
}
}   
############################################################################################################################################

?>
    <link href="<?php echo URL; ?>mvc/design/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo URL; ?>mvc/design/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo URL; ?>mvc/design/css/ruang-admin.min.css" rel="stylesheet">
        <link href="<?php echo URL; ?>mvc/design/css/ruang-admin.css" rel="stylesheet">
        <link href="<?php echo URL; ?>mvc/design/css/animate.css" rel="stylesheet">
</head>
<body id="page-top"style="background:<?php echo BODY3;?>;"oncontextmenu="return false">

<script language="javascript">
  document.onmousedown=disableclick;status="Right Click Disabled";Function disableclick(e){if(event.button==2){alert(status);return false;}}
  

</script>

<div class="loader">
<h1></h1>
</div>


         <?php 
  
   if(isset($_GET['webox']))
    {
        $webox=$_GET['webox'];
       if($webox==OUVERTURE)
        {  
         
        include('./mvc/models/webox/login.php');  

                         
        }
        elseif($webox==REGISTER)
        {  
          include('./mvc/models/webox/register.php');
         
        }
         elseif($webox==REUSSITE)
        {  
          include('./mvc/models/webox/login.php');  
          include('./mvc/models/webox/reussite.php');
          

      }

       elseif($webox==ACTIVATION)
        {  include('./mvc/models/webox/login.php');
          include('./mvc/models/webox/activer.php');
          

      }
       elseif($webox==MESSAGE)
        {  include('./mvc/models/webox/login.php');
       //sleep(5);
          include('./mvc/models/webox/message_de_bienvenue.php');
          

      }
       elseif($webox==LOADING)
        {  
          include('./mvc/models/webox/chargement.php');
          

      }
       elseif($webox==MESSAGE2)
        {  include('./mvc/models/webox/login.php');
       //sleep(5);
          include('./mvc/models/webox/message2.php');
          

      }
       elseif($webox==COOKIES)
        {  
          include('./cookie_accept.php');
          

      }
         elseif($webox==FORGOT)
        {  
          include('./mvc/models/webox/forgot.php');
         
        }
         elseif($webox==HOME)
        {  
          include('./mvc/models/webox/acceuil.php');
         
        }
         elseif($webox==LISTE_DES_TARIFS)
        {  
             include('./mvc/models/webox/liste_des_tarifs.php');
             echo "<br><br><br>";
         
        }
         elseif($webox==CONNEXION_REUSSITE)
        {  
          include('./mvc/models/webox/connexion_reussite.php');
                         
        }
         elseif($webox==DECONNEXION)        
          {
            if(isset($_GET['identifiant_a_deconnecter']))
            {
            
            $id=htmlspecialchars($_GET['identifiant_a_deconnecter']);
            
            $req=$bdd->prepare("SELECT * FROM users where id='".$id."'");

            if($req){
            $connectes=0 ;
            $bdd->exec("UPDATE users SET connectes='".$connectes."' WHERE id='".$id."'"); 
            //exit();
            }
           
          if($bdd) {
           $_SESSION = array();
            session_destroy();
            sleep(2);
            echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./woodoo.php?webox='.OUVERTURE.'&tokken='.TOKKEN.'"</SCRIPT>';          
            
          }
           } 
            }
      else
        {
       // sleep(1);
         echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./woodoo.php?webox='.OUVERTURE.'"</SCRIPT>';          


      }
  }   

?>
         

      <?php
    if(isset($_COOKIE['accept_cookie'])) {
    $showcookie = false;
    } else {
    $showcookie = true;
    }

    if($showcookie) { 
//echo'<div class="accept-cookies d-none-soft" style="display: block;"> En utilisant cette application, vous acceptez l\'utilisation de cookies
  //<span class="hidden-sm-down"> . &nbsp;&nbsp;<a href="cookie_accept.php"style="color:#ffa">j\'accèpte la condition</a></span></div>'; 

  echo'<div class="accept-cookies d-none-soft" style="display: block;">En poursuivant votre navigation sur ce site, vous acceptez l’utilisation de cookies pour vous proposer des contenus et services adaptés à vos centres d’intérêts<span class="hidden-md-up">.</span> &nbsp;&nbsp;<a href="cookie_accept.php"style="color:#ffa;text-decoration:none" aria-label="dismiss cookie message" role="button" tabindex="0" class="btn btn-info btn-sm waves-effect waves-light ">D\'accord</a></div>';     
    }
?>
 <style>  
.accept-cookies {
    position: fixed;
    text-align: center;
    bottom: 8px;
    left: 50%;
    transform: translateX(-50%);
    background-color:#ffF;
    color:;
    width: 100%;
  
    z-index: 104;
    border-radius: 4px;
   padding: 0.6em;
}
.inf, .cad_inf {
  margin: 0px;padding: 0px;
    background-color: #D00;
    color: #FFF;
    padding: 10px 10px;
    font-family: Oswald;
    font-weight: bold;

}
</style>
       
 <!---->



 <div class="container-login">
    <div class="row justify-content-center">
      <div class="col-xl-6 col-lg-12 col-md-12">
<table>
<tbody><tr>  
<td class="cad_inf"> <b id="DivClignotante2"style="background-color:#17bb64; color:#FFF; font-weight:bold; font-family:arial ;"><center>INFOS
<?php 
/***/


          $reponse=$bdd->query("SELECT * FROM infosvue WHERE ip='".$_SERVER['REMOTE_ADDR']."'");
          $res=$reponse->fetchAll();

          $ip=$_SERVER['REMOTE_ADDR'];

          if(count($res)==0)   // L'IP ne se trouve pas dans la table, on va l'ajouter.
          {   
          $req= $bdd->prepare('INSERT INTO infosvue(ip)VALUES(?)');
          $req->execute(array($ip));

          }  
  

      $reponse=$bdd->query("SELECT COUNT(*) AS nbre_entrees FROM infosvue"); while($donnees = $reponse ->fetch())
      {
        $ret = $bdd->query('SELECT * FROM infos ORDER BY id DESC LIMIT 0, 1');
            if($dot = $ret->fetch())
            {
              $dot['vue']=$donnees['nbre_entrees']+1;

            }
      
      } 

?>  
</center> </b>  </td>                                               
<td style="background-color:#fff;width:100%; font-weight:bold; font-family:arial black; color:#444; ;text-transform:uppercasee">                                                   

<marquee crolldelay="4" scrollamount="4" onmouseout="this.start()" onmouseover="this.stop()" class="Scroller">

 <?php
 /* */
    $reponse = $bdd->query('SELECT * FROM infos ORDER BY id DESC LIMIT 0, 1');

    if ($donnees = $reponse->fetch())
    {

    echo '<span style="padding-bottom:200px;color:red;vertical-align: middle;">'.strtoupper($donnees['titre']).'</span><span style="color:black; font-weight:normal;font-size:16px; font-family:verdana;"> : '.ucfirst($donnees['contenu']).'</span>';

    }
    else
    {
    echo '<span style="padding-bottom:200px;color:white;vertical-align: middle;font-weight:normal;font-size:16px; font-family:verdana;">Document-poro vous souhaite la bienvenue sur le site officiel et une bonne et heureuse année </span>';
    }
   
?>


<?php
    /* 
    $reponse = $bdd->query('SELECT * FROM actualite ORDER BY id DESC LIMIT 0, 1');

    if ($donnees = $reponse->fetch())
    {

    echo '<strong style="color:#ffa;text-transform: uppercase;font-weight:bolder">ACTU</strong></b>&nbsp;/&nbsp;<strong style="color:white;">'.$donnees['titre'].'</strong></b></font>&nbsp;<font color="#6c7277">:&nbsp;'.ucfirst($donnees['contenu']).'</font></font>&nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; </font>&nbsp; &nbsp;';

    }
    */

?>

</marquee> 
</td>            

</tr>
</tbody></table>
</div></div> </div> 
<br>






  <!-- Scroll to top -->

<?php  include('./mvc/models/webox/image_du_bas.php');  ?>



 <script type="text/JavaScript">
var clignotement = function(){ 
if (document.getElementById('DivClignotante2').style.visibility=='visible'){ 
document.getElementById('DivClignotante2').style.visibility='hidden'; 
} 
else{ 
document.getElementById('DivClignotante2').style.visibility='visible'; 
} 
}; 
periode = setInterval(clignotement, 800);

</script>




<!-- Scroll to top -->
<a class="scroll-to-top" href="#page-top"style="background:;border-radius:">
<i class="fas fa-angle-up"></i>
</a>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="jquery-ui.js"></script>
<script src="<?php echo URL; ?>mvc/design/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo URL; ?>mvc/design/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo URL; ?>mvc/design/vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="<?php echo URL; ?>mvc/design/js/ruang-admin.min.js"></script>
<script src="<?php echo URL; ?>mvc/design/vendor/chart.js/Chart.min.js"></script>
<script src="<?php echo URL; ?>mvc/design/js/demo/chart-area-demo.js"></script>  
</body>

</html>

<style type="text/css">
 .sticky-footer{

position: absolute;right: 0;bottom: 0;left: 0;background-color:#393c3d;text-align: center;max-width:100%;padding: 10px 30px;
}
 {
margin: 0px;padding: 0px;
}
div {
display: block;

}

.sidebar {
   
    -webkit-box-shadow: 0 0.15rem 1.75rem 0 rgb(58 59 69 /15%) !important;
    box-shadow: 0 0.15rem 1.75rem 0 rgb(58 59 69 / 15%) !important;
   
}
.card {
    -webkit-box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;
    box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;
}
</style>

     <br> <footer class="sticky-footer"style="  padding: .9rem 1rem;background:<?php echo FOOTER;?>;border-bottom: 0.45rem solid <?php echo GAUCHE;?> ;border-top: 0.45rem solid <?php echo GAUCHE;?> ;box-shadow:  0 0.15rem 1.75rem 0 rgb(58 59 69 / 15%)!important;">
        <div class="container my-auto">
          <div class="copyright text-center my-auto"style="color:#666;font-size:16px">
            <span >   <i class="fa fa-arrow-righte"></i>  Copyright &copy;
            <script> document.write(new Date().getFullYear()); </script> - Developped & Designed by  <!--<b style="font-size:25px;font-family:mistral;color:#ff9900">thanzol</b><b style="font-size:25px;font-family:mistral;color:#36a03b">man</b> -->  <img src="./mvc/vues/img/logo/siaka.png" style=" height:18px;width:18px" alt="souci d\'affichage"><img src="./mvc/vues/img/logo/cccc.png" style=" height:18px;width:100px" alt="souci d\'affichage"> 
            
          </span>
          </div>
        </div>
      </footer>


 <?php  include('./mvc/models/webox/image_du_bas.php');  ?> 



      <div class="modal fade" id="DECONNEXION" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document"style="visibility: visible; -webkit-animation: fadeInLeft 3.2s ; ">
           <div class="modal-content"style="background:transparent;border-color:white">
               <!-- <div class="modal-header"style="color:<?php //echo COULEURT;?>;  background:<?php //echo COULEUR;?>;border-bottom: 0.0rem solid <?php //echo COULEUR;?> ;border-right:0px solid #eee">
         
              <center>     <i class="fas fa-power-off fa-sm fa-fw mr-2 text-gray-4"></i>Confirmation de la déconnexion en cours ...</b></center>
            
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>  -->
          

          <div class="modal-body">
          
            <small><center> 
            	 <button type="button"style="border-radius:20px" class="btn btn-warning  btn-sm waves-effect waves-light"data-dismiss="modal">Abandonner</button>  &nbsp;&nbsp; <a href="./woodoo.php?webox=<?php echo DECONNEXION;?>&identifiant_a_deconnecter=<?php echo $_SESSION['id'];?>"><button type="button"style="border-radius:20px" class="btn btn-danger btn-sm waves-effect waves-light ">Deconnexion</button></a>

            </center>
              
          </small>

          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>
    
  $(document).ready(function () {
    $("#DECONNEXION").modal();
  });
//made by csandreas1 for Stackoverflow
</script>












      <div class="modal fade" id="INTERVALLE" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document"style="visibility: visible; -webkit-animation: fadeInLeft 3.2s ; ">
           <div class="modal-content"style="background:transparent;border-color:transparent;">
              

          <div class="modal-body">
                <form role="form"class="navbar-search"action="./goodoo.php?webox=<?php echo SEARCH_DAY;?>" method="GET"autocomplete="off">
                    <input type="hidden"  name="webox"value="<?php echo SEARCH_DAY;?>">
            <div class="form-group" id="simple-date4">
                    <label for="dateRangePicker">Range Select</label>
                    <div class="input-daterange input-group">
                       
                      <input type="date" class="input-sm form-control" name="Start"required="">
                      <div class="input-group-prepend">
                        <span class="input-group-text"style="background:<?php echo BODY;?>;border:1px solid <?php echo BODY;?>;color:black">AU</span>
                      </div>
                      <input type="date" class="input-sm form-control" name="End"required="">
                       <div class="input-group-prepend">
                        <button type="submit" class="input-group-text"style="background:<?php echo COULEUR;?>;border:1px solid <?php echo COULEUR;?>;color: "><i class="fas fa-fw fa-search"></i> </button>
                      </div>
                    
                    </div>
                  </div>
              </form>
          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>
    
  $(document).ready(function () {
    $("#INTERVALLE").modal();
  });
//made by csandreas1 for Stackoverflow
</script>





 <div class="modal fade" id="DEMANDE" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document"style="visibility: visible; -webkit-animation: fadeInLeft 3.2s ; ">
        <div class="modal-content"style="background:transparent;border-color:white">
              <!--  <div class="modal-header"style="color:<?php echo COULEURT;?>;  background:<?php //echo COULEUR;?>;border-bottom: 0.0rem solid <?php //echo COULEUR;?> ;border-right:0px solid #eee">
          
              <center>     <i class="fas fa-check-circle fa-sm fa-fw mr-2 text-gray-4"></i>Activation d'une demande en cours de traitement ...</b></center>
            
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div> -->
          
          <div class="modal-body">
          

                    <form role="form"class="navbar-search"action="./goodoo.php?webox=<?php echo SEARCH;?>" method="GET"autocomplete="off">
                        <input type="hidden"  name="webox"value="<?php echo SEARCH;?>">
                  <div class="input-group">
                                <?php
                                /*
                                $reponse=$bdd->query('SELECT*FROM demandes ORDER By coded ASC limit 0, 10000');

                                $nb_resultats = $reponse->rowCount(); 
                                $res = $reponse->fetchAll();
                                if (count($res) == 0) 
                                {
                                echo'

                                ';

                                }
                                else {
                                echo'<select class="form-control "autocomplete="on"name="SearchBrowserData">' ;
                                foreach ($res as $donnees) {
                                echo ' <option value="'.$donnees['coded'].'">'.$donnees['coded'].'&nbsp;&nbsp; --  '.$donnees['categorie'].'</option> ';
                                }
                                }
                                echo'</select>';
                                */
                                ?>          
                   <input type="search" name="SearchBrowserData" autofocus="" class="form-control bg-light border-1 small" placeholder="Rechercher la demande " aria-label="Search" aria-describedby="basic-addon2" style="border-color: blue;font-family:arial;color:silver;text-align: centerd"required>
                    <div class="input-group-append">
                      <button class="btn btn-warning progress-bar progress-bar-striped progress-bar-animated bg-warning" type="submit"value="search"style="background:">
                        <i class="fas fa-search fa-sm"></i> 
                      </button>
                    </div>
                  </div>
                </form>
             

                 
          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>
  $(document).ready(function () {
    $("#DEMANDE").modal();
  });
//made by csandreas1 for Stackoverflow
</script>











 <div class="modal fade" id="MONTANT" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document"style="visibility: visible; -webkit-animation: fadeInLeft 3.2s ; ">
           <div class="modal-content"style="background:transparent;border-color:white">
              <!--  <div class="modal-header"style="color:<?php echo COULEURT;?>;  background:<?php //echo COULEUR;?>;border-bottom: 0.0rem solid <?php //echo COULEUR;?> ;border-right:0px solid #eee">
          
              <center>     <i class="fas fa-check-circle fa-sm fa-fw mr-2 text-gray-4"></i>Activation d'une demande en cours de traitement ...</b></center>
            
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div> -->
          
          <div class="modal-body">
          

                    <form role="form"class="navbar-search"action="./goodoo.php?webox=<?php echo SEARCHMONTANT;?>" method="GET">
                        <input type="hidden"  name="webox"value="<?php echo SEARCHMONTANT;?>">
                  <div class="input-group">
                                <?php
                                /* */
                                $reponse=$bdd->query('SELECT*FROM tarif ORDER By nom ASC limit 0, 10000');

                                $nb_resultats = $reponse->rowCount(); 
                                $res = $reponse->fetchAll();
                                if (count($res) == 0) 
                                {
                                echo'

                                ';

                                }
                                else {
                                echo'<select class="form-control "autocomplete="off"name="SearchBrowserData">' ;
                                foreach ($res as $donnees) {
                                echo ' <option value="'.$donnees['nom'].'">'.urldecode($donnees['nom']).'</option> ';
                                }
                                }
                                echo'</select>';
                               
                                ?>          
                                
                                <?php
                                /* */
                                $reponse=$bdd->query('SELECT*FROM tarif ORDER By nom ASC limit 0, 10000');

                                $nb_resultats = $reponse->rowCount(); 
                                $res = $reponse->fetchAll();
                                if (count($res) == 0) 
                                {
                                echo'
                                    <span style="color:orange"> <center> IL N\'Y A RIEN EN CE MOMENT DANS LA CAISSE : 0 FCFA</center></span>  
                                ';

                                }
                                else {
                                  echo'  <div class="input-group-append">
                      <button class="btn btn-warning progress-bar progress-bar-striped progress-bar-animated bg-warning" type="submit"value="search"style="background:">
                        <i class="fas fa-search fa-sm"></i> 
                      </button>
                    </div>';
                                }
                                
                               
                                ?>          
                  
                  
                  </div>
                </form>
             

                 
          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>
  $(document).ready(function () {
    $("#MONTANT").modal();
  });
//made by csandreas1 for Stackoverflow
</script>















      <div class="modal fade" id="COMPTE" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document"style="visibility: visible; -webkit-animation: fadeInLeft 3.2s ; ">
           <div class="modal-content">
        
          <div class="modal-body">
        
          
          <?php 
if( isset($_SESSION['id']))
{

$req = $bdd->query('SELECT * FROM users where id="'.$_SESSION['id'].'"');
$donnees = $req->fetch();
if($donnees)
{


echo 
'           
          <a class="dropdown-item align-items-center" href="#">
                  <div class="mb-3">
                    <div class="small text-gray-500"> <i class="fas fa-camera"></i>  PHOTO 
                      <div class="float-right">';

                  if(empty($donnees['photo'])) {
                    echo'<img class="img-profile" src="./mvc/vues/img/logo/avatar.png" style="border-radius:100%;max-width: 60px;height:30px;width:30px">';
                }
                else
                {
                       echo'<img class="img-profile" src="./mvc/vues/img/photo/users/'.$donnees['photo'].'" style="border-radius:100%;max-width: 60px;height:30px;width:30px">';
                }
                 
                      echo'</b></div>
                    </div>
                    <div class="progress" style="height:6px;">
                      <div class="progress-bar bg-warning" role="progressbar" style="width:0%" aria-valuenow="50"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                  </div>
                </a>

              <a class="dropdown-item align-items-center" href="#">
                  <div class="mb-3">
                    <div class="small text-gray-500"> <i class="fas fa-user-circle"></i>  COMPTE
                      <div class="float-right"><b style="color:#ff9900">'.strtoupper($donnees['compte']).'</b></div>
                    </div>
                    <div class="progress" style="height:6px;">
                      <div class="progress-bar bg-warning" role="progressbar" style="width:0%" aria-valuenow="50"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                  </div>
                </a>
              
                <a class="dropdown-item align-items-center" href="#">
                  <div class="mb-3">
                    <div class="small text-gray-500"><i class="fas fa-bookmark"></i>  IDENTIFIANT
                      <div class="float-right"><b style="color:#ff9900">'.$donnees['code'].'</b></div>
                    </div>
                    <div class="progress" style="height:6px;">
                      <div class="progress-bar bg-warning" role="progressbar" style="width:0%" aria-valuenow="50"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                  </div>
                </a>
                <a class="dropdown-item align-items-center" href="#">
                  <div class="mb-3">
                    <div class="small text-gray-500"><i class="fas fa-user"></i>  NOM & PRENOMS
                      <div class="float-right"><b style="color:#ff9900">'.$donnees['nomprenoms'].'</b></div>
                    </div>
                    <div class="progress" style="height:6px;">
                      <div class="progress-bar bg-warning" role="progressbar" style="width:0%" aria-valuenow="50"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                  </div>
                </a>

                 <a class="dropdown-item align-items-center" href="#">
                  <div class="mb-3">
                    <div class="small text-gray-500"> <i class="fas fa-phone"></i> TELEPHONE
                      <div class="float-right"><b style="color:#ff9900">'.$donnees['mobile'].'</b></div>
                    </div>
                    <div class="progress" style="height:6px;">
                      <div class="progress-bar bg-warning" role="progressbar" style="width:0%" aria-valuenow="50"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                  </div>
                </a>

                <a class="dropdown-item align-items-center" href="#">
                  <div class="mb-3">
                    <div class="small text-gray-500"> <i class="fas fa-envelope"></i>  ADRESSE EMAIL
                      <div class="float-right"><b style="color:#ff9900">'.substr($donnees['email'],0,50).'</b></div>
                    </div>
                    <div class="progress" style="height:6px;">
                      <div class="progress-bar bg-warning" role="progressbar" style="width:0%" aria-valuenow="50"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                  </div>
                </a>

               <!--  --><a class="dropdown-item align-items-center" href="#">
                  <div class="mb-3">
                    <div class="small text-gray-500"><i class="fas fa-graduation-cap"></i>  NOM UTILISATEUR
                      <div class="float-right"><b style="color:#ff9900">'.$donnees['pseudo'].'</b></div>
                    </div>
                    <div class="progress" style="height:6px;">
                      <div class="progress-bar bg-warning" role="progressbar" style="width:0%" aria-valuenow="50"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                  </div>
                </a>

                <a class="dropdown-item align-items-center" href="#">
                  <div class="mb-3">
                    <div class="small text-gray-500"> <i class="fas fa-lock"></i> MOT DE PASSE
                      <div class="float-right"><b style="color:#ff9900">'.$donnees['mdpcrypte'].'</b></div>
                    </div>
                    <div class="progress" style="height:6px;">
                      <div class="progress-bar bg-warning" role="progressbar" style="width:0%" aria-valuenow="75"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                  </div>
                </a>';
                if($_SESSION['droitacces']== 2)
                {

                   echo'<a class="dropdown-item align-items-center" href="#">
                  <div class="mb-3">
                    <div class="small text-gray-500"><i class="fas fa-calendar"></i>  DATE D\'INSCRIPTION
                      <div class="float-right"><b style="color:#ff9900">'.$donnees['dateins'].'</b></div>
                    </div>
                    <div class="progress" style="height:6px;">
                      <div class="progress-bar bg-warning" role="progressbar" style="width:0%" aria-valuenow="75"
                        aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                  </div>
                </a>';
          }
         
                        

    }
    }
?>
          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>


  $(document).ready(function () {
    $("#COMPTE").modal();
  });
//made by csandreas1 for Stackoverflow
</script>























      <div class="modal fade" id="SERVICE_CLIENT" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document"style="visibility: visible; -webkit-animation: fadeInLeft 3.2s ; ">
           <div class="modal-content">
         
          <div class="modal-body">
        
          
          <?php 
if( isset($_SESSION['id']))
{

                      $connectes=1;
                            $droitacces=1;
                          $reponse1=$bdd->query('SELECT * FROM users   WHERE connectes="'.$connectes.'"AND droitacces="'.$droitacces.'" ORDER BY nomprenoms ASC limit 0,4  ');

                            $res1 = $reponse1->fetchAll();
                            foreach ($res1 as $donnees) {

                            
                            echo'<a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">';
                              if(empty($donnees['photo'])) {
                              echo'<img class="rounded-circle" src="./mvc/vues/img/logo/boy.png"  style="max-width: 80px;width:70px;height:70px">';
                              }
                              else
                              {
                              echo'<img class="rounded-circle" src="./mvc/vues/img/photo/admin/'.$donnees['photo'].'"  style="max-width: 80px;width:70px;height:70px">';
                              }
                           
                            echo'<div class="status-indicator bg-success"></div>
                            </div>
                            <div>
                            <div class="text-truncate">'.substr($donnees['nomprenoms'],0,25).'</div>
                            <div class=" text-gray-500">   <i class="fas fa-phone"></i>  '.$donnees['mobile'].'</div>
                            </div>
                            </a> ';
          
         
                        

    }
    }
?>
          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>


  $(document).ready(function () {
    $("#SERVICE_CLIENT").modal();
  });
//made by csandreas1 for Stackoverflow
</script>












      <div class="modal fade" id="ANNIVERSAIRE" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document"style="visibility: visible; -webkit-animation: fadeInLeft 3.2s ; ">
           <div class="modal-content">
         
          <div class="modal-body">
         <?php
                           if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='2'){
                            $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                            $donnees=$req->fetch(); 
                          if($req){
                            // age actuelle du client
                         
                          $dna=$donnees['dna'];
                          $da=$donnees['da'];

                           if($da!='' AND $dna!='')
                          {
                      echo'
                      <center>  <i class="fas fa-fw fa-user-circle fa-1x "style="color:'.COULEURT.'"></i> Joyeux anniversaire à vous   ';
                  if($donnees['sexe']=="F"){
                      echo'Mme / Mlle';
                     }
                      elseif($donnees['sexe']=='H'){
                      echo'Mr';
                      }

                echo'<b> '.strtoupper($_SESSION['nomprenoms']).' . </b> pour vos 1 an de plus Aujourd\'hui . Vous avez actuellement <b style="color:red"> '.strtoupper($donnees['age']).' ANS</b> . <br>Toute l\'équipe de document-poro vous souhaite une longévité .</center>
                      ';
                          }
                          elseif($da=='' AND $dna=='')
                          {
                           echo' <center>Vous n\'avez pas de notification pour le moment</center>';
                          }
                        
                         
                  }
                  }
                        ?>
          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>


  $(document).ready(function () {
    $("#ANNIVERSAIRE").modal();
  });
//made by csandreas1 for Stackoverflow
</script>










      <div class="modal fade" id="FERMERTURE" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document"style="visibility: visible; -webkit-animation: fadeInLeft 3.2s ; ">
           <div class="modal-content"style="background:transparent;border-color:white">
            <!-- <div class="modal-header"style="color:<?php //echo COULEURT;?>;  background:<?php //echo GAUCHE;?>;border-bottom: 0.0rem solid <?php //echo COULEUR;?> ;border-right:0px solid #eee">
           
              <center>     <i class="fas fa-trash fa-sm fa-fw mr-2 text-gray-4"></i> êtes vous sûre de vouloir fermer le compte </b></center>
            
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>-->
          
          <div class="modal-body">
            <small><center>
            	 <button type="button"style="border-radius:20px;" class="btn btn-warning  btn-sm waves-effect waves-light"data-dismiss="modal"><b style="color: white">Abandonner</b></button>  &nbsp;&nbsp; <a href="./supprimer_un_compte.php?webox=<?php echo FERMERTURE;?>&id=<?php echo $_SESSION['id'];?>" onclick="return confirm(\'Voulez-vous vraiment supprimer ?\');" data-toggle="tooltip" data-placement="top" title="" data-original-title="Modifier "><button type="button"style="border-radius:20px" class="btn btn-danger btn-sm waves-effect waves-light">Fermer le compte</button></a>

            </center>
              
          </small>
          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>
  $(document).ready(function () {
    $("#FERMERTURE").modal();
  });
//made by csandreas1 for Stackoverflow
</script>














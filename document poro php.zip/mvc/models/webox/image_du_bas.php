 <div class="watermark">
<?php 
                ##############################################################################################################################################################

      if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='1'){
       
         /*echo' <a  href="javascript:{}"style="background:;border-radius:100%">    <!-- <i class="fas fa-fw fa-envelope"style="font-size:25px;color:'.COULEURT.'"></i> -->
<img src="./mvc/vues/img/logo/logoo.png" style=" height:60px;width:60px" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI">
         		</a>';

            echo'<a class="nav-link" href="./goodoo.php?webox='.LISTE_DES_DEMANDES_EN_ATTENTE.'">  <img src="./mvc/vues/img/logo/siaka.png"style=" height:25px;width:25px" alt="souci d\'affichage" title="DEMANDES EN ATTENTE"id="Siaka">';
            $categorie='Demande recu';$jour=date("d/m/Y"); 
             $paiement=0; 
             $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE statut='".$categorie."' AND paiement='".$paiement."' AND jour='".$jour."'");
                    while($donnees = $reponse ->fetch()){
                    echo'
                           <span class="badge badge-danger badge-counter"style="background:#C00;color:#fff;border-radius:60%">'.$donnees['idd'].'</span></a>&nbsp;&nbsp;&nbsp;
                           ';  
                    } $reponse->closeCursor();*/
         }


    elseif(isset($_SESSION['id']) AND $_SESSION['droitacces']=='2'){
   
      /* echo'<a  href="#page-top">  <img src="./mvc/vues/img/logo/cc.png"style=" height:25px;width:25px" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI"></a>';
      echo'<a class="nav-link" href="./goodoo.php?webox='. LISTE_DES_DEMANDES_RECU.'">  <img src="./mvc/vues/img/logo/siaka.png"style=" height:25px;width:25px" alt="souci d\'affichage" title="MON PANIER"id="Siaka">';
                           $categorie='Demande recu';
                            $paiement=0; 
                          $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE statut='".$categorie."' AND paiement='".$paiement."' AND codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                    echo'
                           <span class="badge badge-warning badge-counter"style="background:#C00;color:#fff;border-radius:60%"title="MON PANIER">'.$donnees['idd'].'</span></a>&nbsp;&nbsp;&nbsp;
                           ';  
                    } $reponse->closeCursor();
*/
       }



       else{
       /* echo' <a  href="javascript:{}">    <!--  <i class="fas fa-fw fa-comments"style="font-size:50px;color:#ff6600"></i>-->

            <img src="./mvc/vues/img/logo/logoo.png" style=" height:60px;width:60px" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI"></a>';*/
       
       }
 
        ?>

                
    </div>
<style type="text/css">
.watermark {
   opacity: 0.9;
    position: fixed;
    bottom: 0;
    right: 0;

}

</style>



 <script type="text/JavaScript">
var clignotement = function(){ 
if (document.getElementById('Siaka').style.visibility=='visible'){ 
document.getElementById('Siaka').style.visibility='hidden'; 
} 
else{ 
document.getElementById('Siaka').style.visibility='visible'; 
} 
}; 
periode = setInterval(clignotement, 1000);

</script>





<!--
 -->
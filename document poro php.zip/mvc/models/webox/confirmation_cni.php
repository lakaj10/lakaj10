<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo GAUCHE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-paste fa-1x "style="color:<?php echo GAUCHE;?>"></i>Actes de naissance</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Actes de naissance</li>
            </ol>
          </div>
  
<?php

  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   
               $reponse=$bdd->query("SELECT*FROM demandes_cni_tmp WHERE coded='".$identifiant_demande."' ORDER BY idcni  DESC LIMIT 0, 1");


              $nb_resultats = $reponse->rowCount(); 
              $res = $reponse->fetchAll();
              if (count($res) == 0) 
              {   
              echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
              //echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE.'"</SCRIPT>'; 

              }
              else
              {
              foreach ($res as $donnees) {

                $req = $bdd->prepare('SELECT 1 FROM demandes_cni WHERE coded="'.$identifiant_demande.'"');
                          $req->execute(array('coded'=>$donnees['coded']));
                          $nb_resultats_recherche=$req->fetch();

                              if(!$nb_resultats_recherche)
                              {
                             
                              //echo '<b><script type="text/javascript"> alert(\'Nouveau Mouvement ajouté dans la base de donnée\');</script></b>';

                              $req= $bdd->prepare('INSERT INTO demandes_cni(coded,codeu,type,categorie,paiement,datepaiement,statut,datestatut,jour,mois,annee,pu,nbrecopie,montant,fre,mode,commune,frc,quartier,frq,filiation,nomprenom,numcni,dn,ln,motifdemande,lieudemande,villelivrai,adressedom,solde)
                                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
                              $req->execute(array($donnees['coded'],$donnees['codeu'],$donnees['type'],$donnees['categorie'],$donnees['paiement'],$donnees['datepaiement'],$donnees['statut'],$donnees['datestatut'],$donnees['jour'],$donnees['mois'],$donnees['annee'],$donnees['pu'],$donnees['nbrecopie'],$donnees['montant'],$donnees['fre'],$donnees['mode'],$donnees['commune'],$donnees['frc'],$donnees['quartier'],$donnees['frq'],$donnees['filiation'],$donnees['nomprenom'],$donnees['numcni'],$donnees['dn'],$donnees['ln'],$donnees['motifdemande'],$donnees['lieudemande'],$donnees['villelivrai'],$donnees['adressedom'],$donnees['solde']));
                             
                                
                                $req2= $bdd->prepare('INSERT INTO demandes(coded,codeu,type,categorie,paiement,datepaiement,statut,datestatut,jour,mois,annee,pu,nbrecopie,solde)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
                                $req2->execute(array($donnees['coded'],$donnees['codeu'],$donnees['type'],$donnees['categorie'],$donnees['paiement'],$donnees['datepaiement'],$donnees['statut'],$donnees['datestatut'],$donnees['jour'],$donnees['mois'],$donnees['annee'],$donnees['pu'],$donnees['nbrecopie'],$donnees['solde']));
                             

                                if($req)
                                {
                               // $bdd->exec(" DELETE FROM demandes_cni_tmp WHERE idd = ".$donnees['idd']);
                               
                            echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DEMANDE6_CONFIRMEE.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>';
                              ;
                              //echo 'bien';
                                }

                              }
                              else 
                              {
                             echo '<b><script type="text/javascript"> alert(\'Mouvement existant \');</script></b>';

                              }                


              }
              }
              }
              
?>

<br> <br> 
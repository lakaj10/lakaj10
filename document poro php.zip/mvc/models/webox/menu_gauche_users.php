    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="./goodoo.php?webox=<?php echo DASHBOARD;?>"style="background:<?php echo GAUCHE;?>;box-shadow: 0 0.15rem 1.75rem 0 rgb(58 59 69 / 10%) !important;border-bottom: 0.0rem solid orange ;border-right:1px solid <?php echo BODY3;?>;    min-height: 50px;">
        <div class="sidebar-brand-icon"style="font-weight:bolder;font-family:mistral;background-color:;border-radius: 100%">
         <!-- <img src="./mvc/vues/img/logo/cc.png" style=" height:23px;width:25px">  -->
               <i class="fas fa-shopping-cart text-warning"></i>      
        </div>
        <div class="sidebar-brand-text mx-1">
         <img src="./mvc/vues/img/logo/cccc.png" style=" height:23px;width:180px">   </div>
      </a>
     
     
      <hr class="sidebar-divider my-0">
       <li class="nav-item"style="background:<?php echo BODY;?>">
        <a class="nav-link collapsed" href="#" data-toggle="modal" data-target="#COMPTE" id="#modalCenter"title="COMPTE <?php echo strtoupper($_SESSION['compte']);?>">
       
                <?php 

                ##############################################################################################################################################################
                /*
                  if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='2'){
                    $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                    $donnees=$req->fetch(); 
                    if($req){
                        if(empty($donnees['photo'])) {
                    echo'<img class="img-profile" src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;max-width: 60px;height:20px;width:20px">';
                }
                else
                {
                       echo'<img class="img-profile" src="./mvc/vues/img/photo/users/'.$donnees['photo'].'" style="border-radius:100%;max-width: 60px;height:20px;width:20px">';
                }
                 
                        }
                     }
        
          */
                  ##############################################################################################################################################################

                   ?>
                    <i class="fas fa-fw fa-lock fa-3x text-info"></i>
          <span>

            <?php 
                  if(isset($_SESSION['id'])){
                    $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                    $donnees=$req->fetch(); 
                    if($req){
                      echo '<b>'.strtoupper(substr($_SESSION['compte'],0,20)).'</b> : ';

                                    $annee1=substr($donnees['dn'],6,20);
                                    $annee2=date("Y");
                                    $age=$annee2-$annee1;

                                    echo '<span><b style="color:red;font-family:arial black"> '.$age.' ANS</b></span> ';
                                 
                  }
                  }
                  
                   ?></span></a>
      </li>
        
      
      <?php 

      ##############################################################################################################################################################

        if(isset($_SESSION['id']) AND $_SESSION['droitacces']==2){
        $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
        $donnees=$req->fetch(); 
        if($req){
       
        
      echo'

     
        <hr class="sidebar-divider">
      <div class="sidebar-heading">
        CALENDRIER DU JOUR
      </div>

      <li class="nav-item active">
        <a class="nav-link" href="javascript:{}"title="La date du jour "style="background:'.BODY.'">
          <i class="fas fa-fw fa-calendar-check fa-3x text-danger"></i>
          <span class="badge badge-danger progress-bar progress-bar-striped progress-bar-animated bg-danger">';
                $date=getdate();
                $joura=date('d');
                $moisa=date('m');
                $anneea=date('Y');
                $jour=$joura.'/'.$moisa.'/'.$anneea;
              echo $jour;
        echo'</span></a>
      </li>
  
    
        <hr class="sidebar-divider">
      <div class="sidebar-heading">
        MENU DE LA PLATEFORME
      </div>
      <li class="nav-item active">
        <a class="nav-link" href="./goodoo.php?webox='.DASHBOARD.'"title="Mon tableau de bord"style="background:'.BODY3.'">
          <i class="fas fa-fw fa-tachometer-alt fa-3x text-info"></i>
          <span>Tableau de Bord</span></a>
      </li>
    
        <li class="nav-item active">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap"
            aria-expanded="true" aria-controls="collapseBootstrap">
            <i class="fas fa-gavel fa-3x text-info"></i>
            <span>Etats civils</b></span>
          </a>
          <div id="collapseBootstrap" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="./goodoo.php?webox='.NAISSANCE.'"title="Actes de Naissance">Actes de Naissance</a>
              <a class="collapse-item" href="./goodoo.php?webox='.MARIAGE.'"title="Actes de Mariage">Actes de Mariage</a>
              <a class="collapse-item" href="./goodoo.php?webox='.DECES.'"title="Actes de Décès">Actes de Décès</a>
              <a class="collapse-item" href="javascript:{}"title="Certification de Document">Certification de Document</a>

              
            </div>
          </div>
        </li>



            <li class="nav-item active"style="background:"href="#search">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap2"
          aria-expanded="true" aria-controls="collapseBootstrap"style="background:'.BODY.'">
          <i class="fas fa-graduation-cap fa-3x text-info"></i>
          <span>Actes de Justice</b></span>
        </a>
        <div id="collapseBootstrap2" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
                    <a class="collapse-item" href="./goodoo.php?webox='.CASIER.'"title="Casier Judiciaire">Casier Judiciaire</a>
            <a class="collapse-item" href="./goodoo.php?webox='.CERTIFICAT.'" title="Certificats de Nationalité Ivoirienne">Certificat de Nationalité</a>
    
          </div>
        </div>
      </li>


        <hr class="sidebar-divider">
      <div class="sidebar-heading">
        TOUTES MES DEMANDES
      </div>

      <li class="nav-item active">
        <a class="nav-link collapsed" href="./goodoo.php?webox='.LISTE_DES_DEMANDES.'" style="background:'.BODY.'">
          <i class="fas fa-fw fa-edit fa-3x text-warning"></i> 
          <span class="badge badge-warning progress-bar progress-bar-striped progress-bar-animated bg-warning">';

                    $reponse=$bdd->query("SELECT COUNT(*) AS idd FROM demandes WHERE codeu='".$_SESSION['code']."'");
                    while($donnees = $reponse ->fetch()){
                     echo'000'.$donnees['idd'].' ';
                    } $reponse->closeCursor();
             
        echo' </span></a>
      </li>


  <hr class="sidebar-divider">
      <div class="sidebar-heading">
        MESSAGERIES
      </div>
   <!-- Datatables
          <li class="nav-item active">
        <a class="nav-link" href="./goodoo.php?webox='.ADMIN.'"title="Ecrire au service client"style="background:'.BODY.'">
          <i class="fas fa-fw fa-headphones fa-3x text-info"></i>
          <span>Discussion instantannée</span></a>
      </li> -->

      
         <li class="nav-item active">
        <a class="nav-link" href="./goodoo.php?webox='.SIGNALER_PROBLEME.'"title="Envoyer un message"style="background:'.BODY.'">
          <i class="fas fa-fw fa-envelope fa-3x text-info"></i>
          <span>Envoyer un message</span></a>
      </li>




      <hr class="sidebar-divider">
       <div class="sidebar-heading">
        PARAMETRES DU COMPTE
      </div>


      

            <li class="nav-item active"style="background:"href="#search">
        <a class="nav-link collapsed" href="#" data-toggle="modal" data-target="#DECONNEXION" id="#modalCenter"style="background:'.BODY.'">
          <i class="fas fa-fw fa-power-off fa-3x text-info"></i>
          <span> Deconnexion</b></span>
        </a>
        
      </li> 
       <hr class="sidebar-divider">
    <div class="version">Version  <b style="color:orange;font-family:arial black">1.0.3</b></div>
    </ul>

      ';
      }
        }
       
        ##############################################################################################################################################################          
       ?>      
      
      
     
       






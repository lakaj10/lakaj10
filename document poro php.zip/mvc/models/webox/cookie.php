 <div class="modal fade" id="cookie" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <!--<div class="modal-header"style="background-color:orange;color:white">
           <h5 class="modal-title" id="exampleModalCenterTitle">
              utilisation des cookies
            </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>  -->
          
          <div class="modal-body">
            <small> Nous utilisons des cookies pour vous garantir la meilleure expérience sur notre application . Si vous continuez à utiliser cette dernière, nous considérerons que vous acceptez l'utilisation des cookies. &nbsp;&nbsp;<a href="./woodoo.php?webox=<?php echo COOKIES;?>"style="text-decoration:none; color:red;font-weight:bolder;font-family:verdana"> j'accèpte l'utilisation </a>
              
          </small>
          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>
  $(document).ready(function () {
    $("#cookie").modal();
  });
//made by csandreas1 for Stackoverflow
</script>
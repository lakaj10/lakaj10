
<style type="text/css">
 .sticky-footer{
position: absolute;right: 0;bottom: 0;left: 0;text-align: center;max-width:100%;padding: 10px 30px;
}
 {
margin: 0px;padding: 0px;
}
div {
display: block;
}
</style>


   <footer class="sticky-footer"style="padding: .9rem 1rem;background-color:<?php echo FOOTER;?>;border-top: 0.0rem solid orange ;box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.15)!important;">
        <div class="container my-auto">
          <div class="copyright text-center my-auto"style="color:#fff;font-size:16px">
            <span >copyright &copy;
            <script> document.write(new Date().getFullYear()); </script> - developpé & propulsé par
            <b><a href="#"  style="color:#ccc;font-family:Mistral;font-size:18px">NIVO<a href="#"  style="color:white;font-family:Mistral;font-size:18px">DEX</a> </a></b>
          </span>
          </div>
        </div> 
    </footer>
     



<?php
// Database Structure 
define('MYBDD', 'mysql:dbname=sgeppmea;host=localhost');
  // Adresse du serveur de base de données
define('BDDUSER', 'root');
  // Adresse du serveur de base de données#0F056B#3b5998#791CF8#6610f2
define('BDDPWD', '');
 try
{
$bdd = new PDO(MYBDD, BDDUSER, BDDPWD, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
}
 catch(Exception $e){echo 'Un souci avec la base de donnée<br>'; die('Erreur : '.$e->getMessage());
}

$searchTerm = $_GET['term'];

$reponse=$bdd->query("SELECT * FROM users WHERE nomprenoms LIKE '%".$searchTerm."%'" );
$res = $reponse->fetchAll();

foreach ($res as $donnees) 
{
 $data[] = $donnees['nomprenoms'];
}
//return json data
echo json_encode($data);
?>
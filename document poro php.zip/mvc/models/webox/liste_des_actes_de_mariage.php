
<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;">  <i class="fas fa-fw fa-venus-double fa-1x "style="color:<?php echo TITRE;?>"></i> Actes de mariage</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Actes de mariage</li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->



          <!-- Row -->
         



              <?php



                //echo $code_client;
                //$reponse=$bdd->query("SELECT*FROM demandes  ORDER BY type  DESC limit 0,10000 ");
                
                 
                
              
                      $droitacces=2;
                  $categorie='Actes de Mariage';
                
              $reponse=$bdd->query(" 
                    SELECT
                  users.code,
                  users.nomprenoms,
                  users.mobile,
                  users.photo,
                  users.droitacces,
                  users.email,


                  demandes.idd,
                  demandes.coded,
                  demandes.codeu,
                  demandes.type,
                  demandes.categorie,
                  demandes.paiement,
                  demandes.datepaiement,
                  demandes.statut,
                  demandes.datestatut,
                  demandes.jour,
                  demandes.mois,
                  demandes.annee,
                  demandes.pu,
                  demandes.nbrecopie,
                  demandes.solde
                 
                  FROM users, demandes WHERE users.code=demandes.codeu AND users.droitacces='".$droitacces."' AND demandes.categorie='".$categorie."'  ORDER BY users.nomprenoms  DESC LIMIT 0, 10000000");
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                  if (count($res) == 0) 
                {

                 /* echo '<script type="text/javascript"> alert(\'     DESOLE  . AUCUNS RESULTAT TROUVES      \');</script>';

                   echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>'; */

                    echo' 

                          <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">LISTE DES ACTES DE MARIAGE :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                      ';
                
                            include('./mvc/models/webox/oops.php');

                }
                else {
                echo'
                 <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                <div class="table-responsive condensed">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">LISTE DES ACTES DE MARIAGE :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                </div>
                      <table class="table  table-sm mb-0 table-hover table-condensed">

                    <thead style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
                      <tr>
                          <th>Photo</th>
                      
                        <th>Reference </th>
                        <th>Nom </th>
                        <th><centere>Email</center> </th>

                        <th>Mobile </th>
                        <th>Reglé</th>
                        <th>Statut</th>
                        <th>Qté   </th>
                        <th>Pu  </th>
                        <th>Montant</th>
                        <th></th>

                      </tr>
                    </thead>

               

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody id="myInput">
                     
                      
                      <tr>
                          <td>';
                       
                        if(empty($donnees['photo'])) {
                        echo'<img  src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;height:20px;width:20px">';
                        }
                        else
                        {
                        echo'<img  src="./mvc/vues/img/photo/users/'.$donnees['photo'].'" style="border-radius:100%;height:20px;width:20px">';
                        }

                        
                     echo'</td>

                      
                            <td><span class="badge badge-primary progress-bar progress-bar-striped progress-bar-animated bg-primary">'.$donnees['coded'].'</span></td>
                        <td title='.$donnees['nomprenoms'].'><centere>'.substr($donnees['nomprenoms'],0,10).' </center></td>
                        <td title='.$donnees['email'].'>'.substr($donnees['email'],0,10).'</td>
                          <!----><td title='.$donnees['mobile'].'>'.substr($donnees['mobile'],0,10).'</td>
                               
                        
                        <td ><center>';
                        if($donnees['paiement']=='1')
                        {
                          echo'<b style="color:blue"><span class="badge badge-warning progress-bar progress-bar-striped progress-bar-animated bg-warning">Oui </span></b>';
                        }
                        else
                        {
                          echo'<b style="color:blue"><span class="badge badge-info progress-bar progress-bar-striped progress-bar-animated bg-info">Non</span></b>';
                        }
                      
                        echo'</td>


                           
                          <td>';
                        if($donnees['statut']=='Demande recu')
                        {
                          echo'<b style="color:blue"><span class="badge badge-danger progress-bar progress-bar-striped progress-bar-animated bg-danger">Demande reçu </span></b>';
                        }
                        elseif($donnees['statut']=='Activée')
                        {
                           echo'<b style="color:orange"><span class="badge badge-warning progress-bar progress-bar-striped progress-bar-animated bg-warning">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                        elseif($donnees['statut']=='En cours de traitement')
                        {
                           echo'<b style="color:orange"><span class="badge badge-primary progress-bar progress-bar-striped progress-bar-animated bg-primary">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                        elseif($donnees['statut']=='Traitée')
                        {
                           echo'<b style="color:orange"><span class="badge badge-info progress-bar progress-bar-striped progress-bar-animated bg-info">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                         else
                        {
                           echo'<b style="color:orange"><span class="badge badge-success progress-bar progress-bar-striped progress-bar-animated bg-success">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                      
                      
                      
                         
                      echo'</td>
                          <td >'.$donnees['nbrecopie'].'</td>
                         <td > '.$donnees['pu'].'</td>
                         <td >'.$donnees['solde'].'</td>
                        
                         <td><small><a href="./goodoo.php?webox='.EDITER_ADM.'&identifiant_demande='.$donnees['coded'].'" data-toggle="tooltip" data-placement="top" title="EDITER LES INFORMATIONS DE CETTE DEMANDE" data-original-title="Afiicher les informations su compte"target="_bank><font color="white"><i class="fa fa-eye"style="color:#4c60da;"></i></b></a></font></small></center></td>

                           
                         </tr>
              
            </tbody>';
                     }

                echo'</table>';
          }
          
          ?>
  </div>   </div>  </div>  </div>   <br> 









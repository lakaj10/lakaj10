
<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
            <h1 class="h3 mb-0 text-gray-800"style="color:#15ca20;font-weight:bolder;">  <i class="fas fa-fw fa-check-circle fa-1x "style="color:<?php echo BOUTON;?>"></i> Activer une Demande</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Activer une Demande</li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->



          <!-- Row -->
          <div class="row">
            <!-- Datatables -->
            <div class="col-lg-12">
              <div class="card mb-4">

                
                 <?php

                //echo $code_client;
                //$reponse=$bdd->query("SELECT*FROM demandes  ORDER BY type  DESC limit 0,10000 ");

                $reponse=$bdd->query(" 
                SELECT

                users.code,
                users.nomprenoms,

                demandes.idd,
                demandes.nbrecopie,
                demandes.coded,
                demandes.montant,
                demandes.categorie,
                demandes.paiement,
                demandes.statut,
                demandes.jour,
                demandes.pu

                

                FROM users, demandes WHERE 
                users.code=demandes.codeu   ORDER BY demandes.idd  DESC LIMIT 0, 1000");
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                if (count($res) == 0) 
                {
                    echo'  <br><div class="alert alert-danger"style="color:red ;background-color:'.COULEURT.'">
                            <center><b style="color:red ">  <a style="color:red ">DESOLE !</a>. AUCUN RESULTAT TROUVE DANS LA BASE DE DONNEE .</b></center>
                            </div>
                ';

                }
                else {
                echo'


                <div class="table-responsive p-3">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">LISTE DES DEMANDES</h6>
                </div>
                  <table class="table table-hover table-condensed">

                    <thead style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
                      <tr>
                        <th>ID</th>
                         <th>CodeU </th>
                         <th><center>Référence</center> </th>
                        <th>Utilisateur </th>
                         <th>Demande </th>
                        <th>Effectuée le  </th>
                        <th>Réglé</th>
                       
                        <th><centere>PU </center></th>
                         <th><centere>Qté</center></th>
                          <th><centere>Solde</center></th>
                      </tr>
                    </thead>

                    <!-- <tfoot style="background-color:'.TABLEAU.';color:'.COULEURT.'">
                      <tr>
                        <th>ID</th>
                         <th>Référence </th>
                        <th>Catégorie </th>
                        <th>Type de Demande</th>
                       
                        <th><center>Prix Unitaire </center></th>
                      </tr>
                    </tfoot>-->

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody id="myInput">
                     
                      
                      <tr>
                      <td>'.$donnees['idd'].'</td>
                        <td>'.$donnees['code'].'</td>
                        <td style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;"><center>'.$donnees['coded'].' </center></td>
                        <td>'.$donnees['nomprenoms'].'</td>
                         <td>'.$donnees['categorie'].'</td>
                         <td>'.$donnees['jour'].'</td>
                        <td>'.$donnees['paiement'].'</td>
                         <td>'.$donnees['pu'].'</td>
                        <td>'.$donnees['nbrecopie'].'</td>
                        <td>'.$donnees['montant'].'</td>
                      </tr>
                     
              
            </tbody>';
                     }

                echo'</table>';
          }
          ?>
        </div>   </div>  </div>  </div>   <br> 
             


































            
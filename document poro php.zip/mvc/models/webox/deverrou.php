 <?php 



$id=htmlspecialchars($_GET["id"]) ;
if(empty($id))
{
	echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>';

}
elseif(isset($id))
{
	$id=htmlspecialchars($_GET["id"]) ;
	$deverrou=0 ;
	$bdd->exec("UPDATE users SET verrou='".$deverrou."' WHERE id='".$_GET['id']."'");
	//echo '<script type="text/javascript"> alert(\'             Opération éffectuée avec succès            \');</script>';

if($bdd)
{
	echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.LISTE_DES_UTILISATEURS.'"</SCRIPT>';
}
}
else
{
	echo("echoué") ;
}

?>



<div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-home fa-1x text-warning"></i>Acceuil</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Bienvenue sur la plateforme</li>
            </ol>
          </div>

    <div class="alert alert-danger"style="font-size:14px; background-color:#C00;border-color:#C00;color:white;border-radius:10px;visibility: visible; animation-name:fadeInRightBig">
    <center><i class="fa fa-bullhorn"id="DivClignotantesiaka"></i> Salut !!!  <b> utilisateur .</b> Veillez avant de continuer prévoir une image de la copie de l'original de l'acte de naissance que vous allez uploader apres le remplissage du formualaire</center>
    </div>


<div class="card-body"style="border-radius:100px; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.20)!important;background-color:white">
   
<a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-success">
                      <i class="fas fa-donate text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 7, 2019</div>
                    $290.29 has been deposited into your account!
                  </div>
                </a>
</div>
<br>


<div class="card-body"style="border-radius:100px; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.20)!important;background-color:white">
  <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-success">
                      <i class="fas fa-donate text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 7, 2019</div>
                    $290.29 has been deposited into your account!
                  </div>
                </a>

</div>
<br>



<div class="card-body"style="border-radius:100px; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.20)!important;background-color:white">
   
<a class="dropdown-item d-flex align-items-center">
                  <div class="mr-3">
                    <div class="icon-circle bg-success">
                      <i class="fas fa-donate text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 7, 2019</div>
                    $290.29 has been deposited into your account!
                  </div>
                </a>
</div>




<br>



<div class="card-body"style="border-radius:100px; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.20)!important;background-color:white">
   
<a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-success">
                      <i class="fas fa-donate text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 7, 2019</div>
                    $290.29 has been deposited into your account!
                  </div>
                </a>
</div>
<hr>
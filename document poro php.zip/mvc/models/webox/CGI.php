 <div class="modal fade" id="CGI" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true">
     <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
              <div class="modal-header"style="color:<?php echo GAUCHE;?>;  background:<?php echo CONTENU;?>;border-bottom: 0.0rem solid <?php echo COULEUR;?> ;border-right:0px solid #eee">
          <!--  --><h5 class="modal-title" id="exampleModalCenterTitle">
            
            </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          
          <div class="modal-body">
        

            <p>Les données communiquées via ce formulaire sont collectées avec votre consentement et sont destinées à DOCUMENT-PORO. en sa qualité de responsable du traitement. Elles pourront être transmises à ses sous-traitants agissant sur strictes instructions d’DOCUMENT-PORO. ainsi qu’aux entités du Groupe DOCUMENT-PORO. Dans cette seconde hypothèse, et sous réserve que l’entité du Groupe DOCUMENT-PORO ait signé des règles d’entreprise contraignantes, les données pourront faire l’objet d’un transfert en dehors de l’Union Africaine.</p> Les données de ce formulaire sont collectées à des fins de gestion de la relation client, de sollicitations commerciales et de respect de la règlementation applicable à DOCUMENT-PORO. Les données de votre compte client sont conservées jusqu’à la suppression de votre compte client, . Certaines données traitées  peuvent être conservées plus longtemps conformément à la règlementation applicable.<p> Vous disposez de la faculté d’introduire une réclamation auprès de l’autorité de contrôle compétente ainsi qu’un droit d'accès, de rectification, d’effacement, de limitation, de portabilité et d’opposition pour motif légitime aux données personnelles vous concernant. Pour exercer ce droit, merci d’effectuer votre demande au sein de notre formulaire dédié.</p>
          </div>
         
        </div>
      </div>
    </div>
    
    </div>

    <script>
  $(document).ready(function () {
    $("#CGI").modal();
  });
//made by csandreas1 for Stackoverflow
</script>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-paste fa-1x "style="color:<?php echo TITRE;?>"></i>Actes de naissance</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Actes de naissance</li>
            </ol>
          </div>

    
<?php


$errors = [];
mb_internal_encoding('UTF-8');

  
if ('POST' == $_SERVER['REQUEST_METHOD']) {

if (isset($_POST['ajouter_demande_actes_de_naissance'])) {

        $coded=$_POST['coded'];
     $reponse = $bdd->query('SELECT * FROM demandes_adn_tmp WHERE coded="'.$_POST['coded'].'" ORDER BY idn DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {
                  $bdd->exec("UPDATE demandes_adn_tmp SET 
                  fre='".$_POST['fre']."',
                  mode='".$_POST['mode']."'
                  WHERE  coded='".$coded."'");

  //sleep(2);

              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE_IDENTIQUE_TROIS.'&identifiant_demande='.$_POST['coded'].'"</SCRIPT>'; 

                  
                
      }
   }
}

if($errors) {
echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div>';

}

?> 




    
<?php


$errors = [];
mb_internal_encoding('UTF-8');

  
if ('POST' == $_SERVER['REQUEST_METHOD']) {

if (isset($_POST['ajouter_demande_actes_de_naissance3'])) {

        $coded=$_POST['coded'];
     $reponse = $bdd->query('SELECT * FROM demandes_adn_tmp WHERE coded="'.$_POST['coded'].'" ORDER BY idn DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {
                  $bdd->exec("UPDATE demandes_adn_tmp SET 
                  fre='".$_POST['fre']."',
                  mode='".$_POST['mode']."'
                  WHERE  coded='".$coded."'");

  //sleep(2);

              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE_PHOTO.'&identifiant_demande='.$_POST['coded'].'"</SCRIPT>'; 

                  
                
      }
   }
}

if($errors) {
echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div>';

}

?>

 <?php 
 
  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   

   $reponse=$bdd->query("SELECT*FROM demandes_adn_tmp WHERE coded='".$identifiant_demande."' ORDER BY idn  DESC LIMIT 0, 1");

$nb_resultats = $reponse->rowCount(); 
$res = $reponse->fetchAll();
if (count($res) == 0) 
{   
     echo '<b><script type="text/javascript"> alert(\' Un souci est survenu lors de votre enregistrement . veillez reprendre\');</script></b>';
             // echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE.'"</SCRIPT>'; 
echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE.'"</SCRIPT>';

    }
    else
    {
      foreach ($res as $donnees) {

echo'

  <div class="row">
            <div class="col-lg-12">
              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;background-color:white">
               
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;border-radius:.375rem">
         <h6 class="m-0 font-weight-bold text-primary">FORMULAIRE DE DEMANDE</h6>
                 
                  </div>

                <div class="card-body">




    <form method="POST" action=""  autocomplete="off" enctype="multipart/form-data">
      
       



                  <input  value="'.ucfirst($donnees['coded']).'" type="hidden"class="form-control form-control-sm "style=" font-family:verdana ;color:'.COULEUR.';background-color:'.COULEURT.'" name="coded">';

                  
                   if(isset($donnees['villelivrai']) AND $donnees['villelivrai']=="Abidjan" || $donnees['villelivrai']=="Bouake" || $donnees['villelivrai']=="Yamoussoukro" || $donnees['villelivrai']=="Korhogo")
                  {
                    echo' 

                   <div class="form-group">
                      <label for="2"> Filiation du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['filiation'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Nom & prénoms du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['nomprenom'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Date du registre </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['datereg'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Numéro de l\'extrait </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['numextrait'].'">
                    </div>


                    <div class="form-group">
                      <label for="2"> Motif de la demande </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['motifdemande'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Lieu de la demande </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['lieudemande'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Ville d\'expédition </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['villelivrai'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Nombre de copies </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['nbrecopie'].'">
                    </div>


                     <div class="form-group">
                      <label for="13"> Choisissez le mode de livraison </label>
                      <select class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercasee;color:'.BOUTON.'" name="mode"id="31"autofocus value=""required=""autofocus>
                       <option value="Livraison à Domicile">  A Domicile </option>
                        <option value="Livraison par Courrier">Par Courrier </option>
                        
                        
                      </select>
                    </div>

                 

                   
                    <button type="submit"name="ajouter_demande_actes_de_naissance"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar"> ENREGISTRER</button>
                  </div>
                </div>
              </div>
</div>
                    ';
                  }
                  else
                  {
                    echo' 
                    <div class="form-group">
                      <label for="2"> Filiation du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['filiation'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Nom & prénoms du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['nomprenom'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Date du registre </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['datereg'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Numéro de l\'extrait </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['numextrait'].'">
                    </div>


                    <div class="form-group">
                      <label for="2"> Motif de la demande </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['motifdemande'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Lieu de la demande </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['lieudemande'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Ville d\'expédition </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['villelivrai'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Nombre de copies </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['nbrecopie'].'">
                    </div>
                     <div class="form-group">
                      <label for="13"> Mode de livraison à <b>'.strtoupper($donnees['villelivrai']).'</b>  </label>

                      <select class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercasee;color:'.BOUTON.'" name="mode"id="31"autofocus value=""required="">
                        <option value="Livraison par Courrier">Par Courrier </option>
                       
                        
                        
                      </select>
                    </div>
                     <input  value="2000" type="hidden"class="form-control form-control-sm "style=" font-family:verdana ;color:'.COULEUR.';background-color:'.COULEURT.'" name="fre">


                   
                    <button type="submit"name="ajouter_demande_actes_de_naissance3"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar"> ENREGISTRER</button>
                  </div>
                </div>
              </div>
</div>




                    ';
                  }


                 $reponse2=$bdd->query("SELECT*FROM frais WHERE ville='".$donnees['villelivrai']."'");

              $nb_resultats = $reponse2->rowCount(); 
              $res2 = $reponse2->fetchAll();
              if (count($res2) == 0) 
              {   
                   echo '<b><script type="text/javascript"> alert(\' Un souci est survenu lors de votre enregistrement . veillez reprendre\');</script></b>';
             // echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE.'"</SCRIPT>'; 
echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE.'"</SCRIPT>';
                  }
                  else
                  {
                    foreach ($res2 as $donnees2) {
                 
                 echo '<input  type="hidden"autofocus="" name="fre"style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" class="form-control form-control-sm  " id="8" placeholder="  " required="" value="'.$donnees2['montant'].'"required="">
                   ';


              }
              }


}
}
}



   


 echo'
           </form>  


                                ';
 
?>

             
















































































































































                 


                     
             
   
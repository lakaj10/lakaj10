<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
             <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-ambulance fa-1x "style="color:<?php echo TITRE;?>"></i>  Actes de décès </h1>

          
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Actes de décès </li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->




          <!-- Row -->
         


                 <?php
                 $droitacces=2;
                  $categorie='Actes de Décès';
                 $reponse=$bdd->query('SELECT * FROM demandes WHERE categorie="'.$categorie.'"AND codeu="'.$_SESSION['code'].'" ORDER BY idd ASC limit 0,10000000  ');
               
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                  if (count($res) == 0) 
                {
                    echo'  
                           <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">MES ACTES DE DECES :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                            ';
                
                            include('./mvc/models/webox/oops.php');

                }
                else {
                echo'
                 <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                <div class="table-responsive condensed">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">MES ACTES DE DECES :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                </div>
                 <table class="table  table-sm mb-0 table-hover table-condensed">

                    <thead style="    color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
                      <tr>
                      
                      
                        <th>Référence</th>
                        <th>Catégorie </th>
                        <th><centere>Demande</center> </th>
                         <th>Date   </th>
                        <th>Reglé </th>
                       
                        <th>Statut</th>
                         <!----><th>Changé le</th>
                        <th><centere>Pu </center></th>
                        <th><centere>Copie</center></th>
                         <th><centere>Montant</center></th>
                               <th><centere></center></th>
                        

                      </tr>
                    </thead>

                   

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody id="myInput">
                     
                      
                      <tr>
                        
                        <td>'.$donnees['coded'].'</td>

                        <td title='.$donnees['type'].'><centere>'.substr($donnees['type'],0,20).' </center></td>

                        <td title='.$donnees['categorie'].'>'.strtoupper(substr($donnees['categorie'],0,10)).'</td>

                        <td >'.substr($donnees['jour'],0,10).'</td>

                          <!----><td>';
                        if($donnees['paiement']=='1')
                        {
                          echo'<b style="color:orange">Oui</b>';
                        }
                        else
                        {
                        echo'<b style="color:blue">Non</b>';
                        }
                      
                      
                      echo'</td>

                           <td >';
                        if($donnees['statut']=='Demande recu')
                        {
                          echo'<b style="color:blue"><span class="badge badge-danger progress-bar progress-bar-striped progress-bar-animated bg-danger">Demande reçu </span></b>';
                        }
                        elseif($donnees['statut']=='Activée')
                        {
                           echo'<b style="color:orange"><span class="badge badge-warning progress-bar progress-bar-striped progress-bar-animated bg-warning">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                        elseif($donnees['statut']=='En cours de traitement')
                        {
                           echo'<b style="color:orange"><span class="badge badge-primary progress-bar progress-bar-striped progress-bar-animated bg-primary">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                        elseif($donnees['statut']=='Traitée')
                        {
                           echo'<b style="color:orange"><span class="badge badge-info progress-bar progress-bar-striped progress-bar-animated bg-info">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                         else
                        {
                           echo'<b style="color:orange"><span class="badge badge-success progress-bar progress-bar-striped progress-bar-animated bg-success">'.substr($donnees['statut'],0,25).' </span></b>';
                        }
                      
                      
                        echo'</td>

                        <!----><td>'.substr($donnees['datestatut'],0,10).'</td>
                          <!----><td >'.$donnees['pu'].'</td>

                           <td><center>'.substr($donnees['nbrecopie'],0,10).'</center></td>
                        
                          <!----><td ><center>'.$donnees['solde'].'</center></td>

                          <td><small><a href="./goodoo.php?webox='.EDITER_ADDE.'&identifiant_demande='.$donnees['coded'].'" data-toggle="tooltip" data-placement="top" title="EDITER LES INFORMATIONS DE CETTE DEMANDE" data-original-title="Afiicher les informations su compte"target="_bank><font color="white"><i class="fa fa-eye"style="color:#4c60da;"></i></b></a></font></small></center></td>


                           
                      
                        

                      </tr>
                     
              
            </tbody>';
                     }

                echo'</table>';
          }
          
          ?>
  </div>   </div>  </div>  </div>   <br> 



            
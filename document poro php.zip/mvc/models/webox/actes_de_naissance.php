
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-paste fa-1x "style="color:<?php echo TITRE;?>"></i>Actes de naissance</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Actes de naissance</li>
            </ol>
          </div>


             <!--  <div class="alert alert-danger alert-dismissible fade show text-center progress-bar progress-bar-striped progress-bar-animated bg-danger" role="alert"style="font-size:14px;">
     <b>PJ : Extrait de naissance original de moins de 6 mois </b> 
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">×</span>
    </button>
  </div> -->
<?php


$errors = [];
mb_internal_encoding('UTF-8');


if ('POST' == $_SERVER['REQUEST_METHOD']) {

if (isset($_POST['ajouter_demande_actes_de_naissance'])) {
    $stmt = $bdd->prepare('SELECT 1 FROM demandes_adn_tmp WHERE coded = :coded');
    $stmt->execute(['coded' => $_POST['coded']]);
    if (FALSE !== $stmt->fetchColumn()) {
    $errors['coded'] = "ce code est dejà utilisé";
    }

  } 


  if(!$errors) {
  
  $datereg=$_POST['datereg'];
  $timestamp=strtotime($datereg);
  $datereg=date("d/m/Y", $timestamp);

  $statut='Demande recu';
  $datestatut=date("d/m/Y");
$paiement=0;
  $req= $bdd->prepare('INSERT INTO demandes_adn_tmp(coded,codeu,type,categorie,statut,datestatut,jour,mois,annee,pu,filiation,nomprenom,numextrait,datereg,paiement)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
  $req->execute(array($_POST['coded'],$_POST['codeu'],$_POST['type'],$_POST['categorie'],$statut,$datestatut,$_POST['jour'],$_POST['mois'],$_POST['annee'],$_POST['pu'],$_POST['filiation'],$_POST['nomprenom'],$_POST['numextrait'],$datereg,$paiement));

    if ($req) {
     //$reponse = $bdd->query('SELECT * FROM demandes_adn_tmp WHERE coded="'.$_POST['coded'].'" ORDER BY idd DESC LIMIT 0, 1');
      $reponse = $bdd->query('SELECT * FROM demandes_adn_tmp WHERE coded="'.$_POST['coded'].'" ORDER BY idn DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {
 echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE_IDENTIQUE.'&identifiant_demande='.$_POST['coded'].'"</SCRIPT>'; 
                  
                }
      }
   }
}

if($errors) {
echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div>';

}

?> 



<form method="POST" action=""  autocomplete="on" enctype="multipart/form-data">


  <?php

if(isset($_SESSION['code']))
{ 
$req=$bdd->query('SELECT*FROM tarif WHERE nom="Actes de Naissance"'); 
$donnees=$req->fetch(); 
if($req){

echo' 
 <input hidden name="pu" class="form-control form-control-sm  " type="text" value="'.$donnees['montant'].'">
  <input hidden name="type" class="form-control form-control-sm  " type="text" value="'.$donnees['type'].'">
 <input hidden name="categorie" class="form-control form-control-sm  " type="text" value="'.$donnees['nom'].'">

    ';
}
}  
srand((double)microtime()*10000);
$num=rand();
$coded1='ADN-'.$num;
$coded2=substr($coded1,0,8);
$coded=$coded2;
//echo $coded;
echo'  <input type="hidden" name="coded" value="'.$coded.'"/>';   


$date=getdate();
$joura=date('d');
$moisa=date('m');
$anneea=date('Y');
$jour=$joura.'/'.$moisa.'/'.$anneea;
echo'<input type="hidden"name="jour"class="form-control form-control-sm  " value="'.$jour.'">';       
echo'<input type="hidden"name="mois"class="form-control form-control-sm  " value="'.$moisa.'">';
echo'<input type="hidden"name="annee"class="form-control form-control-sm  " value="'.$anneea.'">';       
?>

  <div class="row">
            <div class="col-lg-12">
              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.06)!important;background-color:white">
               
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.06)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-primary">FORMULAIRE DE DEMANDE</h6>
                                            
                </div> 

                 <input  value="<?php if(isset($_SESSION['code']) AND $_SESSION['droitacces']=='2'){ echo $_SESSION['code'];}?>" type="hidden"name="codeu" class="form-control form-control-sm   "style="background:<?php echo COULEURT ?> ;color:<?php echo TITRE ?>; font-family:arial;"  placeholder="users-" required>




                <div class="card-body">
                         <!-- <div class="form-group">
                               <label for="1"> Titulaire du compte</label>
                      <input disabled=""data-toggle="popover" title="TITULAIRE DU COMPTE"
                    data-content="Right?" value="<?php // if(isset($_SESSION['nomprenom']) AND $_SESSION['droitacces']=='2'){ echo $_SESSION['nomprenom'];}?>" type="text"class="form-control form-control-sm   "style="background:<?php  //echo COULEURT ?> ;color:<?php  //echo TITRE ?>; font-family:arial;"  placeholder="users-" required>
                      </div -->


                    <div class="form-group"<?php if (array_key_exists('filiation', $errors)) echo 'has-error';?>>
                      <label for="1"> Filiation du demandeur</label>

                      <select class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:<?php echo BOUTON ?>" name="filiation"id="1"autofocus value="<?php if (array_key_exists('filiation', $_POST)) echo htmlspecialchars($_POST['filiation']); ?>">
                      
                        <option value="Père">Père</option>
                        <option value="Mère">Mère</option>
                        <option value="Oncle">Oncle</option>
                        <option value="Tante"> Tante</option>

                        <option value="Soeur"> Soeur</option>
                        <option value="Frère">Frère</option>
                        <option value="Enfants"> Enfants</option>
                         <option value="Moi même"> Moi même</option>
                        <option value="Autre">Autre</option>
                        
                      </select>
                    </div>

                    <div class="form-group"<?php if (array_key_exists('nomprenom', $errors)) echo 'has-error';?>>
                      <label for="2"> Nom & prénoms du demandeur</label>
                      <input type="text" name="nomprenom" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:<?php echo BOUTON ?>" id="2" placeholder="" required value="<?php if (array_key_exists('nomprenom', $_POST)) echo htmlspecialchars($_POST['nomprenom']); ?>">
                    </div>

                  
                   <div class="form-group"<?php if (array_key_exists('numextrait', $errors)) echo 'has-error';?>>
                      <label for="2"> Numéro de l'extrait </label>
                      <input type="number" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:<?php echo BOUTON ?>" id="2" placeholder="" required value="<?php if (array_key_exists('numextrait', $_POST)) echo htmlspecialchars($_POST['numextrait']); ?>">
                    </div>



                   
   <div class="form-group"<?php if (array_key_exists('datereg', $errors)) echo 'has-error';?>>
                      <label for="3"> Date du régistre</label>
                      <input type="date"autofocus=""data-provide="datepicker" data-date-format="dd/mm/yyyy" name="datereg"style="border:1px solid #ddd;font-family:arial;text-transform:none;color:<?php echo BOUTON ?>" class="form-control form-control-sm  " id="3" placeholder="" required value="<?php if (array_key_exists('datereg', $_POST)) echo htmlspecialchars($_POST['datereg']); ?>">
                    </div>




                
              
          
              
           <div class="form-group">

                    <div class="custom-control custom-checkbox" style="line-height: 1.5rem;">
                    <input type="checkbox" class="custom-control-input" id="customCheck"required="" checked="">
                    <label class="custom-control-label" for="customCheck"checked=""> <b> Pièce Jointe :</b><b  style="color: red"> Une photo de l'extrait de naissance original de moins de 6 mois à Uploader   </b>
                    </label>
                    </div>
                    </div>
              
      
                   
                   <!-- <div class="form-group"<?php //if (array_key_exists('photo', $errors)) echo 'has-error';?>>
                         <label for="13"> Envoyez une copie de l'extrait</label>
                        
                     
                            <div class="col-lg-13">
                      <input  data-toggle="popover" title="Une copie de l'extrait de naissance "data-placement="bottom"
                    data-content="Autorisées 'jpg', 'jpeg', 'gif','png','jfif'" class="form-control form-control-sm  " placeholder="Uploader" form-control form-control-sm -sm"name="photo"required type="file" value="<?php  //if (array_key_exists('photo', $_POST)) echo htmlspecialchars($_POST['photo']); ?>">
                            </div> </div> -->
                       

                      
        
                   

  
        
                   
                    <button type="submit"name="ajouter_demande_actes_de_naissance"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar"> ENREGISTRER
</button>
                  </div>
                </div>
              </div>
</div>
           </form>       
             



             
      




























































































































































     <!--<div class="alert alert-danger"style="font-size:14px; background-color:skyblue;border-color:skyblue;color:white;border-radius:20px;visibility: visible; animation-name:fadeInRightBig">
    <center><i class="fa fa-bullhorn"id="DivClignotantesiaka"></i> Salut !!!  <b> utilisateur .</b> Veillez avant de continuer prévoir une image de la copie de l'original de l'acte de naissance que vous allez uploader apres le remplissage du formualaire</center>
    </div>-->
            <!-- Earnings (Monthly) Card Example 
                <div class="card-body"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.20)!important;background-color:white">












                 


                     
             
               

                </div>-->
             
            <br> <br> 
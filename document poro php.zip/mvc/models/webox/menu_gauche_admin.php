    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="./goodoo.php?webox=<?php echo DASHBOARD;?>"style="background:<?php echo GAUCHE;?>;box-shadow: 0 0.15rem 1.75rem 0 rgb(58 59 69 / 10%) !important;border-bottom: 0.0rem solid orange ;border-right:1px solid <?php echo BODY2;?>;    min-height: 50px;">
        <div class="sidebar-brand-icon"style="font-weight:bolder;font-family:mistral;background-color:;border-radius: 100%">
         <!-- <img src="./mvc/vues/img/logo/siaka.png" style=" height:23px;width:20px">   -->
                <i class="fas fa-shopping-cart text-warning"style="visibility: visible; -webkit-animation: fadeInLefte 3.1s ; "></i>   
        </div>
        <div class="sidebar-brand-text mx-1">
         <img src="./mvc/vues/img/logo/cccc.png" style=" height:23px;width:180px;visibility: visible; -webkit-animation: fadeInLefte 2.9s ; ">   </div>
      </a>
      
     

      
     
      <hr class="sidebar-divider my-0">
      <li class="nav-item"style="background:<?php echo BODY;?>">
        <a class="nav-link collapsed" href="#" data-toggle="modal" data-target="#COMPTE" id="#modalCenter"title="COMPTE <?php echo strtoupper($_SESSION['compte']);?>">
       
                <?php 

                ##############################################################################################################################################################
/*
                  if(isset($_SESSION['id']) AND $_SESSION['droitacces']=='1'){
                    $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                    $donnees=$req->fetch(); 
                    if($req){       
                        if(empty($donnees['photo'])) {
                    echo'<img class="img-profile" src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;max-width: 60px;height:20px;width:20px">';
                }
                else
                {
                       echo'<img class="img-profile" src="./mvc/vues/img/photo/admin/'.$donnees['photo'].'" style="border-radius:100%;max-width: 60px;height:20px;width:20px">';
                }
                 
                        }
                     }
        
          */
                  ##############################################################################################################################################################

                   ?>
                             <i class="fas fa-fw fa-lock fa-3x text-info"></i>
          <span>

            <?php 
                  if(isset($_SESSION['id'])){
                    $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
                    $donnees=$req->fetch(); 
                    if($req){
                      echo '<b>'.strtoupper(substr($_SESSION['compte'],0,20)).'</b>';
                  }
                  }
                  
                   ?></span></a>
      </li>
        
      
      <?php 

      ##############################################################################################################################################################

        if(isset($_SESSION['id']) AND $_SESSION['droitacces']==1){
        $req=$bdd->query('SELECT*FROM users WHERE id="'.$_SESSION['id'].'"'); 
        $donnees=$req->fetch(); 
        if($req){
       
        
      echo'

        <hr class="sidebar-divider">
      <div class="sidebar-heading">
        CALENDRIER DU JOUR
      </div>

      <li class="nav-item active">
        <a class="nav-link" data-toggle="modal" data-target="#INTERVALLE" id="#modalCenter"title="La date du jour "style="background:'.BODY.'">
          <i class="fas fa-fw fa-calendar-check fa-3x text-danger"></i>
          <span class="badge badge-danger progress-bar progress-bar-striped progress-bar-animated bg-danger">';
                $date=getdate();
                //setlocale(LC_TIME.'fr.UTF8');
                //echo strftime('%d %B %Y');
                $joura=date('d');
                $moisa=date('m');
                $anneea=date('Y');
                $jour=$joura.'/'.$moisa.'/'.$anneea;
              echo $jour;
        echo'</span></a>
      </li>
    
        <hr class="sidebar-divider">
      <div class="sidebar-heading">
        MENU DE LA PLATEFORME
      </div>

      <li class="nav-item active">
        <a class="nav-link" href="./goodoo.php?webox='.DASHBOARD.'"title="Mon tableau de bord"style="background:'.BODY3.'">
          <i class="fas fa-fw fa-tachometer-alt fa-3x text-info"></i>
          <span>Tableau de Bord</span></a>
      </li>
    


       <li class="nav-item active"style="background:">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable2" aria-expanded="true"
          aria-controls="collapseTable">
           <i class="fas fa-fw fa-cart-plus fa-3x text-info"></i>
          <span>TarifIcation</b></span>
        </a>
        <div id="collapseTable2" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header"style="background:orange;color:white">GRILLE TARIFAIRE</h6>
                    <a class="collapse-item" href="./goodoo.php?webox='.GRILLE_TARIFAIRE.'"title="Ajouter un tarif">Ajouter & Modifier </a>
            <a class="collapse-item" href="'.URL.'goodoo.php?webox='.LISTE_DES_TARIFS.'" title="Liste des tarifs">Les tarifs des services</a>
    <a class="collapse-item" href="'.URL.'goodoo.php?webox='.LISTE_DES_FRAIS.'" title="Liste des tarifs">Les frais d\'expéditions.</a>
           
          <a class="collapse-item" href="'.URL.'goodoo.php?webox='.LISTE_DES_FRAIS2.'" title="Liste des tarifs à domicile">Les frais de livraison.</a>
              
          
           
          </div>
        </div>
      </li>

         <!-- <li class="nav-item active">
        <a class="nav-link" title="Mon tableau de bord"style="background:'.BODY.'"href="'.URL.'goodoo.php?webox='.ACTIVER_UNE_DEMANDE.'">
          <i class="fas fa-fw fa-check-circle fa-3x text-info"></i>
          <span>Activer une Demande</span></a>
      </li>-->


       <li class="nav-item active"style="background:'.BODY.'">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable3" aria-expanded="true"
          aria-controls="collapseTable">
            <i class="fas fa-fw fa-search fa-3x text-info"></i>
          <span> Rechercher </b></span>
        </a>
        <div id="collapseTable3" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header"style="background:#01D758;color:white">RECHERCHE PERSONNALISEE</h6>
                    <a class="collapse-item"data-toggle="modal" data-target="#DEMANDE" id="#modalCenter"title="Ajouter un tarif">Sur une demande  </a>
            <a class="collapse-item" data-toggle="modal" data-target="#INTERVALLE" id="#modalCenter" title="Liste des tarifs"> Dans un intervalle de date</a>
           </div>
        </div>
      </li>
      

       <hr class="sidebar-divider">
      <div class="sidebar-heading">
       MONTANT EN CAISSE
      </div>

      <li class="nav-item active">
        <a class="nav-link collapsed" href="#" data-toggle="modal" data-target="#MONTANT" id="#modalCenter"style="background:'.BODY.'">
          <i class="fas fa-fw fa-shopping-bag fa-3x text-primary"></i> 
          <span class="badge badge-primary progress-bar progress-bar-striped progress-bar-animated bg-primary">';

                    $reponse=$bdd->query("SELECT SUM(solde) AS idd FROM demandes WHERE paiement=1");
                    while($donnees = $reponse ->fetch()){
                     echo''.$donnees['idd'].' FCFA';
                    } $reponse->closeCursor();
             
        echo' </span></a>
      </li>
       <hr class="sidebar-divider">
      <div class="sidebar-heading">
       STATISTIQUE VISITEURS
      </div>

      <li class="nav-item active">
        <a class="nav-link collapsed" href="'.URL.'goodoo.php?webox='.VISITEURS.'"style="background:'.BODY.'">
          <i class="fas fa-fw fa-user-plus fa-3x text-warning"></i>
          <span class="badge badge-warning progress-bar progress-bar-striped progress-bar-animated bg-warning"style="border-radius:">';
                $reponse=$bdd->query("SELECT COUNT(*) AS ip  FROM visiteurs"); 
                          while($donnees = $reponse ->fetch()){
                               echo'000'.$donnees['ip'].' ';
                          } 
                          $reponse->closeCursor();
             
        echo'</span></a>
      </li>
      
       <hr class="sidebar-divider">
       <div class="sidebar-heading">
        PARAMETRES DU COMPTE
      </div>
       <li class="nav-item active"style="background:'.CONTENU.'"href="#search">
        <a class="nav-link collapsed" href="#" data-toggle="modal" data-target="#DECONNEXION" id="#modalCenter"style="background:'.BODY.'">
          <i class="fas fa-fw fa-power-off fa-3x text-info"></i>
          <span> <b>Deconnexion</b></span>
        </a>
        
      </li> 

       <!-- --> <hr class="sidebar-divider">
    <div class="version">Version <b style="color:orange;font-family:arial black">1.0.3</b></div>
    </ul>

      ';
      }
        }
       
 
        
        ##############################################################################################################################################################          
       ?>      
      
      
     
  




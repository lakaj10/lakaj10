<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-ambulance fa-1x "style="color:<?php echo TITRE;?>"></i> Actes de décès</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Actes de décès</li>
            </ol>
          </div>


<?php


$errors = [];
mb_internal_encoding('UTF-8');


if ('POST' == $_SERVER['REQUEST_METHOD']) {

if (isset($_POST['ajouter_demande_actes_de_deces'])) {

  $pu=$_POST['pu'];
  $nbrecopie=$_POST['nbrecopie'];
  $montant=$pu*$nbrecopie;
  $coded=$_POST['coded'];
   $bdd->exec("UPDATE demandes_adde_tmp SET 
    nbrecopie='".$_POST['nbrecopie']."',
     montant='".$montant."',
    lieudemande='".$_POST['lieudemande']."',
    villelivrai='".$_POST['villelivrai']."'
    WHERE  coded='".$coded."'");
      
    if ($req) {
     $reponse = $bdd->query('SELECT * FROM demandes_adde_tmp WHERE coded="'.$_POST['coded'].'" ORDER BY idde DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {
                  
              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DECES_IDENTIQUE_DEUX.'&identifiant_demande='.$_POST['coded'].'"</SCRIPT>'; 

                  
                }
      }
   }
}

if($errors) {
echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div>';

}

?> 



 <?php 
  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   

   $reponse=$bdd->query("SELECT*FROM demandes_adde_tmp WHERE coded='".$identifiant_demande."' ORDER BY demandes_adde_tmp.idde  DESC LIMIT 0, 1");

$nb_resultats = $reponse->rowCount(); 
$res = $reponse->fetchAll();
if (count($res) == 0) 
{   
    echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DECES.'"</SCRIPT>'; 

    }
    else
    {
      foreach ($res as $donnees) {

echo'
    <form method="POST" action=""  autocomplete="off" enctype="multipart/form-data">
      
        <div class="row">
            <div class="col-lg-12">
              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;background-color:white">
               
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-primary">FORMULAIRE DE DEMANDE</h6>
                
                  </div>

                <div class="card-body">

                  <div class="form-group">
                      <label for="2"> Filiation du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['filiation'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Nom & prénoms du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['nomprenom'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Numéro de la CNI </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['numcni'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Nom & prénoms du defunt </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['defunt'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Date de naissance </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['dn'].'">
                    </div>

                     <div class="form-group">
                      <label for="2"> Lieu de naissance </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['ln'].'">
                    </div>


                  <input  value="'.ucfirst($donnees['coded']).'" type="hidden"class="form-control form-control-sm "style=" font-family:verdana ;color:'.COULEUR.';background-color:'.COULEURT.'" name="coded">

                  <input  value="'.ucfirst($donnees['pu']).'" type="hidden"class="form-control form-control-sm "style=" font-family:verdana ;color:'.COULEUR.';background-color:'.COULEURT.'" name="pu">

                   


                  



    <div class="form-group">
    
                      <label for="54"> Lieu de la demande</label>
                      <select name="lieudemande"style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="54"class="form-control form-control-sm  " value=""required="">

<option value="Agboville"> Agboville</option>
<option value="Sikensi">Sikensi</option>
<option value="Tiassale"> Tiassale</option>
<option value="Koro">Koro</option>
<option value="Ouaninou"> Ouaninou</option>
<option value="Touba">Touba</option>
<option value="Boundiali"> Boundiali</option>
<option value="Kouto">Kouto</option>
<option value="Tengrela"> Tengrela</option>
<option value="Didievi">Didievi</option>


<option value="Tiebissou"> Tiebissou</option>
<option value="Toumodi">Toumodi</option>
<option value="Kounahiri"> Kounahiri</option>
<option value="Mankono">Mankono</option>
<option value="Dianra">Dianra</option>
<option value="Teningboue">Tieningboue</option>
<option value="Bouna"> Bouna</option>
<option value="Doropo">Doropo</option>
<option value="Nassian"> Nassian</option>
<option value="Tehini">Tehini</option>
<option value="Blolequin"> Blolequin</option>
<option value="Guiglo">Guiglo</option>


<option value="Toulepleu"> Toulepleu</option>
<option value="Kaniasso">Kaniasso</option>
<option value="Minignan"> Minignan</option>
<option value="Beoumi">Beoumi</option>
<option value="Bouake"> Bouake</option>
<option value="Sakassou">Sakassou</option>
<option value="Botro"> Botro</option>
<option value="Fresco">Fresco</option>
<option value="Sassandra"> Sassandra</option>
<option value="Gagnoa">Gagnoa</option>


<option value="Oume"> Oume</option>
<option value="Bondoukou">Bondoukou</option>
<option value="Koun-Fao"> Koun-Fao</option>
<option value="Sandegue">Sandegue</option>
<option value="Tanda"> Tanda</option>
<option value="Transua">Transua</option>
<option value="Dabou"> Dabou</option>
<option value="Grand-Lahou">Grand-Lahou</option>
<option value="Jacqueville"> Jacqueville</option>
<option value="Bangolo">Bangolo</option>


<option value="Duekoue"> Duekoue</option>
<option value="Kouibly">Kouibly</option>
<option value="Dabakala"> Dabakala</option>
<option value="Katiola">Katiola</option>
<option value="Niakaramandougou"> Niakaramandougou</option>
<option value="Daloa">Daloa</option>
<option value="Issia"> Issia</option>
<option value="Vavoua">Vavoua</option>
<option value="Zoukougbeu"> Zoukougbeu</option>
<option value="Daoukro">Daoukro</option>


<option value="Mbahiakro"> Mbahiakro</option>
<option value="Prikro">Prikro</option>
<option value="Abengourou"> Abengourou</option>
<option value="Agnibilekro">Agnibilekro</option>
<option value="Bettie"> Bettie</option>
<option value="Madinani">Madinani</option>
<option value="Odienne"> Odienne</option>
<option value="Samatiguila">Samatiguila</option>
<option value="Divo"> Divo</option>
<option value="Guitry">Guitry</option>


<option value="Lakota"> Lakota</option>
<option value="Bouafle">Bouafle</option>
<option value="Sinfra"> Sinfra</option>
<option value="Zuenoula">Zuenoula</option>
<option value="Adzope"> Adzope</option>
<option value="Akoupe">Akoupe</option>
<option value="Alepe"> Alepe</option>
<option value="Yakasse-Attobrou">Yakasse-Attobrou</option>
<option value="Arrah"> Arrah</option>
<option value="Bongouanou">Bongouanou</option>


<option value="Mbatto"> Mbatto</option>
<option value="Gueyo">Gueyo</option>
<option value="Soubre"> Soubre</option>
<option value="Bokanda">Bokanda</option>
<option value="Dimbokro"> Dimbokro</option>
<option value="Dikodougou">Dikodougou</option>
<option value="Korhogo"> Korhogo</option>
<option value="Sinematiali">Sinematiali</option>
<option value="San-Pedro"> San-Pedro</option>
<option value="Tabou">Tabou</option>


<option value="Aboisso"> Aboisso</option>
<option value="Adiake">Adiake</option>
<option value="Grand-Bassam"> Grand-Bassam</option>
<option value="Tiapoum">Tiapoum</option>
<option value="Ferkessedougou"> Ferkessedougou</option>
<option value="Ouangolodougou">Ouangolodougou</option>
<option value="Biankouma"> Biankouma</option>
<option value="Danane">Danane</option>
<option value="Man"> Man</option>
<option value="Zouan-Hounien">Zouan-Hounien</option>


<option value="Buyo"> Buyo</option>
<option value="Meagui">Meagui</option>
<option value="Kani"> Kani</option>
<option value="Seguela">Seguela</option>
<option value="Gbeleban">Gbeleban</option>
<option value="Seguelon">Seguelon</option>
<option value="Bocanda"> Bocanda</option>
<option value="Kouassi-Kouassikro">Kouassi-Kouassikro</option>
<option value="Taabo"> Taabo</option>
<option value="Taï">Taï</option>


<option value="Facobli"> Facobli</option>
<option value="Sipilou">Sipilou</option>
<option value="Mbengue"> Mbengue</option>
<option value="Kong">Kong</option>
<option value="Ouanimou"> Ouanimou</option>
<option value="Kani">Kani</option>
<option value="Sandegue"> Sandegue</option>
<option value="Zouan-Hounien">Zouan-Hounien</option>
<option value="Autre">Autre</option>


</select>
                    </div>

                  ';

}
}
}
    
                   echo' <div class="form-group">
                      <label for="66"> Ville d\'expédition </label>
                      <select name="villelivrai"id="66"style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" class="form-control form-control-sm  " value=""required="">

<option value="Abidjan"> Abidjan</option>
<option value="Bouake">Bouake</option>
<option value="Daloa"> Daloa</option>
<option value="Yamoussoukro">Yamoussoukro</option>
<option value="Korhogo"> Korhogo</option>
<option value="Divo">Divo</option>
<option value="San-pedro"> San-pedro</option>
<option value="Anyama">Anyama</option>
<option value="Man"> Man</option>
<option value="Gagnoa">Gagnoa</option>
<option value="Dianra">Dianra</option>
<option value="Teningboue">Tieningboue</option>


<option value="Abengourou"> Abengourou</option>
<option value="Dabou">Dabou</option>
<option value="Bouafle"> Bouafle</option>
<option value="Grand bassam">Grand bassam</option>
<option value="Dimbokro"> Dimbokro</option>
<option value="Agboville">Agboville</option>
<option value="Sinfra"> Sinfra</option>
<option value="Bingerville">Bingerville</option>
<option value="Danane"> Danane</option>
<option value="Bondoukou">Bondoukou</option>


<option value="Ferkessedougou"> Ferkessedougou</option>
<option value="Katiola">Katiola</option>
<option value="Issia"> Issia</option>
<option value="Oume">Oume</option>
<option value="Odienne"> Odienne</option>
<option value="Toumodi">Toumodi</option>
<option value="Adzope"> Adzope</option>
<option value="Soubre">Soubre</option>
<option value="Duekoue"> Duekoue</option>
<option value="Seguela">Seguela</option>


<option value="Agnibilekrou"> Agnibilekrou</option>
<option value="Daoukro">Daoukro</option>
<option value="Aboisso"> Aboisso</option>
<option value="Tiassale">Tiassale</option>
<option value="Akoupe"> Akoupe</option>
<option value="Lakota">Lakota</option>
<option value="Tingrela"> Tingrela</option>
<option value="Guiglo">Guiglo</option>
<option value="Boundiali"> Boundiali</option>
<option value="Bonoua">Bonoua</option>


<option value="Arrah"> Arrah</option>
<option value="Zuenoula">Zuenoula</option>
<option value="Vavoua"> Vavoua</option>
<option value="Affery">Affery</option>
<option value="Bongouanou"> Bongouanou</option>
<option value="Hire">Hire</option>
<option value="Mbatto"> Mbatto</option>
<option value="Touba">Touba</option>
<option value="Ouragahio"> Ouragahio</option>
<option value="Bouna">Bouna</option>


<option value="Sassandra"> Sassandra</option>
<option value="Ndouci">Ndouci</option>
<option value="Biankouma"> Biankouma</option>
<option value="Tanda">Tanda</option>
<option value="Tiebissou"> Tiebissou</option>
<option value="Tabou">Tabou</option>
<option value="Mankono"> Mankono</option>
<option value="Beoumi">Beoumi</option>
<option value="Bangolo"> Bangolo</option>
<option value="Adiake">Adiake</option>


<option value="Dikodougou"> Dikodougou</option>
<option value="Dabakala">Dabakala</option>
<option value="Rubino"> Rubino</option>
<option value="Bako">Bako</option>
<option value="Sakassou"> Sakassou</option>
<option value="Kani">Kani</option>
<option value="Tafire"> Tafire</option>
<option value="Mbahiakro">Mbahiakro</option>
<option value="Toulepleu"> Toulepleu</option>
<option value="Fresco">Fresco</option>


<option value="Jacqueville"> Jacqueville</option>
<option value="Guiberoua">Guiberoua</option>
<option value="Ayame"> Ayame</option>
<option value="Botro">Botro</option>
<option value="Alepe"> Alepe</option>
<option value="Ndiekro">Ndiekro</option>
<option value="Bocanda"> Bocanda</option>
<option value="Grand-lahou">Grand-lahou</option>

<option value="Autre">Autre</option>

</select>
                    </div>



                    <div class="form-group">
                      <label for="13"> Nombre de copies</label>
                      <select class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" name="nbrecopie"id="31"autofocus value=""required="">
                       <option value="2"> 2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6"> 6</option>

                        <option value="7"> 7</option>
                        <option value="8">8</option>
                        <option value="9"> 9</option>
                        <option value="10">10</option>
                        
                      </select>
                    </div>



                 




                   
                    <button type="submit"name="ajouter_demande_actes_de_deces"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar"> ENREGISTRER</button>
                  </div>
                </div>
              </div>
</div>
           </form>  
                                ';
?>

             

















































































































































































     <!--<div class="alert alert-danger"style="font-size:14px; background-color:skyblue;border-color:skyblue;color:white;border-radius:20px;visibility: visible; animation-name:fadeInRightBig">
    <center><i class="fa fa-bullhorn"id="DivClignotantesiaka"></i> Salut !!!  <b> utilisateur .</b> Veillez avant de continuer prévoir une image de la copie de l'original de l'acte de naissance que vous allez uploader apres le remplissage du formualaire</center>
    </div>-->
            <!-- Earnings (Monthly) Card Example 
                <div class="card-body"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.20)!important;background-color:white">












                 


                     
             
               

                </div>-->
             
            <br> <br> 
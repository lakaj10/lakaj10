 <?php 



$idd=htmlspecialchars($_GET["idd"]) ;
$go=htmlspecialchars($_GET["go"]) ;
if(empty($idd) || empty($go) )
{
	echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>';

}
elseif(isset($idd) AND isset($go))
{
	$idd=htmlspecialchars($_GET["idd"]) ;
        $go=htmlspecialchars($_GET["go"]) ;
        $jour = date('d');
        $mois = date('m');
        $annee = date('Y');
        $heure = date('H');
        $minute = date('i');
        $datepaiement=$jour.'/'.$mois.'/'.$annee;
        $paiement=1 ;
        $bdd->exec("UPDATE demandes SET datepaiement='".$datepaiement."',paiement='".$paiement."' WHERE idd='".$_GET['idd']."'");
        $bdd->exec("UPDATE demandes_adn SET datepaiement='".$datepaiement."',paiement='".$paiement."' WHERE coded='".$_GET['go']."'");
	//$bdd->exec("UPDATE users SET activer='".$activation_du_compte."' WHERE id='".$_GET['id']."'");
	//echo '<script type="text/javascript"> alert(\'             Opération éffectuée avec succès            \');</script>';

if($bdd)
{
	echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.SEARCH.'&SearchBrowserData='.$go.'"</SCRIPT>';
}
}
else
{
	echo("echoué") ;
}

?>





<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-cart-plus fa-1x "style="color:<?php echo TITRE;?>"></i> Tarification</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Tarification</li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example 

        <div class="card-body"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.20)!important;background-color:white">-->

          <!--Row-->
         <?php
$errors = [];
mb_internal_encoding('UTF-8');

if ('POST' == $_SERVER['REQUEST_METHOD']) {
  if (isset($_POST['v'])) {
          
  if (isset($_POST['v'])) {
    $stmt = $bdd->prepare('SELECT 1 FROM tarif WHERE code = :code');
    $stmt->execute(['code' => $_POST['code']]);
    if (FALSE !== $stmt->fetchColumn()) {
    $errors['code'] = "Tentative de doublon";
    }

  } 

     if (isset($_POST['v'])) {
    $stmt = $bdd->prepare('SELECT 1 FROM tarif WHERE nom = :nom');
    $stmt->execute(['nom' => $_POST['nom']]);
    if (FALSE !== $stmt->fetchColumn()) {
    $errors['nom'] = "Demande existante";
    }

  } 


 

// si tout est bon je commence le traitement des formulaires
  if(!$errors) {
   
   if(isset($_POST['nom']) AND $_POST['nom']=='Actes de Naissance' || $_POST['nom']=='Actes de Mariage' || $_POST['nom']=='Actes de Décès' || $_POST['nom']=='Certification de Document')
   {
    $type='Etat civil';
   }
   else
   {
    $type='Actes de justice';
   }
   $req= $bdd->prepare('INSERT INTO tarif(code,type,nom,montant)VALUES(?,?,?,?)');
   $req->execute(array($_POST['code'],$type,$_POST['nom'],$_POST['montant']));
      
    if ($req) {
     $reponse = $bdd->query('SELECT * FROM tarif WHERE code="'.$_POST['code'].'" ORDER BY idt DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {
            //echo '<div class="alert alert-success"> Demande ajoutée avec succès ...</div>  <META HTTP-EQUIV="refresh" CONTENT="1; URL=#">';
 echo '<script type="text/javascript"> alert(\'  Demande ajoutée avec succès  \');</script>';
          }
         }
        }
       }
      }
      


        if($errors) {

                echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div><META HTTP-EQUIV="refresh" CONTENT="1; URL=#">';
        }



  srand((double)microtime()*10000);
$num=rand();
$coded1=$num;
$coded2=substr($coded1,0,4);
$code=$coded2;
//echo $coded;
echo'  <input type="hidden" name="code" value="'.$code.'"/>';   

    


?> 







         <?php
$errors = [];
mb_internal_encoding('UTF-8');

if ('POST' == $_SERVER['REQUEST_METHOD']) {
    if (isset($_POST['m'])) {
     $stmt = $bdd->prepare('SELECT 1 FROM tarif WHERE nom = :nom');
     $stmt->execute(['nom' => $_POST['nom']]);
  if (FALSE !== $stmt->fetchColumn()) {
    $bdd->exec("UPDATE tarif SET montant='".$_POST['montant']."' WHERE  nom='".$_POST['nom']."'");
     if($bdd==true)
   {
   echo '
            <div class="alert alert-success"> Demande modifiée </div>  
            <META HTTP-EQUIV="refresh" CONTENT="1; URL=#">';
   }
  }
  else{
    $errors['nom'] = "Demande non ajouté ";
    }
          
  
}
      }
      


        if($errors) {
                echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div><META HTTP-EQUIV="refresh" CONTENT="1; URL=#">';

        }

?> 






















         <?php
$errors = [];
mb_internal_encoding('UTF-8');

if ('POST' == $_SERVER['REQUEST_METHOD']) {
  if (isset($_POST['vf'])) {
          
  if (isset($_POST['vf'])) {
    $stmt = $bdd->prepare('SELECT 1 FROM frais WHERE code = :code');
    $stmt->execute(['code' => $_POST['code']]);
    if (FALSE !== $stmt->fetchColumn()) {
    $errors['code'] = "Tentative de doublon";
    }

  } 

     if (isset($_POST['vf'])) {
    $stmt = $bdd->prepare('SELECT 1 FROM frais WHERE ville = :ville');
    $stmt->execute(['ville' => $_POST['ville']]);
    if (FALSE !== $stmt->fetchColumn()) {
    $errors['nom'] = "Ville existante";
    }

  } 


 

// si tout est bon je commence le traitement des formulaires
  if(!$errors) {
   
  
   $req= $bdd->prepare('INSERT INTO frais(code,ville,montant)VALUES(?,?,?)');
   $req->execute(array($_POST['code'],$_POST['ville'],$_POST['montant']));
      
    if ($req) {
     $reponse = $bdd->query('SELECT * FROM frais WHERE code="'.$_POST['code'].'" ORDER BY idf DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {
            echo '
            <div class="alert alert-success"> Ville ajoutée </div>  <META HTTP-EQUIV="refresh" CONTENT="1; URL=#">';
          }
         }
        }
       }
      }
      


        if($errors) {
                echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div><META HTTP-EQUIV="refresh" CONTENT="1; URL=#">';
        }





?> 






         <?php
$errors = [];
mb_internal_encoding('UTF-8');

if ('POST' == $_SERVER['REQUEST_METHOD']) {
    if (isset($_POST['mf'])) {
     $stmt = $bdd->prepare('SELECT 1 FROM frais WHERE ville = :ville');
     $stmt->execute(['ville' => $_POST['ville']]);
  if (FALSE !== $stmt->fetchColumn()) {
    $bdd->exec("UPDATE frais SET montant='".$_POST['montant']."' WHERE  ville='".$_POST['ville']."'");
     if($bdd==true)
   {
   echo '
            <div class="alert alert-success"> Frais de la ville modifié</div> <META HTTP-EQUIV="refresh" CONTENT=1"; URL=#">';
            
   }
  }
  else{
    $errors['nom'] = "Ville non ajoutée ";
    }
          
  
}
      }
      


        if($errors) {
                echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div><META HTTP-EQUIV="refresh" CONTENT="1; URL=#">';

        }

?> 











         <?php
$errors = [];
mb_internal_encoding('UTF-8');

if ('POST' == $_SERVER['REQUEST_METHOD']) {
  if (isset($_POST['vc'])) {
          
  if (isset($_POST['vc'])) {
    $stmt = $bdd->prepare('SELECT 1 FROM commune WHERE code = :code');
    $stmt->execute(['code' => $_POST['code']]);
    if (FALSE !== $stmt->fetchColumn()) {
    $errors['code'] = "Tentative de doublon";
    }

  } 

     if (isset($_POST['vc'])) {
    $stmt = $bdd->prepare('SELECT 1 FROM commune WHERE nom = :nom');
    $stmt->execute(['nom' => $_POST['nom']]);
    if (FALSE !== $stmt->fetchColumn()) {
    $errors['nom'] = "commune existante";
    }

  } 


 

// si tout est bon je commence le traitement des formulaires
  if(!$errors) {
   
  
   $req= $bdd->prepare('INSERT INTO commune(code,nom,montant)VALUES(?,?,?)');
   $req->execute(array($_POST['code'],$_POST['nom'],$_POST['montant']));
      
    if ($req) {
     $reponse = $bdd->query('SELECT * FROM commune WHERE code="'.$_POST['code'].'" ORDER BY idco DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {
            echo '
            <div class="alert alert-success"> Ville ajoutée </div>  <META HTTP-EQUIV="refresh" CONTENT="1; URL=#">';
          }
         }
        }
       }
      }
      


        if($errors) {
                echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div><META HTTP-EQUIV="refresh" CONTENT="1; URL=#">';
        }





?> 








         <?php
$errors = [];
mb_internal_encoding('UTF-8');

if ('POST' == $_SERVER['REQUEST_METHOD']) {
    if (isset($_POST['mfi'])) {
     $stmt = $bdd->prepare('SELECT 1 FROM commune WHERE nom = :nom');
     $stmt->execute(['nom' => $_POST['nom']]);
  if (FALSE !== $stmt->fetchColumn()) {
    $bdd->exec("UPDATE commune SET montant='".$_POST['montant']."' WHERE  nom='".$_POST['nom']."'");
     if($bdd==true)
   {
   echo '
            <div class="alert alert-success"> Frais de la commune modifié</div> <META HTTP-EQUIV="refresh" CONTENT=1"; URL=#">';
            
   }
  }
  else{
    $errors['nom'] = "commune non ajoutée ";
    }
          
  
}
      }
      


        if($errors) {
                echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div><META HTTP-EQUIV="refresh" CONTENT="1; URL=#">';

        }

?> 














<form method="post" action=""  autocomplete="on">

         <?php

  srand((double)microtime()*10000);
$num=rand();
$coded1=$num;
$coded2=substr($coded1,0,4);
$code=$coded2;
//echo $coded;
echo'  <input type="hidden" name="code" value="'.$code.'"/>';   

    


?> 
           
<div class="row">
          
            <div class="col-lg-6">


              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;background-color:white">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-warning">AJOUTER UNE DEMANDE</h6>
                </div> 


                 <div class="card-body">

                    <div class="form-group">
                                            <label for="11"> Demande</label>

                        <select class="form-control form-control-sm"style="border:1px solid skyblue;font-family:arial;text-transform:uppercase;color:<?php echo TEXTE2 ?>;" name="nom"id="11"autofocus>
                     
                        <option value="Actes de Naissance">Actes de Naissance</option>
                        <option value="Actes de Mariage">Actes de Mariage</option>
                        <option value="Actes de Décès">Actes de Décès</option>
                        <option value="Certification de Document"> Certification de Document</option>
                           

                        <option value="Casiers Judiciaires">Casiers Judiciaires</option>
                        <option value="Certificat de Nationalite Ivoirienne"> Certificat de Nationalite Ivoirienne</option>
                        
                      </select>
                    </div>
                    

                     <div class="form-group">
                      <label for="3"> Prix unitaire</label>
                      <select class="form-control form-control-sm"style="border:1px solid skyblue;font-family:arial;text-transform:uppercase;color:<?php echo TEXTE2 ?>;" name="montant"id="11"autofocus>
                      <option value="500">500</option>
                        <option value="1000">1000</option>
                        <option value="1500">1500</option>
                        <option value="2000">2000</option>
                       <option value="2500">2500</option>
                        <option value="3000">3000</option>
                        <option value="3500">3500</option>
                        <option value="4000">4000</option>
                        <option value="4500">4500</option>
                        <option value="5000">5000</option>
                        <option value="5500">5500</option>
                        <option value="6000">6000</option>
                        <option value="6500">6500</option>
                        <option value="7000">7000</option>
                        <option value="7500">7500</option>
                        <option value="8000">8000</option>
                        <option value="8500">8500</option>
                        <option value="9000">9000</option>
                        <option value="9500">9500</option>
                        <option value="10000">10000</option>
                        
                      </select>
                    </div>

               



                   
                    <button type="submit"name="v"  class="btn btn-warning  btn-sm progress-bar progress-bar-striped progress-bar-animated bg-warning">  AJOUTER </button>
                  </form>
               

                </div>
             
         

        </div>  </div>  





































            <div class="col-lg-6">



              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;background-color:white">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-primary">MODIFIER UNE DEMANDE</h6>
                </div> 

<form method="post" action=""  autocomplete="on">
                 <div class="card-body">
                  
                    <div class="form-group">
                                            <label for="111"> Demande</label>

                        <select class="form-control form-control-sm"style=";color:<?php echo TEXTE2 ?>;border:1px solid skyblue;font-family:arial;text-transform:uppercase" name="nom"id="111"autofocus>
                     
                       <option value="Actes de Naissance">Actes de Naissance</option>
                        <option value="Actes de Mariage">Actes de Mariage</option>
                        <option value="Actes de Décès">Actes de Décès</option>
                        <option value="Certification de Document"> Certification de Document</option>
                           

                        <option value="Casiers Judiciaires">Casiers Judiciaires</option>
                        <option value="Certificat de Nationalite Ivoirienne"> Certificat de Nationalite Ivoirienne</option>
                        
                      </select>
                    </div>
                    

                     <div class="form-group">
                      <label for="33"> Prix unitaire</label>
                       <select class="form-control form-control-sm"style="border:1px solid skyblue;font-family:arial;text-transform:uppercase;color:<?php echo TEXTE2 ?>;" name="montant"id="33"autofocus>
                      <option value="500">500</option>
                        <option value="1000">1000</option>
                        <option value="1500">1500</option>
                        <option value="2000">2000</option>
                       <option value="2500">2500</option>
                        <option value="3000">3000</option>
                        <option value="3500">3500</option>
                        <option value="4000">4000</option>
                        <option value="4500">4500</option>
                        <option value="5000">5000</option>
                        <option value="5500">5500</option>
                        <option value="6000">6000</option>
                        <option value="6500">6500</option>
                        <option value="7000">7000</option>
                        <option value="7500">7500</option>
                        <option value="8000">8000</option>
                        <option value="8500">8500</option>
                        <option value="9000">9000</option>
                        <option value="9500">9500</option>
                        <option value="10000">10000</option>
                        
                      </select>
                    </div>

                     
                  


                   
                    <button type="submit"name="m"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary">  MODIFIER </button>
                  </form>
               

                </div>
             
         

        </div>  </div>  
             
            






































































            <div class="col-lg-6">


              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;background-color:white">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-info">AJOUTER FRAIS D'EXPEDITION</h6>
                </div> 

<form method="post" action=""  autocomplete="on">

    <?php  
  srand((double)microtime()*10000);
$num=rand();
$coded1=$num;
$coded2=substr($coded1,0,4);
$code=$coded2;
//echo $coded;
echo'  <input type="hidden" name="code" value="'.$code.'"/>';   
?> 

    
                 <div class="card-body">
                  
                    <div class="form-group">
                                            <label for="111"> Ville</label>

                        <select class="form-control form-control-sm"style=";color:<?php echo TEXTE2 ?>;border:1px solid skyblue;font-family:arial;text-transform:uppercase" name="ville"id="111"autofocus>
                     
                      <option value="Abidjan"> Abidjan</option>
<option value="Bouake">Bouake</option>
<option value="Daloa"> Daloa</option>
<option value="Yamoussoukro">Yamoussoukro</option>
<option value="Korhogo"> Korhogo</option>
<option value="Divo">Divo</option>
<option value="San-pedro"> San-pedro</option>
<option value="Anyama">Anyama</option>
<option value="Man"> Man</option>
<option value="Gagnoa">Gagnoa</option>
<option value="Dianra">Dianra</option>
<option value="Teningboue">Tieningboue</option>


<option value="Abengourou"> Abengourou</option>
<option value="Dabou">Dabou</option>
<option value="Bouafle"> Bouafle</option>
<option value="Grand bassam">Grand bassam</option>
<option value="Dimbokro"> Dimbokro</option>
<option value="Agboville">Agboville</option>
<option value="Sinfra"> Sinfra</option>
<option value="Bingerville">Bingerville</option>
<option value="Danane"> Danane</option>
<option value="Bondoukou">Bondoukou</option>


<option value="Ferkessedougou"> Ferkessedougou</option>
<option value="Katiola">Katiola</option>
<option value="Issia"> Issia</option>
<option value="Oume">Oume</option>
<option value="Odienne"> Odienne</option>
<option value="Toumodi">Toumodi</option>
<option value="Adzope"> Adzope</option>
<option value="Soubre">Soubre</option>
<option value="Duekoue"> Duekoue</option>
<option value="Seguela">Seguela</option>


<option value="Agnibilekrou"> Agnibilekrou</option>
<option value="Daoukro">Daoukro</option>
<option value="Aboisso"> Aboisso</option>
<option value="Tiassale">Tiassale</option>
<option value="Akoupe"> Akoupe</option>
<option value="Lakota">Lakota</option>
<option value="Tingrela"> Tingrela</option>
<option value="Guiglo">Guiglo</option>
<option value="Boundiali"> Boundiali</option>
<option value="Bonoua">Bonoua</option>


<option value="Arrah"> Arrah</option>
<option value="Zuenoula">Zuenoula</option>
<option value="Vavoua"> Vavoua</option>
<option value="Affery">Affery</option>
<option value="Bongouanou"> Bongouanou</option>
<option value="Hire">Hire</option>
<option value="Mbatto"> Mbatto</option>
<option value="Touba">Touba</option>
<option value="Ouragahio"> Ouragahio</option>
<option value="Bouna">Bouna</option>


<option value="Sassandra"> Sassandra</option>
<option value="Ndouci">Ndouci</option>
<option value="Biankouma"> Biankouma</option>
<option value="Tanda">Tanda</option>
<option value="Tiebissou"> Tiebissou</option>
<option value="Tabou">Tabou</option>
<option value="Mankono"> Mankono</option>
<option value="Beoumi">Beoumi</option>
<option value="Bangolo"> Bangolo</option>
<option value="Adiake">Adiake</option>


<option value="Dikodougou"> Dikodougou</option>
<option value="Dabakala">Dabakala</option>
<option value="Rubino"> Rubino</option>
<option value="Bako">Bako</option>
<option value="Sakassou"> Sakassou</option>
<option value="Kani">Kani</option>
<option value="Tafire"> Tafire</option>
<option value="Mbahiakro">Mbahiakro</option>
<option value="Toulepleu"> Toulepleu</option>
<option value="Fresco">Fresco</option>


<option value="Jacqueville"> Jacqueville</option>
<option value="Guiberoua">Guiberoua</option>
<option value="Ayame"> Ayame</option>
<option value="Botro">Botro</option>
<option value="Alepe"> Alepe</option>
<option value="Ndiekro">Ndiekro</option>
<option value="Bocanda"> Bocanda</option>
<option value="Grand-lahou">Grand-lahou</option>
                        
                      </select>
                    </div>
                    

                     <div class="form-group">
                      <label for="33"> Frais</label>
                       <select class="form-control form-control-sm"style="border:1px solid skyblue;font-family:arial;text-transform:uppercase;color:<?php echo TEXTE2 ?>;" name="montant"id="33"autofocus>
                         <option value="0">0</option>
                      <option value="500">500</option>
                        <option value="1000">1000</option>
                        <option value="1500">1500</option>
                        <option value="2000">2000</option>
                       <option value="2500">2500</option>
                        <option value="3000">3000</option>
                        <option value="3500">3500</option>
                        <option value="4000">4000</option>
                        <option value="4500">4500</option>
                        <option value="5000">5000</option>
                        <option value="5500">5500</option>
                        <option value="6000">6000</option>
                        <option value="6500">6500</option>
                        <option value="7000">7000</option>
                        <option value="7500">7500</option>
                        <option value="8000">8000</option>
                        <option value="8500">8500</option>
                        <option value="9000">9000</option>
                        <option value="9500">9500</option>
                        <option value="10000">10000</option>
                        
                      </select>
                    </div>

                     
                   

                   
                    <button type="submit"name="vf"  class="btn btn-info btn-sm progress-bar progress-bar-striped progress-bar-animated bg-info">  AJOUTER </button>
                  </form>
               

                </div>
             
         

        </div>  </div>  
             
            












            <div class="col-lg-6">




              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;background-color:white">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-success">MODIFIER FRAIS D'EXPEDITION</h6>
                </div> 

<form method="post" action=""  autocomplete="on">
                 <div class="card-body">
                  
                    <div class="form-group">
                                            <label for="111"> Ville</label>

                        <select class="form-control form-control-sm"style=";color:<?php echo TEXTE2 ?>;border:1px solid skyblue;font-family:arial;text-transform:uppercase" name="ville"id="111"autofocus>
                     
                    <option value="Abidjan"> Abidjan</option>
<option value="Bouake">Bouake</option>
<option value="Daloa"> Daloa</option>
<option value="Yamoussoukro">Yamoussoukro</option>
<option value="Korhogo"> Korhogo</option>
<option value="Divo">Divo</option>
<option value="San-pedro"> San-pedro</option>
<option value="Anyama">Anyama</option>
<option value="Man"> Man</option>
<option value="Gagnoa">Gagnoa</option>
<option value="Dianra">Dianra</option>
<option value="Teningboue">Tieningboue</option>


<option value="Abengourou"> Abengourou</option>
<option value="Dabou">Dabou</option>
<option value="Bouafle"> Bouafle</option>
<option value="Grand bassam">Grand bassam</option>
<option value="Dimbokro"> Dimbokro</option>
<option value="Agboville">Agboville</option>
<option value="Sinfra"> Sinfra</option>
<option value="Bingerville">Bingerville</option>
<option value="Danane"> Danane</option>
<option value="Bondoukou">Bondoukou</option>


<option value="Ferkessedougou"> Ferkessedougou</option>
<option value="Katiola">Katiola</option>
<option value="Issia"> Issia</option>
<option value="Oume">Oume</option>
<option value="Odienne"> Odienne</option>
<option value="Toumodi">Toumodi</option>
<option value="Adzope"> Adzope</option>
<option value="Soubre">Soubre</option>
<option value="Duekoue"> Duekoue</option>
<option value="Seguela">Seguela</option>


<option value="Agnibilekrou"> Agnibilekrou</option>
<option value="Daoukro">Daoukro</option>
<option value="Aboisso"> Aboisso</option>
<option value="Tiassale">Tiassale</option>
<option value="Akoupe"> Akoupe</option>
<option value="Lakota">Lakota</option>
<option value="Tingrela"> Tingrela</option>
<option value="Guiglo">Guiglo</option>
<option value="Boundiali"> Boundiali</option>
<option value="Bonoua">Bonoua</option>


<option value="Arrah"> Arrah</option>
<option value="Zuenoula">Zuenoula</option>
<option value="Vavoua"> Vavoua</option>
<option value="Affery">Affery</option>
<option value="Bongouanou"> Bongouanou</option>
<option value="Hire">Hire</option>
<option value="Mbatto"> Mbatto</option>
<option value="Touba">Touba</option>
<option value="Ouragahio"> Ouragahio</option>
<option value="Bouna">Bouna</option>


<option value="Sassandra"> Sassandra</option>
<option value="Ndouci">Ndouci</option>
<option value="Biankouma"> Biankouma</option>
<option value="Tanda">Tanda</option>
<option value="Tiebissou"> Tiebissou</option>
<option value="Tabou">Tabou</option>
<option value="Mankono"> Mankono</option>
<option value="Beoumi">Beoumi</option>
<option value="Bangolo"> Bangolo</option>
<option value="Adiake">Adiake</option>


<option value="Dikodougou"> Dikodougou</option>
<option value="Dabakala">Dabakala</option>
<option value="Rubino"> Rubino</option>
<option value="Bako">Bako</option>
<option value="Sakassou"> Sakassou</option>
<option value="Kani">Kani</option>
<option value="Tafire"> Tafire</option>
<option value="Mbahiakro">Mbahiakro</option>
<option value="Toulepleu"> Toulepleu</option>
<option value="Fresco">Fresco</option>


<option value="Jacqueville"> Jacqueville</option>
<option value="Guiberoua">Guiberoua</option>
<option value="Ayame"> Ayame</option>
<option value="Botro">Botro</option>
<option value="Alepe"> Alepe</option>
<option value="Ndiekro">Ndiekro</option>
<option value="Bocanda"> Bocanda</option>
<option value="Grand-lahou">Grand-lahou</option>
                        
                      </select>
                    </div>
                    

                     <div class="form-group">
                      <label for="334"> Frais</label>
                       <select class="form-control form-control-sm"style="border:1px solid skyblue;font-family:arial;text-transform:uppercase;color:<?php echo TEXTE2 ?>;" name="montant"id="334"autofocus>
                      <option value="0">0</option>
                        <option value="1000">1000</option>
                        <option value="1500">1500</option>
                        <option value="2000">2000</option>
                       <option value="2500">2500</option>
                        <option value="3000">3000</option>
                        <option value="3500">3500</option>
                        <option value="4000">4000</option>
                        <option value="4500">4500</option>
                        <option value="5000">5000</option>
                        <option value="5500">5500</option>
                        <option value="6000">6000</option>
                        <option value="6500">6500</option>
                        <option value="7000">7000</option>
                        <option value="7500">7500</option>
                        <option value="8000">8000</option>
                        <option value="8500">8500</option>
                        <option value="9000">9000</option>
                        <option value="9500">9500</option>
                        <option value="10000">10000</option>
                        
                      </select>
                    </div>

                     
                    


                   
                    <button type="submit"name="mf"  class="btn btn-success btn-sm progress-bar progress-bar-striped progress-bar-animated bg-success">  MODIFIER </button>
                  </form>
               

                </div> </div> </div>
             
         


































































            <div class="col-lg-6">


              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;background-color:white">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-danger">AJOUTER COMMUNE</h6>
                </div> 

<form method="post" action=""  autocomplete="on">

    <?php  
  srand((double)microtime()*10000);
$num=rand();
$coded1=$num;
$coded2=substr($coded1,0,4);
$code=$coded2;
//echo $coded;
echo'  <input type="hidden" name="code" value="'.$code.'"/>';   
?> 

    
                 <div class="card-body">
                  
                    <div class="form-group">
                                            <label for="111"> Comumune</label>

                        <select class="form-control form-control-sm"style=";color:<?php echo TEXTE2 ?>;border:1px solid skyblue;font-family:arial;text-transform:uppercase" name="nom"id="111"autofocus>
                     
                    <option value="Abobo"> Abobo</option>
                      <option value="Adjamé">Adjamé</option>
                      <option value="Plateau"> Plateau</option>
                      <option value="Triechville">Triechville</option>
                      <option value="Koumassi"> Koumassi</option>
                      <option value="Marcory">Marcory</option>
                      <option value="Yopougon"> Yopougon</option>
                      <option value="Anyama">Anyama</option>
                      <option value="Port-Bouet"> Port-Bouet</option>
                       <option value="Attécoube"> Attécoube</option>
                        <option value="Cocody"> Cocody</option>
                         <option value="Songon"> Songon</option>
                          <option value="Bingerville"> Bingerville</option>
                      </select>
                    </div>
                    

                     <div class="form-group">
                      <label for="339"> Frais livraison à domicile</label>
                       <select class="form-control form-control-sm"style="border:1px solid skyblue;font-family:arial;text-transform:uppercase;color:<?php echo TEXTE2 ?>;" name="montant"id="339"autofocus>
                         <option value="0">0</option>
                      <option value="500">500</option>
                        <option value="1000">1000</option>
                        <option value="1500">1500</option>
                        <option value="2000">2000</option>
                       <option value="2500">2500</option>
                        <option value="3000">3000</option>
                        <option value="3500">3500</option>
                        <option value="4000">4000</option>
                        <option value="4500">4500</option>
                        <option value="5000">5000</option>
                        <option value="5500">5500</option>
                        <option value="6000">6000</option>
                        <option value="6500">6500</option>
                        <option value="7000">7000</option>
                        <option value="7500">7500</option>
                        <option value="8000">8000</option>
                        <option value="8500">8500</option>
                        <option value="9000">9000</option>
                        <option value="9500">9500</option>
                        <option value="10000">10000</option>
                        
                      </select>
                    </div>

                     
                   

                   
                    <button type="submit"name="vc"  class="btn btn-danger btn-sm progress-bar progress-bar-striped progress-bar-animated bg-danger">  AJOUTER </button>
                  </form>
               

                </div>
             
         

        </div>  </div>  
             
            

























            <div class="col-lg-6">





              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;background-color:white">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-info">MODIFIER COMMUNE</h6>
                </div> 

<form method="post" action=""  autocomplete="on">
                 <div class="card-body">
                  
                    <div class="form-group">
                                            <label for="111"> Commune</label>

                        <select class="form-control form-control-sm"style=";color:<?php echo TEXTE2 ?>;border:1px solid skyblue;font-family:arial;text-transform:uppercase" name="nom"id="111"autofocus>
                     
                   <option value="Abobo"> Abobo</option>
                      <option value="Adjamé">Adjamé</option>
                      <option value="Plateau"> Plateau</option>
                      <option value="Triechville">Triechville</option>
                      <option value="Koumassi"> Koumassi</option>
                      <option value="Marcory">Marcory</option>
                      <option value="Yopougon"> Yopougon</option>
                      <option value="Anyama">Anyama</option>
                      <option value="Port-Bouet"> Port-Bouet</option>
                       <option value="Attécoube"> Attécoube</option>
                        <option value="Cocody"> Cocody</option>
                        <option value="Songon"> Songon</option>
                          <option value="Bingerville"> Bingerville</option>
                        
                      </select>
                    </div>
                    

                     <div class="form-group">
                      <label for="331"> Frais livraison à domicile</label>
                       <select class="form-control form-control-sm"style="border:1px solid skyblue;font-family:arial;text-transform:uppercase;color:<?php echo TEXTE2 ?>;" name="montant"id="331"autofocus>
                      <option value="0">0</option>
                        <option value="1000">1000</option>
                        <option value="1500">1500</option>
                        <option value="2000">2000</option>
                       <option value="2500">2500</option>
                        <option value="3000">3000</option>
                        <option value="3500">3500</option>
                        <option value="4000">4000</option>
                        <option value="4500">4500</option>
                        <option value="5000">5000</option>
                        <option value="5500">5500</option>
                        <option value="6000">6000</option>
                        <option value="6500">6500</option>
                        <option value="7000">7000</option>
                        <option value="7500">7500</option>
                        <option value="8000">8000</option>
                        <option value="8500">8500</option>
                        <option value="9000">9000</option>
                        <option value="9500">9500</option>
                        <option value="10000">10000</option>
                        
                      </select>
                    </div>

                     
                    


                   
                    <button type="submit"name="mfi"  class="btn btn-info btn-sm progress-bar progress-bar-striped progress-bar-animated bg-info">  MODIFIER </button>
                  </form>
               

                </div>
             

        </div>  </div>  </div>  </div>  </div>
             
            

<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo GAUCHE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-headphones fa-1x "style="color:<?php echo GAUCHE;?>"></i> Discussion instantanée</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Discussion instantanée</li>
            </ol>
          </div>
    
  <div class="row">
            <div class="col-lg-12">
              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;background-color:white">
               
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-primary">DISCUSSION</b> </h6>
                                          
                </div> 






                  <?php 
  if(isset($_GET['tokken_service']) AND !empty($_GET['tokken_service']))
  {
    $tokken_service=htmlspecialchars($_GET['tokken_service']);
   
    $connectes=1;
    $reponse=$bdd->query('SELECT * FROM users WHERE code="'.$tokken_service.'" AND connectes="'.$connectes.'"');
    $res = $reponse->fetchAll();
    if(count($res) == 0) 
    {   echo '<b><script type="text/javascript"> alert(\'------------------ Le lien utilisé est erroné ------------------- .\');</script></b>';
  //exit();
  //die('&nbsp;desolee');
        echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>'; 

    }
    
       }
   

   ?>

  
        <?php
    if (isset($_POST['ecrire_un_message_prive'])){
   if (isset($_SESSION['id'])){

       if(isset($_POST['message']) AND !empty($_POST['message'])) {
            
              $req = $bdd->prepare('SELECT * FROM msgsend WHERE codesmg = :codesmg');
                          $req->execute(array('codesmg'=> $_POST['codesmg']));
                          $verif_codesmg=$req->fetch();
     
                            if(!$verif_codesmg) /*si il n'y a pas de resultat*/
                              {
       $req= $bdd->prepare('INSERT INTO msgsend(id_receveur,id_envoyeur,message,codesmg,dateenvoie,heureenvoie,vue_receveur,vue_envoyeur,lu_receveur,lu_envoyeur)
    VALUES(?,?,?,?,?,?,?,?,?,?)');
                            $req->execute(array($_POST['id_receveur'],$_POST['id_envoyeur'],$_POST['message'],$_POST['codesmg'],$_POST['dateenvoie'],$_POST['heureenvoie'],$_POST['vue_receveur'],$_POST['vue_envoyeur'],$_POST['lu_receveur'],$_POST['lu_envoyeur']));

                     if ($req) {
                      echo '<script type="text/javascript"> alert(\'MESSAGE ENVOYE AVEC SUCCES \');</script>';
                        echo' <META HTTP-EQUIV="refresh" CONTENT="0; URL=#">';
                        
                       } 
                      }
                    }
                   }
                  }
    
?>
  


<form method="POST" action=""  autocomplete="on" >
 <div class="card-body">
   <div class="form-group">
    <label for="3">Envoyer à</label>
      <?php 
      if(isset($_GET['tokken_service']) AND !empty($_GET['tokken_service']))
      {
      $tokken_service=htmlspecialchars($_GET['tokken_service']);
      $connectes=1;

      $reponse=$bdd->query('SELECT * FROM users WHERE code="'.$tokken_service.'" AND connectes="'.$connectes.'"');
      $res = $reponse->fetchAll();
      if(count($res) == 0) 
      {
      }
      else
      {
        foreach ($res as $donnees) {
       
     
      if(empty($donnees['photo'])) {
           echo'<br><img  src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;height:20px;width:20px">&nbsp;<b>'.$donnees['nomprenoms'].'</b>';
      }
      else
      {
            echo'<br><img  src="./mvc/vues/img/photo/admin/'.$donnees['photo'].'" style="border-radius:100%;height:20px;width:20px">&nbsp;<b>'.$donnees['nomprenoms'].'</b>';
        }

      
      }

    }

  }


      ?>
 </div>
            
                          
          <?php 
         /**/ if(isset($_SESSION['id']))
          {
            $tokken_service=htmlspecialchars($_GET['tokken_service']);
            $reponse=$bdd->query('SELECT * FROM users where code="'.$tokken_service.'"');
          $donnees=$reponse->fetch();
          if($donnees)
          {
            

        srand((double)microtime()*10000);
              $num=rand();
              $codesmg=$num;
        
              $date=getdate();
              $dateenvoie=date("d/m/Y"); 
              $heureenvoie=date("H:i:s"); 
             

          echo'
                <input type="hidden" name="vue_envoyeur"   value="1">
                <input type="hidden" name="vue_receveur"   value="0">
                <input type="hidden" name="lu_envoyeur"   value="1">
                <input type="hidden" name="lu_receveur"   value="0">
                <input type="hidden" name="id_receveur"   value="'.$donnees['id'].'">
                <input type="hidden" name="id_envoyeur"   value="'.$_SESSION['id'].'">
                <input type="hidden" name="dateenvoie" value="'.$dateenvoie.'">
                <input type="hidden" name="heureenvoie" value="'.$heureenvoie.'">
                <input type="hidden" name="codesmg"   value="'.$codesmg.'">';
  }
 }
        

          ?>        

                    <div class="form-group">
                      <label for="2"> Message </label>
                      <textarea placeholder=" "name="message" required="" value=""class="form-control form-control-sm" id="2" rows="4" style="border:1px solid skyblue;font-family:arial;text-transform:;color:<?php echo BOUTON ?>"></textarea>

                     
                    </div>

                   
                     <div class="form-group">

            <div class="custom-control custom-checkbox" style="line-height: 1.5rem;">
              <input type="checkbox" class="custom-control-input" id="customCheck"required="">
              <label class="custom-control-label" for="customCheck"checked=""> Signez 
                </label>
            </div>
          </div>



                   
                    <button type="submit"name="ecrire_un_message_prive"  class="btn btn-danger btn-sm"> ENVOYER
</button>
                  </div>
                </div>
              </div>
</div>
           </form>       
             



             
      




























































































































































     <!--<div class="alert alert-danger"style="font-size:14px; background-color:skyblue;border-color:skyblue;color:white;border-radius:20px;visibility: visible; animation-name:fadeInRightBig">
    <center><i class="fa fa-bullhorn"id="DivClignotantesiaka"></i> Salut !!!  <b> utilisateur .</b> Veillez avant de continuer prévoir une image de la copie de l'original de l'acte de naissance que vous allez uploader apres le remplissage du formualaire</center>
    </div>-->
            <!-- Earnings (Monthly) Card Example 
                <div class="card-body"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.20)!important;background-color:white">












                 


                     
             
               

                </div>-->
             
            <br> <br> 
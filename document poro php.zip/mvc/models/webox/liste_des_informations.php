<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-Icon:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;">  <i class="fas fa-fw fa-th fa-1x "style="color:<?php echo TITRE;?>"></i> Liste des informations</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Liste des informations</li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->



          <!-- Row -->
         


                 <?php



                //echo $code_client;
                //$reponse=$bdd->query("SELECT*FROM probleme  ORDER BY type  DESC limit 0,10000 ");
                
               //$reponse=$bdd->query("SELECT*FROM probleme ORDER BY dateenvoi  ASC LIMIT 0, 10000000");


                     $droitacces=2;
                  $categorie='Actes de Mariage';
                
                  $reponse=$bdd->query(" SELECT*FROM infos ORDER BY id  DESC LIMIT 0, 10000000");
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                  if (count($res) == 0) 
                {

                 /* echo '<script type="text/javascript"> alert(\'     DESOLE  . AUCUNS RESULTAT TROUVES      \');</script>';

                   echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>'; */

                    echo' 

                          <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">LISTE DES INFORMATIONS :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                        ';
                
                            include('./mvc/models/webox/oops.php');

                }
                else {
                echo'
                 <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                <div class="table-responsive condensed">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">LISTE DES INFORMATIONS :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                </div>
                 <table class="table  table-sm mb-0 table-hover table-condensed">

                    <thead style="color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
                      <tr>
                        <th>ID</th>
                      
                        <th>Titre </th>
                     
                        <th><centere>Date</center> </th>

                        <th>Heure </th>
                          <th>Contenu</th>
                       <th></th>

                      </tr>
                    </thead>

                   

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody id="myInput">
                     
                      
                      <tr>
                       

                      
                  <td>#00'.$donnees['id'].'</td>

                  <td title='.$donnees['titre'].'><centere><span class="badge badge-primary progress-bar progress-bar-striped progress-bar-animated bg-primary">'.substr($donnees['titre'],0,18).' </span></center></td>

                  <td title='.$donnees['dateenvoie'].'>'.substr($donnees['dateenvoie'],0,20).'</td>

                  <!----><td  title='.$donnees['heureenvoie'].'>'.substr($donnees['heureenvoie'],0,5).'</td>
                     <td title='.$donnees['contenu'].'>'.substr($donnees['contenu'],0,400).'</span></span></td>


          

                          <td ><small><a href="./goodoo.php?webox='.SUPPR_INFO.'&id='.$donnees['id'].'"onclick="return confirm(\'êtes vous sûre de le supprimer   '.$donnees['id'].' ?\');" data-toggle="tooltip" data-placement="top" title="SUPPRESSION" data-original-title="Supprimer"><font color="white"><i class="fa fa-trash"style="color:red;"></i></b></a></font></small></center></td>
                         </tr>
                     
              
            </tbody>';
                     }

                echo'</table>';
          }
          
          ?>
  </div>   </div>  </div>  </div>   <br> 



            


            
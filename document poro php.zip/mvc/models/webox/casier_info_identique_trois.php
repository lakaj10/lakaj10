
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-folder-open fa-1x "style="color:<?php echo TITRE;?>"></i> Casier judiciaire</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Casier judiciaire</li>
            </ol>
          </div>


    
<?php


$errors = [];
mb_internal_encoding('UTF-8');


if ('POST' == $_SERVER['REQUEST_METHOD']) {

if (isset($_POST['ajouter_demande_actes_de_naissance2'])) {

        $coded=$_POST['coded'];
     $reponse = $bdd->query('SELECT * FROM demandes_cj_tmp WHERE coded="'.$_POST['coded'].'" ORDER BY idcj DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {
                  $bdd->exec("UPDATE demandes_cj_tmp SET 
                  commune='".$_POST['commune']."',
                  frq='".$_POST['frq']."',
                  adressedom='".$_POST['adressedom']."',
                   quartier='".$_POST['quartier']."'
                  WHERE  coded='".$coded."'");

  //sleep(2);

              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CASIER_IDENTIQUE_QUATRE.'&identifiant_demande='.$_POST['coded'].'"</SCRIPT>'; 

                  
                
      }
   }
}

if($errors) {
echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div>';

}

?> 




    
<?php


$errors = [];
mb_internal_encoding('UTF-8');


if ('POST' == $_SERVER['REQUEST_METHOD']) {

if (isset($_POST['ajouter_demande_actes_de_naissance'])) {

        $coded=$_POST['coded'];
     $reponse = $bdd->query('SELECT * FROM demandes_cj_tmp WHERE coded="'.$_POST['coded'].'" ORDER BY idcj DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {
                  $bdd->exec("UPDATE demandes_cj_tmp SET 
                  
                   quartier='".$_POST['quartier']."',
                   frq='".$_POST['frq']."'
                  WHERE  coded='".$coded."'");

  //sleep(2);

             echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CASIER_TERMINE.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>'; 

                  
                
      }
   }
}

if($errors) {
echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div>';

}

?> 













 <?php 
 
  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   

   $reponse=$bdd->query("SELECT*FROM demandes_cj_tmp WHERE coded='".$identifiant_demande."' ORDER BY idcj  DESC LIMIT 0, 1");

$nb_resultats = $reponse->rowCount(); 
$res = $reponse->fetchAll();
if (count($res) == 0) 
{   
    echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
            //  echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE_IDENTIQUE_TROIS.'"</SCRIPT>'; 

    }
    else
    {
      foreach ($res as $donnees) {

echo'

  <div class="row">
            <div class="col-lg-12">
              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;background-color:white">
               
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;border-radius:.375rem">
 <h6 class="m-0 font-weight-bold text-primary">FORMULAIRE DE DEMANDE</h6>      

                  </div>

                <div class="card-body">




    <form method="POST" action=""  autocomplete="off">';
      
         

                  echo'<input  value="'.ucfirst($donnees['coded']).'" type="hidden"class="form-control form-control-sm "style=" font-family:verdana ;color:'.COULEUR.';background-color:'.COULEURT.'" name="coded">';

                  
                   if(isset($donnees['villelivrai']) AND $donnees['villelivrai']=="Abidjan"  AND $donnees['mode']=="Livraison à Domicile" )
                  {


                       
           
                      echo'    
                      <div class="form-group">
                      <label for="2"> Filiation du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['filiation'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Nom & prénoms du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['nomprenom'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Numéro de la CNI </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['numcni'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Date de naissance </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['dn'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Lieu de naissance </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['ln'].'">
                    </div>


                    <div class="form-group">
                      <label for="2"> Profession </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['prof'].'">
                    </div>

                    <div class="form-group">
                      <label for="2"> Nombre d\'enfants </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['enfants'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Situation matrimoniale </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['situation'].'">
                    </div>


                    <div class="form-group">
                      <label for="2"> Lieu de residence </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['residence'].'">
                    </div>

                    <div class="form-group">
                      <label for="2"> Modif de la demande </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['motifdemande'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Lieu de la demande </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['lieudemande'].'">
                    </div>





                 


                       <div class="form-group">
                      <label for="13"> Dans quelle commune êtes vous ? </label>
                      <select name="commune"style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="54"class="form-control form-control-sm  " value=""required="">
                      

                      <option value="Abobo"> Abobo</option>
                      <option value="Adjamé">Adjamé</option>
                      <option value="Plateau"> Plateau</option>
                      <option value="Triechville">Triechville</option>
                      <option value="Koumassi"> Koumassi</option>
                      <option value="Marcory">Marcory</option>
                      <option value="Yopougon"> Yopougon</option>
                      <option value="Anyama">Anyama</option>
                      <option value="Port-Bouet"> Port-Bouet</option>
                       <option value="Attécoube"> Attécoube</option>
                        <option value="Cocody"> Cocody</option>
                      </select>
                      </div>

                        <div class="form-group">
                      <label for="2"> Adresse du domicile </label>
                      <input type="text" name="adressedom" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:" id="2" placeholder="" required value=""autofocus>
                    </div>

                    <div class="form-group">
                      <label for="2"> Nom du quartier </label>
                      <input type="text" name="quartier" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:" id="2" placeholder="" required value=""autofocus>
                    </div>
                      
                          <input  value="0" type="hidden"class="form-control form-control-sm "style=" font-family:verdana ;color:'.COULEUR.';background-color:'.COULEURT.'" name="frq">
                          

                        <button type="submit"name="ajouter_demande_actes_de_naissance2"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar"> ENREGISTRER</button>
                        </div>
                        </div>
                        </div>
                        </div>
                        </form>   
                      ';
                  }
                elseif(isset($donnees['villelivrai']) AND $donnees['villelivrai']=="Abidjan"  AND $donnees['mode']=="Livraison par Courrier" )
                  {
                     echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CASIER_TERMINE.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>'; 
                  
                    //echo' Vous allez recevoir le courrier dans une gare de transport à '.$donnees['villelivrai'];

                  }

                  elseif(isset($donnees['villelivrai']) AND  $donnees['villelivrai']=="Bouake" || $donnees['villelivrai']=="Yamoussoukro" || $donnees['villelivrai']=="Korhogo"  AND $donnees['mode']=="Livraison à Domicile")
                  {
                      echo'
                         <div class="form-group">
                      <label for="2"> Filiation du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['filiation'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Nom & prénoms du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['nomprenom'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Numéro de la CNI </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['numcni'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Date de naissance </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['dn'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Lieu de naissance </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['ln'].'">
                    </div>


                    <div class="form-group">
                      <label for="2"> Profession </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['prof'].'">
                    </div>

                    <div class="form-group">
                      <label for="2"> Nombre d\'enfants </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['enfants'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Situation matrimoniale </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['situation'].'">
                    </div>


                    <div class="form-group">
                      <label for="2"> Lieu de residence </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['residence'].'">
                    </div>

                    <div class="form-group">
                      <label for="2"> Modif de la demande </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['motifdemande'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Lieu de la demande </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['lieudemande'].'">
                    </div>




                     <div class="form-group">
                      <label for="2"> Nombre de copies </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['nbrecopie'].'">
                    </div>


                    <div class="form-group">
                      <label for="2"> Mode de Livraison </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['mode'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Ville d\'expédition </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['villelivrai'].'">
                    </div>


                      <div class="form-group">
                      <label for="13"> Saisissez le nom de votre quartier </label>
                       <input  value="" type="text"class="form-control form-control-sm "style=" font-family:verdana ;background-color:'.COULEURT.'" name="quartier"autofocus>

                        <input  value="2000" type="hidden"class="form-control form-control-sm "style=" font-family:verdana ;color:'.COULEUR.';background-color:'.COULEURT.'" name="frq">
                       
                      </div>

                      

                        <button type="submit"name="ajouter_demande_actes_de_naissance"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar"> ENREGISTRER</button>
                        </div>
                        </div>
                        </div>
                        </div>
                        </form>  
                      ';
                  }
                   elseif(isset($donnees['villelivrai']) AND  $donnees['villelivrai']=="Bouake" || $donnees['villelivrai']=="Yamoussoukro" || $donnees['villelivrai']=="Korhogo"  AND $donnees['mode']=="Livraison par Courrier" )
                  {
                        echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CASIER_TERMINE.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>'; 
                      
                  }
                   
                   
                  else
                  {
                    //echo' Vous allez recevoir le courrier dans une gare de transport à'.$donnees['villelivrai'];
                    echo' 
                        ';
                        echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CASIER_TERMINE.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>'; 
                  }


                




   }
}

}
?>

      </div>
                        </div>
                        </div>
                        </div>      </div>        <br>         
















































































































































                 


                     
             
   
 <?php 



$id=htmlspecialchars($_GET["id"]) ;
if(empty($id))
{
	echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>';

}
elseif(isset($id))
{
	$id=htmlspecialchars($_GET["id"]) ;
	 $date=getdate();

        $joura=date('d');
        $moisa=date('m');
        $anneea=date('Y');

        $hour=date('H');
        $min=date('i');
        $sec=date('s');

        $dateact=$joura.'/'.$moisa.'/'.$anneea;
        $heureact=$hour.':'.$min.':'.$sec;
        $activer=1 ;
        $bdd->exec("UPDATE users SET activer='".$activer."',datec='".$datec."', dateact='".$dateact."',heureact='".$heureact."' WHERE id='".$_GET['id']."'");
	//$bdd->exec("UPDATE users SET activer='".$activation_du_compte."' WHERE id='".$_GET['id']."'");
	//echo '<script type="text/javascript"> alert(\'             Opération éffectuée avec succès            \');</script>';

if($bdd)
{
	echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.LISTE_DES_UTILISATEURS.'"</SCRIPT>';
}
}
else
{
	echo("echoué") ;
}

?>



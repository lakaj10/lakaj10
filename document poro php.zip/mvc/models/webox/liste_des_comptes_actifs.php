
<div class="d-sm-flex align-items-center justify-content-between mb-4"style="visibility: visible; animation-name:fadeInRightBig">
            <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-unlock fa-1x "style="color:<?php echo TITRE;?>"></i> Comptes actifs</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="">Comptes actifs</li>
            </ol>
          </div> 
            <!-- Earnings (Monthly) Card Example -->



          <!-- Row -->
         


                 <?php



                //echo $code_client;
                //$reponse=$bdd->query("SELECT*FROM demandes  ORDER BY type  DESC limit 0,10000 ");
                
                     $droitacces=2;
                  $activer=1;
                 $reponse=$bdd->query('SELECT * FROM users  where droitacces="'.$droitacces.'" AND activer="'.$activer.'" ORDER BY id ASC limit 0,10000000  ');
               
                $nb_resultats = $reponse->rowCount(); 
                $res = $reponse->fetchAll();
                  if (count($res) == 0) 
                {

                 /* echo '<script type="text/javascript"> alert(\'     DESOLE  . AUCUNS RESULTAT TROUVES      \');</script>';

                   echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.DASHBOARD.'"</SCRIPT>'; */

                    echo' 

                          <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                          <h6 class="m-0 font-weight-bold text-primary">LISTE DES COMPTES ACTIFS :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                           ';
                
                            include('./mvc/models/webox/oops.php');

                }
                else {
                echo'
                 <div class="row">
                          <!-- Datatables -->
                          <div class="col-lg-12">
                          <div class="card mb-4">

                <div class="table-responsive condensed">
                  <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">LISTE DES COMPTES ACTIFS :&nbsp;<b style="color:red">'.$nb_resultats.'</b></h6>
                          </div>
                 <table class="table  table-hover table-sm mb-0 table-condensed">

                    <thead style="color: #6e707e;background-color: #eaecf4; border-color: #e3e6f0;">
                      <tr>
                        <th>Photo</th>
                       <th>Genre </th>
                        <th>Identifiant</th>
                        <th>Nom </th>
                        <th><centere>Email</center> </th>

                        <th>Pseudo </th>
                        <th>Mdpasse  </th>
                        <th>Actif</th>
                        <th>Date   </th>
                        <th>Heure</th>
                       
                       

                      </tr>
                    </thead>

                  

                     ' ;
foreach ($res as $donnees) {
echo '            

              
                    <tbody id="myInput">
                     
                      
                      <tr>
                          <td>';
                       
                        if(empty($donnees['photo'])) {
                        echo'<img  src="./mvc/vues/img/logo/boy.png" style="border-radius:100%;height:20px;width:20px">';
                        }
                        else
                        {
                        echo'<img  src="./mvc/vues/img/photo/users/'.$donnees['photo'].'" style="border-radius:100%;height:20px;width:20px">';
                        }

                        
                     echo' <td title='.$donnees['sexe'].'><center><b style="color:orange"><span class="badge badge-success progress-bar progress-bar-striped progress-bar-animated bg-success">'.substr($donnees['sexe'],0,15).'</span></b> </center></td>
                      
                        <td >'.$donnees['code'].'</td>

                        <td title='.$donnees['nomprenoms'].'><centere>'.substr($donnees['nomprenoms'],0,20).' </center></td>

                        <td  title='.$donnees['email'].'>'.substr($donnees['email'],0,30).'</td>

                          <!----><td>'.$donnees['pseudo'].'</td>

                         <td >'.substr($donnees['mdpcrypte'],0,6).'</td>

                        <td><center>';
                        if($donnees['activer']=='1')
                        {
                          echo'<b style="color:orange"><span class="badge badge-warning progress-bar progress-bar-striped progress-bar-animated bg-warning">Oui</span></b>';
                        }
                        else
                        {
                          echo'Non';
                        }
                      
                        echo'</center></td>

                         <td >'.$donnees['dateact'].'</td>

                          <td >'.substr($donnees['heureact'],0,5).'</td>
                         </tr>
                     
              
            </tbody>';
                     }

                echo'</table>';
          }
          
          ?>
  </div>   </div>  </div>  </div>   <br> 



            


            
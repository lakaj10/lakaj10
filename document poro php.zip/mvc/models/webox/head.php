
 <?php
############################################################################################################################################
if(empty($_SESSION['pseudo']))
{
######################################################################################################################################### echo'<META HTTP-EQUIV="refresh" CONTENT="0; URL=./woodoo.php?webox='.OUVERTURE.'">';

}
else
{ 
  sleep(2);
   echo'<META HTTP-EQUIV="refresh" CONTENT="2; URL=./goodoo.php?webox='.DASHBOARD.'">';
}


      
;  ?>
<div class="text-center">
<h1 class="h3 text-gray-90 mb-0"style="text-decoration:none;">
<center> 

<a  href="./woodoo.php?webox=<?php echo OUVERTURE;?>"title="ACCEUEIL"style="text-decoration:none;"> 
	<!--<i class="fa fa-file-pdf fa-spina fa-2x"style="color:#fc544b;font-size:60px"id="DivClignotantesiakaa"></i><br><br>
 	 <img src="./mvc/vues/img/logo/log.png" style=" height:60px;width:60px" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI">

<span style="font-weight:bolder;
font-size:80px;color:<?php //echo COULEUR;?>;text-decoration:none;font-family: mistral">D</span><span style="font-weight:bolder;
font-size:80px;color:<?php //echo GAUCHE;?>;text-decoration:none;font-family: mistral">P</span> 

 <img src="./mvc/vues/img/logo/sa.png" style=" height:28px;width:31px" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI">	<img src="./mvc/vues/img/logo/cccc.png" style=" height:24px;width:250px" >  --> 
 	
 	<img src="./mvc/vues/img/logo/siaka.png" style=" height:60px;width:60px" alt="souci d\'affichage" title="DOCUMENTS-PORO.CI">
 	</a> 
</center>

</h1> <br>  

</div>

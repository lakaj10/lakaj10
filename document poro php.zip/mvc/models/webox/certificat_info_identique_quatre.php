
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-flag fa-1x "style="color:<?php echo TITRE;?>"></i> Certificat de Nationalité</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Certificat de Nationalité</li>
            </ol>
          </div>
   

    
    
    
<?php


$errors = [];
mb_internal_encoding('UTF-8');


if ('POST' == $_SERVER['REQUEST_METHOD']) {

if (isset($_POST['ajouter_demande_actes_de_naissance'])) {

        $coded=$_POST['coded'];
     $reponse = $bdd->query('SELECT * FROM demandes_cni_tmp WHERE coded="'.$_POST['coded'].'" ORDER BY idcni DESC LIMIT 0, 1');
                while ($donnees = $reponse->fetch())
                 {
                  $bdd->exec("UPDATE demandes_cni_tmp SET 
                  frc='".$_POST['frc']."'
                  WHERE  coded='".$coded."'");

  //sleep(2);

              echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CERTIFICAT_TERMINE.'&identifiant_demande='.$_POST['coded'].'"</SCRIPT>'; 

                  
                
      }
   }
}

if($errors) {
echo '

                <div class="alert alert-danger">
                ', implode('', $errors), '
                </div>';

}

?> 

 <?php 
 
  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   

   $reponse=$bdd->query("SELECT*FROM demandes_cni_tmp WHERE coded='".$identifiant_demande."' ORDER BY idcni  DESC LIMIT 0, 1");

$nb_resultats = $reponse->rowCount(); 
$res = $reponse->fetchAll();
if (count($res) == 0) 
{   
    echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
            //  echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE_IDENTIQUE_TROIS.'"</SCRIPT>'; 

    }
    else
    {
      foreach ($res as $donnees) {

echo'

  <div class="row">
            <div class="col-lg-12">
              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;background-color:white">
               
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.10)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-primary">FORMULAIRE DE DEMANDE</b> )</h6>
                
                  </div>

                <div class="card-body">




    <form method="POST" action=""  autocomplete="off" enctype="multipart/form-data">
      
                              <div class="form-group">
                      <label for="2"> Filiation du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['filiation'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Nom & prénoms du demandeur </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['nomprenom'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Numéro de la CNI </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['numcni'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Date de naissance </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['dn'].'">
                    </div>


                     <div class="form-group">
                      <label for="2"> Lieu de naissance </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['ln'].'">
                    </div>


                

                    <div class="form-group">
                      <label for="2"> Motif de la demande </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['motifdemande'].'">
                    </div>
                     <div class="form-group">
                      <label for="2"> Lieu de la demande </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['lieudemande'].'">
                    </div>






                     <div class="form-group">
                      <label for="2"> Nombre de copies </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['nbrecopie'].'">
                    </div>

 <div class="form-group">
                      <label for="2"> Mode de Livraison </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['mode'].'">
                    </div>

                     <div class="form-group">
                      <label for="2"> Ville d\'expédition </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['villelivrai'].'">
                    </div>

                    <div class="form-group">
                      <label for="2"> Nom de la commune </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['commune'].'">
                    </div>



                     <div class="form-group">
                      <label for="2"> Adresse du domicile </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['adressedom'].'">
                    </div>

                    <div class="form-group">
                      <label for="2"> Nom du quartier </label>
                      <input type="text"disabled="" name="numextrait" class="form-control form-control-sm  "style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" id="2" placeholder="" required value="'.$donnees['quartier'].'">
                    </div>








                  <input  value="'.ucfirst($donnees['coded']).'" type="hidden"class="form-control form-control-sm "style=" font-family:verdana ;color:'.COULEUR.';background-color:'.COULEURT.'" name="coded">

        
                   <input  value="'.ucfirst($donnees['commune']).'" type="hidden"class="form-control form-control-sm "style=" font-family:verdana ;background-color:'.COULEURT.'">';




                  $commune=$donnees['commune'];

                 $reponse2=$bdd->query("SELECT*FROM commune WHERE nom='".$commune."'");

              $nb_resultats = $reponse2->rowCount(); 
              $res2 = $reponse2->fetchAll();
              if (count($res2) == 0) 
              {   
                  //echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
                          //  echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE.'"</SCRIPT>'; 
                    die('Les frais de livraison à domicile dans cette commune existe pas ');
                  }
                  else
                  {
                    foreach ($res2 as $donnees2) {
                 
                 echo '<input  type="hidden"autofocus="" name="frc"style="border:1px solid #ddd;font-family:arial;text-transform:uppercase;color:'.BOUTON.'" class="form-control form-control-sm  " id="8" placeholder="  " required="" value="'.$donnees2['montant'].'"required="">
                   ';

                  


              }
              }

  echo'<div class="form-group">

                    <div class="custom-control custom-checkbox" style="line-height: 1.5rem;">
                    <input type="checkbox" class="custom-control-input" id="customCheck"checked=""required=""autofocus>
                    <label class="custom-control-label" for="customCheck"checked=""> <b>Juste que là tout vas bien ?</b> 
                    </label>
                    </div>
                    </div>


                    <button type="submit"name="ajouter_demande_actes_de_naissance"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar"> ENREGISTRER</button>
                    </div>
                    </div>
                    </div>
                    </div>
                    </form>  


                    ';
}
}
}



   



 
?>

             

 </div> </div> </div> </div> </div> <br>














































































































































                 


                     
             
   
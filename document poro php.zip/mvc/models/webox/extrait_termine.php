<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo GAUCHE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-paste fa-1x "style="color:<?php echo GAUCHE;?>"></i>Actes de naissance</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Actes de naissance</li>
            </ol>
          </div>
  











<?php

  if(isset($_GET['identifiant_demande']) AND !empty($_GET['identifiant_demande']))
  {
    $identifiant_demande=htmlspecialchars($_GET['identifiant_demande']);   
               $reponse=$bdd->query("SELECT*FROM demandes_adn_tmp WHERE coded='".$identifiant_demande."' ORDER BY idn  DESC LIMIT 0, 1");


              $nb_resultats = $reponse->rowCount(); 
              $res = $reponse->fetchAll();
              if (count($res) == 0) 
              {   
              //echo '<b><script type="text/javascript"> alert(\' Vos ne pouvez pas accéder à ce service\');</script></b>';
              //echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.NAISSANCE.'"</SCRIPT>'; 
                exit();
              }
              else
              {
              foreach ($res as $donnees) {

                $req = $bdd->prepare('SELECT 1 FROM demandes_adn WHERE coded="'.$identifiant_demande.'"');
                          $req->execute(array('coded'=>$donnees['coded']));
                          $nb_resultats_recherche=$req->fetch();

                              if(!$nb_resultats_recherche)
                              {
                              $solde=$donnees['montant']+$donnees['fre']+$donnees['frc']+$donnees['frq'];
                                  $bdd->exec("UPDATE demandes_adn_tmp SET solde='".$solde."' WHERE  coded='".$donnees['coded']."'");
                              //echo '<b><script type="text/javascript"> alert(\'Nouveau Mouvement ajouté dans la base de donnée\');</script></b>';

                              /*$req= $bdd->prepare('INSERT INTO demandes_adn(coded,codeu,type,categorie,paiement,datepaiement,statut,datestatut,jour,mois,annee,pu,nbrecopie,montant,fre,mode,commune,frc,quartier,frq)
                                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
                              $req->execute(array($donnees['coded'],$donnees['codeu'],$donnees['type'],$donnees['categorie'],$donnees['paiement'],$donnees['datepaiement'],$donnees['statut'],$donnees['datestatut'],$donnees['jour'],$donnees['mois'],$donnees['annee'],$donnees['pu'],$donnees['nbrecopie'],$donnees['montant'],$donnees['fre'],$donnees['mode'],$donnees['commune'],$donnees['frc'],$donnees['quartier'],$donnees['frq']));
                              */

                                if($req)
                                {
                                 //$bdd->exec(" DELETE FROM demandes_tmp WHERE idd = ".$donnees['idd']);
                                 echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.CONFIRMER_ADN.'&identifiant_demande='.$donnees['coded'].'"</SCRIPT>'; 
                                }

                              }
                              else 
                              {
                             echo '<b><script type="text/javascript"> alert(\'Mouvement existant \');</script></b>';

                              }                


              }
              }
              }
              
?>



</div></div></div></div></div>

















        





















































































































































                 


                     
             
               

            
             
            <br> <br> 

<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-800"style="color:<?php echo TITRE;?>;font-weight:bolder;"> <i class="fas fa-fw fa-lock fa-1x "style="color:<?php echo TITRE;?>"></i> Mot de passe</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#">Accueil</a></li>
              <li class="breadcrumb-item active" aria-current="page">Mot de passe</li>
            </ol>
          </div>
            <div class="row">
            <div class="col-lg-12">
              <div class="card mb-4"style=" box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.06)!important;background-color:white">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between"style="background:#fff; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.06)!important;border-radius:.375rem">
                 <h6 class="m-0 font-weight-bold text-primary"> CHANGER LE MOT DE PASSE</h6>
                </div> 
                <div class="card-body">


<?php

if(isset($_POST['v'])){
 if(isset($_POST['mdp']) AND !empty($_POST['mdp']) AND isset($_POST['mdp2'])  AND $_POST['mdp']==$_POST['mdp2']){
    $mdp=$_POST['mdp'];
    $mdp2=$_POST['mdp2'];
    $mdpcrypte=$_POST['mdp'];
    $taille=2;
    $insertmdp=$bdd->prepare("UPDATE users SET  mdp='".sha1($_POST['mdp'])."',mdpcrypte='".$_POST['mdp']."' WHERE id='".$_SESSION['id']."'");

    $insertmdp->execute(array($mdp,$mdpcrypte));
        echo '<SCRIPT LANGUAGE="JavaScript">document.location.href="./goodoo.php?webox='.MDP.'"</SCRIPT>';          

 }  
   elseif($_POST['mdp']!=$_POST['mdp2']){
    echo '<script type="text/javascript"> alert(\'Les deux mots de passes ne sont pas conforment \');</script>';
    
    }
    elseif(isset($_POST['mdp']) AND !empty($_POST['mdp']) AND isset($_POST['mdp2']) AND !empty($_POST['mdp2'])AND strlen($_POST['mdp'])<$taille){
    echo '<script type="text/javascript"> alert(\'Le mot de passe saisi est très faible \');</script>';
            
   }
   elseif(isset($_POST['v']) AND empty($_POST['mdp']) || empty($_POST['mdp2'])){
   echo '<script type="text/javascript"> alert(\'Aucunes modifications apportée sur le compte \');</script>';
  

}
} 

?>     

<?php 
if( isset($_SESSION['id']))
{

$req = $bdd->query('SELECT * FROM users where id="'.$_SESSION['id'].'"');
$donnees = $req->fetch();
if($donnees)
{


echo 
' 
               
                  <form method="post" action=""  autocomplete="on">

                        <input type="hidden"name="id" value="'.$donnees['id'].'">

                    <div class="form-group">
                      <label for="exampleInputEmail1">Mot de passe actuel</label>
                      <input type="text" class="form-control form-control-sm" disabled id="exampleInputEmail1" aria-describedby="emailHelp" placeholder=""value="'.$donnees['mdpcrypte'].'">
                     
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Nouveau</label>
                      <input type="password"autofocus="" name="mdp"style="border:1px solid #ddd;font-family:arial;text-transform:normal" class="form-control form-control-sm" id="exampleInputPassword1" placeholder="" required>
                    </div>
                    
                     <div class="form-group">
                      <label for="exampleInputPassword1">Confirme </label>
                      <input type="password"autofocus="" name="mdp2"style="border:1px solid #ddd;font-family:arial;text-transform:normal" class="form-control form-control-sm" id="exampleInputPassword1" placeholder="" required>
                    </div>
                   
                    <button type="submit"name="v"  class="btn btn-primary btn-sm progress-bar progress-bar-striped progress-bar-animated bg-primary btn-sm" role="progressbar"">  ENREGISTRER</button>
                  </form>
               
 ';
    }
    }
?>
                </div>     </div>     </div>     </div>
             
            
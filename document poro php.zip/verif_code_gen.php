<?php session_start(); 
header ("Content-type: image/png");

$_img=imagecreatefrompng('fondd.png');

$arriere_plan = imagecolorallocate($_img, 45,67,226); 

$avant_plan = imagecolorallocate($_img, 0,0,0); 

$randomString = substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 1) . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6);

$_SESSION['aleat_nbr'] = $randomString;

imagestring($_img, 5, 18, 5, $randomString, $avant_plan);
imagepng($_img);
?>


